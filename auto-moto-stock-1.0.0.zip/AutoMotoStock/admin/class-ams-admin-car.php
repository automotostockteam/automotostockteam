<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
if (!class_exists('AMS_Admin_Car')) {
    /**
     * Class AMS_Admin_Car
     */
    class AMS_Admin_Car
    {
        /**
         * Register custom columns
         * @param $columns
         * @return array
         */
        public function register_custom_column_titles($columns)
        {
            unset($columns['tags']);
            $columns['cb'] = "<input type=\"checkbox\" />";
            $columns['thumb'] = esc_html__('Image', 'auto-moto-stock');
            $columns['title'] = esc_html__('Vehicle Title', 'auto-moto-stock');
            $columns['type'] =  esc_html__('Type', 'auto-moto-stock');
            $columns['maker'] =  esc_html__('Brand', 'auto-moto-stock');
            /*$columns['model'] =  esc_html__('Model', 'auto-moto-stock');
            $columns['body'] =  esc_html__('Body', 'auto-moto-stock');*/
            $columns['status'] = esc_html__('Status', 'auto-moto-stock');
            $columns['price'] = esc_html__('Price', 'auto-moto-stock');
            $columns['featured'] = '<span data-tip="' .  esc_html__('Featured?', 'auto-moto-stock') . '" class="tips dashicons dashicons-star-filled"></span>';
            $columns['author'] = esc_html__('Author', 'auto-moto-stock');
            $columns['viewcount'] = esc_html__('View Count', 'auto-moto-stock');
            $new_columns = array();
            $custom_order = array('cb', 'thumb', 'title', 'type', 'maker',/*'model', 'body',*/ 'status', 'price', 'featured', 'author', 'viewcount', 'date');
            foreach ($custom_order as $colname) {
                $new_columns[$colname] = $columns[$colname];
            }
            return $new_columns;
        }

        /**
         * Display custom column for vehicles
         * @param $column
         */
        public function display_custom_column($column)
        {
            global $post;
            switch ($column) {

                case 'thumb':
                    if (has_post_thumbnail()) {
                        the_post_thumbnail('thumbnail', array(
                            'class' => 'attachment-thumbnail attachment-thumbnail-small',
                        ));
                    } else {
                        echo '&ndash;';
                    }
                    break;

                case 'type':
                    echo ams_admin_taxonomy_terms($post->ID, 'car-type', 'car');
                    break;

                case 'maker':
                    echo ams_admin_taxonomy_terms($post->ID, 'car-maker', 'car');
                    break;

                    /*case 'model':
                    echo ams_admin_taxonomy_terms($post->ID, 'car-model', 'car');
                    break;

                case 'body':
                    echo ams_admin_taxonomy_terms($post->ID, 'car-body', 'car');
                    break;*/

                case 'status':
                    echo ams_admin_taxonomy_terms($post->ID, 'car-status', 'car');
                    break;

                case 'price':
                    $price = get_post_meta($post->ID, AMS_METABOX_PREFIX . 'car_price', true);
                    if (!empty($price)) {
                        echo esc_html($price);
                    } else {
                        echo '&ndash;';
                    }
                    break;

                case 'featured':
                    $featured = get_post_meta($post->ID, AMS_METABOX_PREFIX . 'car_featured', true);
                    if ($featured == 1) {
                        $featured_text = esc_html__('Featured', 'auto-moto-stock');
                        $featured_icon = 'tips accent-color dashicons dashicons-star-filled';
                    } else {
                        $featured_text = esc_html__('Not Featured', 'auto-moto-stock');
                        $featured_icon = 'tips dashicons dashicons-star-empty';
                    }
                    $url = wp_nonce_url(admin_url('admin-ajax.php?action=ams_admin_feature_car&id=' . $post->ID), 'dip-feature-car');
                    echo '<a href="' . esc_url($url) . '"><i data-tip="' . $featured_text . '" class="' . esc_attr($featured_icon) . '"></i></a>';
                    break;

                case 'author':
                    echo '<a href="' . esc_url(add_query_arg('author', $post->post_author)) . '">' . get_the_author() . '</a>';
                    break;

                case 'viewcount':
                    $views = get_post_meta($post->ID, AMS_METABOX_PREFIX . 'car_views_count', true);
                    echo  ams_get_format_number($views);
                    break;
            }
        }

        /**
         * Modify List Row Actions
         * @param $actions
         * @param $post
         * @return mixed
         */
        public function modify_list_row_actions($actions, $post)
        {
            // Check for your post type.
            if ($post->post_type == 'car') {
                if (in_array($post->post_status, array('pending', 'expired')) && current_user_can('publish_transport', $post->ID)) {
                    $actions['car-approve'] = '<a href="' . wp_nonce_url(add_query_arg('approve_listing', $post->ID), 'approve_listing') . '">' . esc_html__('Approve', 'auto-moto-stock') . '</a>';
                }
                if (in_array($post->post_status, array('publish', 'pending')) && current_user_can('publish_transport', $post->ID)) {
                    $actions['car-expired'] = '<a href="' . wp_nonce_url(add_query_arg('expire_listing', $post->ID), 'expire_listing') . '">' . esc_html__('Expire', 'auto-moto-stock') . '</a>';
                }
                if (in_array($post->post_status, array('publish')) && current_user_can('publish_transport', $post->ID)) {
                    $actions['car-hidden'] = '<a href="' . wp_nonce_url(add_query_arg('hidden_listing', $post->ID), 'hidden_listing') . '">' . esc_html__('Hide', 'auto-moto-stock') . '</a>';
                }
                if (in_array($post->post_status, array('hidden')) && current_user_can('publish_transport', $post->ID)) {
                    $actions['car-show'] = '<a href="' . wp_nonce_url(add_query_arg('show_listing', $post->ID), 'show_listing') . '">' . esc_html__('Show', 'auto-moto-stock') . '</a>';
                }
            }
            return $actions;
        }

        /**
         * Sortable Columns
         * @param $columns
         * @return mixed
         */
        public function sortable_columns($columns)
        {
            $columns['price'] = 'price';
            $columns['featured'] = 'featured';
            $columns['author'] = 'author';
            $columns['post_date'] = 'post_date';
            return $columns;
        }

        /**
         * Column Orderby
         * @param $vars
         * @return array
         */
        public function column_orderby($vars)
        {
            if (!is_admin())
                return $vars;
            if (isset($vars['orderby']) && 'price' == $vars['orderby']) {
                $vars = array_merge($vars, array(
                    'meta_key' => AMS_METABOX_PREFIX . 'car_price',
                    'orderby' => 'meta_value_num',
                ));
            }
            if (isset($vars['orderby']) && 'featured' == $vars['orderby']) {
                $vars = array_merge($vars, array(
                    'meta_key' => AMS_METABOX_PREFIX . 'car_featured',
                    'orderby' => 'meta_value_num',
                ));
            }
            return $vars;
        }

        /**
         * Modify vehicle slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_slug($existing_slug)
        {
            $car_url_slug = ams_get_option('car_url_slug');
            if ($car_url_slug) {
                return $car_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle type slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_type_slug($existing_slug)
        {
            $car_type_url_slug = ams_get_option('car_type_url_slug');
            if ($car_type_url_slug) {
                return $car_type_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle maker slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_maker_slug($existing_slug)
        {
            $car_maker_url_slug = ams_get_option('car_maker_url_slug');
            if ($car_maker_url_slug) {
                return $car_maker_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle model slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_model_slug($existing_slug)
        {
            $car_model_url_slug = ams_get_option('car_model_url_slug');
            if ($car_model_url_slug) {
                return $car_model_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle body slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_body_slug($existing_slug)
        {
            $car_body_url_slug = ams_get_option('car_body_url_slug');
            if ($car_body_url_slug) {
                return $car_body_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle status slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_status_slug($existing_slug)
        {
            $car_status_url_slug = ams_get_option('car_status_url_slug');
            if ($car_status_url_slug) {
                return $car_status_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle exterior slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_exterior_slug($existing_slug)
        {
            $car_exterior_url_slug = ams_get_option('car_exterior_url_slug');
            if ($car_exterior_url_slug) {
                return $car_exterior_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle interior slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_interior_slug($existing_slug)
        {
            $car_interior_url_slug = ams_get_option('car_interior_url_slug');
            if ($car_interior_url_slug) {
                return $car_interior_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify location slug
         * @param $existing_slug
         * @return string
         */
        public function modify_location_slug($existing_slug)
        {
            $location_url_slug = ams_get_option('location_url_slug');
            if ($location_url_slug) {
                return $location_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle city slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_city_slug($existing_slug)
        {
            $car_city_url_slug = ams_get_option('car_city_url_slug');
            if ($car_city_url_slug) {
                return $car_city_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle neighborhood slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_neighborhood_slug($existing_slug)
        {
            $car_neighborhood_url_slug = ams_get_option('car_neighborhood_url_slug');
            if ($car_neighborhood_url_slug) {
                return $car_neighborhood_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Modify vehicle state slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_state_slug($existing_slug)
        {
            $car_state_url_slug = ams_get_option('car_state_url_slug');
            if ($car_state_url_slug) {
                return $car_state_url_slug;
            }
            return $existing_slug;
        }


        /**
         * Modify vehicle lable slug
         * @param $existing_slug
         * @return string
         */
        public function modify_car_label_slug($existing_slug)
        {
            $car_label_url_slug = ams_get_option('car_label_url_slug');
            if ($car_label_url_slug) {
                return $car_label_url_slug;
            }
            return $existing_slug;
        }

        /**
         * Approve_car
         */
        public function approve_car()
        {
            if (!empty($_GET['approve_listing']) && wp_verify_nonce($_REQUEST['_wpnonce'], 'approve_listing') && current_user_can('publish_post', $_GET['approve_listing'])) {
                $post_id = absint($_GET['approve_listing']);
                $listing_data = array(
                    'ID' => $post_id,
                    'post_status' => 'publish'
                );
                wp_update_post($listing_data);

                $author_id = get_post_field('post_author', $post_id);
                $user = get_user_by('id', $author_id);
                $user_email = $user->user_email;

                $args = array(
                    'listing_title' => get_the_title($post_id),
                    'listing_url' => get_permalink($post_id)
                );
                ams_send_email($user_email, 'mail_approved_listing', $args);
                wp_redirect(remove_query_arg('approve_listing', add_query_arg('approve_listing', $post_id, admin_url('edit.php?post_type=car'))));
                exit;
            }
        }

        /**
         * Expire vehicle
         */
        public function expire_car()
        {
            if (!empty($_GET['expire_listing']) && wp_verify_nonce($_REQUEST['_wpnonce'], 'expire_listing') && current_user_can('publish_post', $_GET['expire_listing'])) {
                $post_id = absint($_GET['expire_listing']);
                $listing_data = array(
                    'ID' => $post_id,
                    'post_status' => 'expired'
                );
                wp_update_post($listing_data);

                $author_id = get_post_field('post_author', $post_id);
                $user = get_user_by('id', $author_id);
                $user_email = $user->user_email;

                $args = array(
                    'listing_title' => get_the_title($post_id),
                    'listing_url' => get_permalink($post_id)
                );
                ams_send_email($user_email, 'mail_expired_listing', $args);

                wp_redirect(remove_query_arg('expire_listing', add_query_arg('expire_listing', $post_id, admin_url('edit.php?post_type=car'))));
                exit;
            }
        }

        /**
         * Hidden vehicle
         */
        public function hidden_car()
        {
            if (!empty($_GET['hidden_listing']) && wp_verify_nonce($_REQUEST['_wpnonce'], 'hidden_listing') && current_user_can('publish_post', $_GET['hidden_listing'])) {
                $post_id = absint($_GET['hidden_listing']);
                $listing_data = array(
                    'ID' => $post_id,
                    'post_status' => 'hidden'
                );
                wp_update_post($listing_data);
                wp_redirect(remove_query_arg('hidden_listing', add_query_arg('hidden_listing', $post_id, admin_url('edit.php?post_type=car'))));
                exit;
            }
        }

        /**
         * Show vehicle
         */
        public function show_car()
        {
            if (!empty($_GET['show_listing']) && wp_verify_nonce($_REQUEST['_wpnonce'], 'show_listing') && current_user_can('publish_post', $_GET['show_listing'])) {
                $post_id = absint($_GET['show_listing']);
                $listing_data = array(
                    'ID' => $post_id,
                    'post_status' => 'publish'
                );
                wp_update_post($listing_data);
                wp_redirect(remove_query_arg('show_listing', add_query_arg('show_listing', $post_id, admin_url('edit.php?post_type=car'))));
                exit;
            }
        }

        /**
         * Filter Restrict Manage Vehicle
         */
        public function filter_restrict_manage_car()
        {
            global $typenow;
            $post_type = 'car';
            $car_author = isset($_GET['car_author']) ? $_GET['car_author'] : '';
            $car_identity = isset($_GET['car_identity']) ? $_GET['car_identity'] : '';
            if ($typenow == $post_type) {
                $taxonomy_arr  = array('car-status', 'car-type', 'car-maker'/*,'car-model','car-body'*/);
                foreach ($taxonomy_arr as $taxonomy) {
                    $selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
                    $info_taxonomy = get_taxonomy($taxonomy);
                    wp_dropdown_categories(array(
                        'show_option_all' => sprintf(esc_html__('All %s', 'auto-moto-stock'), esc_html($info_taxonomy->label)),
                        'taxonomy'        => $taxonomy,
                        'name'            => $taxonomy,
                        'orderby'         => 'name',
                        'selected'        => $selected,
                        'show_count'      => true,
                        'hide_empty'      => false,
                    ));
                }
?>
                <input type="text" placeholder="<?php esc_attr_e('Author', 'auto-moto-stock'); ?>" name="car_author" value="<?php echo esc_attr($car_author); ?>">
                <input type="text" placeholder="<?php esc_attr_e('Vehicle ID', 'auto-moto-stock'); ?>" name="car_identity" value="<?php echo esc_attr($car_identity); ?>">
<?php
            };
        }

        /**
         * Car Filter
         * @param $query
         */
        public function car_filter($query)
        {
            global $pagenow;
            $post_type = 'car';
            $q_vars    = &$query->query_vars;
            if ($pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type) {
                $taxonomy_arr  = array('car-status', 'car-type', 'car-maker'/*,'car-model','car-body'*/);
                foreach ($taxonomy_arr as $taxonomy) {
                    if (isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0) {
                        $term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
                        $q_vars[$taxonomy] = $term->slug;
                    }
                }
                if (isset($_GET['car_author']) && $_GET['car_author'] != '') {
                    $q_vars['author_name'] = ams_clean(wp_unslash($_GET['car_author']));
                }
                if (isset($_GET['car_identity']) && $_GET['car_identity'] != '') {
                    $q_vars['meta_key'] = AMS_METABOX_PREFIX . 'car_identity';
                    $q_vars['meta_value'] = ams_clean(wp_unslash($_GET['car_identity']));
                    $q_vars['meta_compare'] = '=';
                }
            }
        }

        /**
         * Post Type Admin Order
         * @param $query
         */
        public function post_types_admin_order($query)
        {
            if (is_admin()) {
                $post_type = isset($query->query['post_type']) ? $query->query['post_type'] : '';
                if ($post_type == 'car') {
                    if ($query->get('orderby') == '') {
                        $query->set('orderby', array('menu_order' => 'ASC', 'date' => 'DESC'));
                    }
                }
            }
        }

        /**
         * Feature
         */
        public function feature()
        {
            if (!isset($_GET['_wpnonce'])) {
                return;
            }
            if (!wp_verify_nonce($_GET['_wpnonce'], 'dip-feature-car')) {
                return;
            }
            $car_id = isset($_GET['id']) ? $_GET['id'] : 0;

            $is_featured = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured', true);
            if ($is_featured == 1) {
                $is_featured = 0;
            } else {
                $is_featured = 1;
            }
            update_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured', $is_featured);
            if ($is_featured == 1) {
                update_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured_date', current_time('mysql'));
            }
            wp_safe_redirect(wp_get_referer() ? remove_query_arg(array('trashed', 'untrashed', 'deleted', 'ids'), wp_get_referer()) : admin_url('edit.php?post_type=car'));
            die();
        }
    }
}
