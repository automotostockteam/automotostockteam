<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('AMS_Admin_Setup')) {
    /**
     * Class AMS_Admin_Setup
     */
    class AMS_Admin_Setup
    {
        /**
         * Admin Menu
         */
        public function admin_menu()
        {
            add_menu_page(
                esc_html__( 'Auto Moto Stock', 'auto-moto-stock' ),
                esc_html__('Auto Moto Stock', 'auto-moto-stock'),
                'manage_options',
                'ams_welcome',
                array($this, 'menu_welcome_page_callback'),
                'dashicons-car',
                2
            );
            add_submenu_page(
                'ams_welcome',
                esc_html__('Welcome', 'auto-moto-stock'),
                esc_html__('Welcome', 'auto-moto-stock'),
                'manage_options',
                'ams_welcome',
                array($this, 'menu_welcome_page_callback')
            );
            add_submenu_page(
                'ams_welcome',
                esc_html__('AMS Options', 'auto-moto-stock'),
                esc_html__('AMS Options', 'auto-moto-stock'),
                'manage_options',
                'admin.php?page=ams_options'
            );
            add_submenu_page(
                'ams_welcome',
                esc_html__('Setup Pages', 'auto-moto-stock'),
                esc_html__('Setup Pages', 'auto-moto-stock'),
                'manage_options',
                'ams_setup',
                array($this, 'setup_page')
            );
        }
        
        /**
         * Get Welcome Page
         */
        public function menu_welcome_page_callback()
        {
            ?>
            <div class="wrap about-wrap">
                <h1><?php echo sprintf( __( 'Welcome to Auto Moto Stock %s', 'auto-moto-stock' ), AMS_PLUGIN_VER) ?></h1>
                <div class="about-text">
                    <?php esc_html_e( 'Auto Moto Stock is a plugin designed for websites. Suitable for car dealers, managers, private sellers. The plugin is fully functional. It is possible to view and track vehicles, built-in payment gateways, personal account and much more. With Auto Moto Stock, you can easily create an automotive website, find or sell a vehicle.', 'auto-moto-stock' ) ?>
                </div>
                <div class="ams-badge">
                    <img src="<?php echo AMS_PLUGIN_URL.'admin/assets/images/logo.png'; ?>" title="<?php esc_attr_e('Logo', 'auto-moto-stock' ) ?>">
                </div>
                
                <div class="feature-section two-col has-2-columns is-fullwidth">
	<div class="col column">

		<h3><?php esc_html_e( 'Step 1: Create pages with the setup wizard', 'auto-moto-stock' ); ?></h3>
		<p>
			<?php
			esc_html_e( "This setup wizard will help you get started with creating pages for submitting vehicles from the backend and frontend, vehicle management, profile management. Pages for packages, payment, login and registration, vehicles comparison/search and more...", 'auto-moto-stock');				
			?>
		</p>

		<p>
            <a href="<?php echo admin_url( 'admin.php?page=ams_setup' )?>"
            class="button button-primary"><?php esc_html_e('Setup pages', 'auto-moto-stock') ?></a> 
		</p>
	</div>

	<div class="col column">
		<img src="<?php echo AMS_PLUGIN_URL.'admin/assets/images/step-welcome/ams-setup-page.png'; ?>" />
	</div>
</div>

<div class="feature-section two-col has-2-columns is-fullwidth">
	<div class="col column">
		<img src="<?php echo AMS_PLUGIN_URL.'admin/assets/images/step-welcome/ams-options.png'; ?>" />
	</div>

	<div class="col column">
		<h3><?php esc_html_e( 'Step 2: Visit settings page', 'auto-moto-stock' ); ?></h3>

		<p>
			<?php
			esc_html_e("The main functions of the plugin are already included. Review the default settings and change them if necessary to suit your needs.", 'auto-moto-stock');
			?>
		</p>

		<p>
            <a href="<?php echo admin_url( 'admin.php?page=ams_options' ) ?>"
            class="button button-primary"><?php esc_html_e( 'AMS Settings', 'auto-moto-stock' ) ?></a>
		</p>
	</div>
</div>

<div class="feature-section two-col has-2-columns is-fullwidth">
	<div class="col column">

		<h3><?php esc_html_e( 'Step 3: Go to AMS plugin documentation page', 'auto-moto-stock' ); ?></h3>
		<p>
			<?php
			esc_html_e( "Read the documentation for the AMS plugin. Here all the steps for installing and configuring the plugin are describbed in detail. Here tuo will findinstructions on working with shortcodes, how to add new vehicle from the backend and frontend, register as an agent or dealer, payment and much more...", 'auto-moto-stock');				
			?>
		</p>

		<p>
            <a href="<?php echo admin_url( 'admin.php?page=ams_setup' )?>"
            class="button button-primary"><?php esc_html_e('Documentation', 'auto-moto-stock') ?></a> 
		</p>
	</div>

	<div class="col column">
		<img src="<?php echo AMS_PLUGIN_URL.'admin/assets/images/step-welcome/ams-doc-page.png'; ?>" />
	</div>
</div>

<div class="feature-section two-col has-2-columns is-fullwidth">
	<div class="col column">
		<img src="<?php echo AMS_PLUGIN_URL.'admin/assets/images/step-welcome/ams-video.png'; ?>" />
	</div>

	<div class="col column">
		<h3><?php esc_html_e( 'Step 4: Visit video tutorials page', 'auto-moto-stock' ); ?></h3>

		<p>
			<?php
			esc_html_e('If you understand the video documentation, follow the link and watch the detailed video tutorials on our YouTube channel.', 'auto-moto-stock');
			?>
		</p>

		<p>
            <a href="<?php echo admin_url( 'admin.php?page=ams_options' ) ?>"
            class="button button-primary"><?php esc_html_e( 'AMS Video Tutorials', 'auto-moto-stock' ) ?></a>
		</p>
	</div>
</div> 

<div class="feature-section two-col has-2-columns is-fullwidth">
	<div class="col column">

		<h3><?php esc_html_e( 'Step 5: Go to AMS plugin support/faq page', 'auto-moto-stock' ); ?></h3>
		<p>
			<?php
			esc_html_e( "If after all steps you still have questions visit our support page. You will surely find answers here or create a new ticket. We will solve the problem as quickly as possible.", 'auto-moto-stock');				
			?>
		</p>

		<p>
            <a href="<?php echo admin_url( 'admin.php?page=ams_setup' )?>"
            class="button button-primary"><?php esc_html_e('Support/FAQ', 'auto-moto-stock') ?></a> 
		</p>
	</div>

	<div class="col column">
		<img src="<?php echo AMS_PLUGIN_URL.'admin/assets/images/step-welcome/ams-faq-page.png'; ?>" />
	</div>
</div>

<!-- <div class="feature-section two-col has-2-columns is-fullwidth">
	<div class="col column">
		<img src="<?php //echo AMS_PLUGIN_URL.'admin/assets/images/step-welcome/ams-video.png'; ?>" />
	</div>

	<div class="col column">
		<h3><?php //esc_html_e( 'Step 6: Last step', 'auto-moto-stock' ); ?></h3>

		<p>
			<?php
			//esc_html_e("Don't forget to support us ratings and donations. We will be very grateful to you. Thank you very much and have a nice day!", 'auto-moto-stock');
			?>
		</p>

		<p>
            <a href="<?php //echo admin_url( 'admin.php?page=ams_options' ) ?>"
            class="button button-primary"><?php //esc_html_e( 'Donate', 'auto-moto-stock' ) ?></a>
		</p>
	</div>
</div> --> 
         <?php
        }

        /**
         * Redirect the setup page on first activation
         */
        public function redirect()
        {
            // Bail if no activation redirect transient is set
            if (!get_transient('_ams_activation_redirect')) {
                return;
            }

            if (!current_user_can('manage_options')) {
                return;
            }

            // Delete the redirect transient
            delete_transient('_ams_activation_redirect');

            // Bail if activating from network, or bulk, or within an iFrame
            if (is_network_admin() || isset($_GET['activate-multi']) || defined('IFRAME_REQUEST')) {
                return;
            }

            if ((isset($_GET['action']) && 'upgrade-plugin' == $_GET['action']) && (isset($_GET['plugin']) && strstr($_GET['plugin'], 'auto-moto-stock.php'))) {
                return;
            }

            wp_redirect(admin_url('admin.php?page=ams_welcome'));
            exit;
        }

        /**
         * Create page on first activation
         * @param $title
         * @param $content
         * @param $option
         */
        private function create_page($title, $content, $option)
        {
            $page_data = array(
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_author' => 1,
                'post_name' => sanitize_title($title),
                'post_title' => $title,
                'post_content' => $content,
                'post_parent' => 0,
                'comment_status' => 'closed'
            );
            $page_id = wp_insert_post($page_data);
            if ($option) {
                $config = get_option(AMS_OPTIONS_NAME);
                $config[$option] = $page_id;
                update_option(AMS_OPTIONS_NAME, $config);
            }
        }

        /**
         * Output page setup
         */
        public function setup_page()
        {
	        $pages_to_create = AMS_Admin_Setup::get_page_setup_config();
            $step = !empty($_GET['step']) ? absint(wp_unslash($_GET['step'])) : 1;
            if (3 === $step && !empty($_POST)) {
                $create_pages = isset($_POST['ams-create-page']) ? ams_clean(wp_unslash($_POST['ams-create-page']))  : array();
                $page_titles = isset($_POST['ams-page-title']) ? ams_clean(wp_unslash($_POST['ams-page-title']))  : array();
                foreach ($pages_to_create as $page => $v) {
                    if (!isset($create_pages[$page]) || empty($page_titles[$page])) {
                        continue;
                    }
                    $content = isset($v['content']) ? $v['content'] : '';
                    $this->create_page(sanitize_text_field($page_titles[$page]), $content, 'ams_' . $page . '_page_id');
                }
            }
            ?>
            <div class="ams-setup-wrap">
                <h2><?php esc_html_e('Setup Wizard.', 'auto-moto-stock'); ?></h2>
                <ul class="ams-setup-steps">
                    <li class="<?php if ($step === 1) echo 'ams-setup-active-step'; ?>"><?php esc_html_e('1. Introduction', 'auto-moto-stock'); ?></li>
                    <li class="<?php if ($step === 2) echo 'ams-setup-active-step'; ?>"><?php esc_html_e('2. Page Setup', 'auto-moto-stock'); ?></li>
                    <li class="<?php if ($step === 3) echo 'ams-setup-active-step'; ?>"><?php esc_html_e('3. Done', 'auto-moto-stock'); ?></li>
                </ul>

                <?php if (1 === $step) : ?>
                    <h3><?php esc_html_e('Thanks for installing Auto Moto Stock!', 'auto-moto-stock'); ?></h3>

                    <p><?php esc_html_e('This setup wizard will help you get started by creating the pages for vehicle submission, vehicle management, profile management, listing vehicle, listing manager, packages, payment, login, register...', 'auto-moto-stock'); ?></p>
                    <p><?php printf(__('If you want to skip the wizard and setup the pages and shortcodes yourself manually. Refer to the %sdocumentation%s for help.', 'auto-moto-stock'), '<a href="http://document.amsgroup.com/auto-moto-stock">', '</a>'); ?></p>

                    <p class="submit">
                        <a href="<?php echo esc_url(add_query_arg('step', 2)); ?>"
                           class="button button-primary"><?php esc_html_e('Page Setup', 'auto-moto-stock'); ?></a>
                        <a href="<?php echo esc_url(add_query_arg('skip-ams-setup', 1, admin_url('admin.php?page=ams_setup&step=3'))); ?>"
                           class="button"><?php esc_html_e('Skip setup. (Not Recommended)', 'auto-moto-stock'); ?></a>
                    </p>

                <?php endif; ?>
                <?php if (2 === $step) : ?>

                    <h3><?php esc_html_e('Page Setup', 'auto-moto-stock'); ?></h3>

                    <p><?php printf(__('<em>Auto Moto Stock</em> includes %1$sshortcodes%2$s which can be used within your %3$spages%2$s to output content. For more information on the AMS shortcodes view the %4$sshortcode documentation%2$s.', 'auto-moto-stock'), '<a href="https://codex.wordpress.org/shortcode" title="What is a shortcode?" target="_blank" class="help-page-link">', '</a>', '<a href="http://codex.wordpress.org/Pages" target="_blank" class="help-page-link">', '<a href="https://document.amsgroup.com/auto-moto-stock" target="_blank" class="help-page-link">'); ?></p>

                    <form action="<?php echo esc_url(add_query_arg('step', 3)); ?>" method="post">
                        <table class="ams-shortcodes widefat">
                            <thead>
                            <tr>
                                <th>&nbsp;</th>
                                <th><?php esc_html_e('Page Title', 'auto-moto-stock'); ?></th>
                                <th><?php esc_html_e('Page Description', 'auto-moto-stock'); ?></th>
                                <th><?php esc_html_e('Content Shortcode', 'auto-moto-stock'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($pages_to_create as $k => $v): ?>
                                <?php
	                                $title = isset($v['title']) ? $v['title'] : '';
	                                $desc = isset($v['desc']) ? $v['desc'] : '';
	                                $content = isset($v['content']) ? $v['content'] : '';
	                            ?>
	                            <tr>
		                            <td><input type="checkbox" checked="checked" name="ams-create-page[<?php echo esc_attr($k)?>]"/>
		                            </td>
		                            <td><input type="text" value="<?php echo esc_attr($title); ?>" name="ams-page-title[<?php echo esc_attr($k)?>]"/></td>
		                            <td>
			                            <?php if (!empty($desc)): ?>
			                                <p><?php echo esc_html($desc) ?></p>
	                                    <?php endif; ?>
		                            </td>
		                            <td>
			                            <?php if (!empty($content)): ?>
				                            <code><?php echo esc_html($v['content'])?></code>
	                                    <?php endif; ?>
		                            </td>
	                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th colspan="4">
                                    <input type="submit" class="button button-primary" value="<?php esc_html_e('Create selected pages', 'auto-moto-stock'); ?>"/>
                                    <a href="<?php echo esc_url(add_query_arg('step', 3)); ?>"
                                       class="button"><?php esc_html_e('Skip this step', 'auto-moto-stock'); ?></a>
                                </th>
                            </tr>
                            </tfoot>
                        </table>
                    </form>

                <?php endif; ?>
                <?php if (3 === $step) : ?>

                    <h3><?php esc_html_e('All Done!', 'auto-moto-stock'); ?></h3>

                    <p><?php esc_html_e('Looks like you\'re all set to start using the plugin. In case you\'re wondering where to go next:', 'auto-moto-stock'); ?></p>

                    <ul class="ams-next-steps">
                        <li>
                            <a href="<?php echo admin_url('themes.php?page=ams_options'); ?>"><?php esc_html_e('AMS plugin settings', 'auto-moto-stock'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo admin_url('post-new.php?post_type=car'); ?>"><?php esc_html_e('Add a vehicle the back-end', 'auto-moto-stock'); ?></a>
                        </li>
	                    <?php foreach ($pages_to_create as $k => $v): ?>
	                        <?php if ($permalink = ams_get_permalink($k)): ?>
		                        <li><a href="<?php echo esc_url($permalink); ?>"><?php echo ams_get_page_title($k)?></a></li>
		                    <?php endif; ?>
	                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
            <?php
        }

	    public static function get_page_setup_config() {
		    $config =  apply_filters('ams_page_setup_config',array(
			    'submit_car' => array(
				    'title' => 	_x('New Vehicle (Front-End)', 'auto-moto-stock'),
				    'desc' => esc_html__('This page allows users to post vehicle to your website via the front-end.','auto-moto-stock'),
				    'content' => '[ams_submit_car]',
				    'priority' => 10,
			    ),
			    'my_cars' => array(
				    'title' => _x('My Vehicles', 'auto-moto-stock'),
				    'desc' => esc_html__('This page allows users to manage and edit their own vehicle via the front-end.', 'auto-moto-stock'),
				    'content' => '[ams_my_cars]',
				    'priority' => 20,
			    ),
			    'my_profile' => array(
				    'title' => _x('My Profile', 'auto-moto-stock'),
				    'desc' => esc_html__('This page allows users to view and edit their own profile via the front-end.', 'auto-moto-stock'),
				    'content' => '[ams_profile]',
				    'priority' => 30,
			    ),
			    'my_invoices' => array(
				    'title' => _x('My Invoices', 'auto-moto-stock'),
				    'desc' => esc_html__('This page allows users to view their own invoice via the front-end.', 'auto-moto-stock'),
				    'content' => '[ams_my_invoices]',
				    'priority' => 40,
			    ),
			    'my_favorites' =>  array(
				    'title' => _x('My Favorites', 'auto-moto-stock'),
				    'desc' => esc_html__('This page allows users to view their own favorites via the front-end.', 'auto-moto-stock'),
				    'content' => '[ams_my_favorites]',
				    'priority' => 50,
			    ),
			    'my_save_search' =>  array(
				    'title' => _x('My Saved Search', 'auto-moto-stock'),
				    'desc' => esc_html__('This page allows users to view their own "saved search" via the front-end.', 'auto-moto-stock'),
				    'content' => '[ams_my_save_search]',
				    'priority' => 60,
			    ),
			    'packages' => array(
				    'title' => _x('Packages', 'auto-moto-stock'),
				    'desc' => esc_html__('This is packages page.', 'auto-moto-stock'),
				    'content' => '[ams_package]',
				    'priority' => 70,
			    ),
			    'payment' => array(
				    'title' => _x('Payment Invoice', 'auto-moto-stock'),
				    'desc' => esc_html__('This is payment page.', 'auto-moto-stock'),
				    'content' => '[ams_payment]',
				    'priority' => 80,
			    ),
			    'payment_completed' => array(
				    'title' => _x('Payment Completed', 'auto-moto-stock'),
				    'desc' => esc_html__('This is payment completed page.', 'auto-moto-stock'),
				    'content' => '[ams_payment_completed]',
				    'priority' => 90,
			    ),
			    'login' => array(
				    'title' => _x('Login', 'auto-moto-stock'),
				    'desc' => esc_html__('This is login page.', 'auto-moto-stock'),
				    'content' =>  '[ams_login]',
				    'priority' => 100,
			    ),
			    'register' => array(
				    'title' => _x('Register', 'auto-moto-stock'),
				    'desc' => esc_html__('This is register page.', 'auto-moto-stock'),
				    'content' =>  '[ams_register]',
				    'priority' => 110,
			    ),
			    'compare' => array(
				    'title' => _x('Compare', 'auto-moto-stock'),
				    'desc' => esc_html__('This is compare page.', 'auto-moto-stock'),
				    'content' =>  '[ams_compare]',
				    'priority' => 120,
			    ),
			    'advanced_search' =>  array(
				    'title' => _x('Advanced Search', 'auto-moto-stock'),
				    'desc' => esc_html__('This is advanced search page.', 'auto-moto-stock'),
				    'content' =>  '[ams_advanced_search]',
				    'priority' => 130,
			    ),
		    ));
		    uasort( $config, 'ams_sort_by_order_callback' );
		    return $config;
	    }
    }
}