<?php
/**
 * The public-facing functionality of the plugin.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('AMS_Public')) {
    
    /**
     * The public-facing functionality of the plugin
     * Class AMS_Public
     */
    class AMS_Public
    {

		// Loader instances
	    private static $_instance;

	    public static function getInstance()
	    {
		    if (self::$_instance == null) {
			    self::$_instance = new self();
		    }

		    return self::$_instance;
	    }

        // Initialize the class and set its vehicles.
        public function __construct()
        {
            require_once AMS_PLUGIN_DIR . 'public/class-ams-template-hooks.php';
        }

        // Register the stylesheets for the public-facing side of the site.
        public function enqueue_styles()
        {
            $min_suffix = ams_get_option('enable_min_css', 0) == 1 ? '.min' : '';

            wp_enqueue_style('jquery-ui', AMS_PLUGIN_URL . 'public/assets/packages/jquery-ui/jquery-ui.min.css', array(), '1.11.4', 'all');

            wp_enqueue_style('owl.carousel', AMS_PLUGIN_URL . 'public/assets/packages/owl-carousel/assets/owl.carousel.min.css', array(), '2.3.4', 'all');

	        wp_enqueue_style('light-gallery', AMS_PLUGIN_URL . 'public/assets/packages/light-gallery/css/lightgallery.min.css', array(), '1.2.18', 'all');

	        wp_register_style('select2_css', AMS_PLUGIN_URL . 'public/assets/packages/select2/css/select2.min.css', array(), '4.0.6-rc.1', 'all');

            wp_enqueue_style(AMS_PLUGIN_PREFIX . 'main', AMS_PLUGIN_URL . 'public/assets/css/main' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            // Shortcodes
            wp_register_style(AMS_PLUGIN_PREFIX . 'dealer', AMS_PLUGIN_URL . 'public/templates/shortcodes/dealer/assets/css/dealer' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'manager', AMS_PLUGIN_URL . 'public/templates/shortcodes/manager/assets/css/manager' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car', AMS_PLUGIN_URL . 'public/templates/shortcodes/car/assets/css/car' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-carousel', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-carousel/assets/css/car-carousel' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-featured', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-featured/assets/css/car-featured' . $min_suffix . '.css', array('owl.carousel'), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-gallery', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-gallery/assets/css/car-gallery' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'google-map-car', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-map/assets/css/car-map' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-advanced-search', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-advanced-search/assets/css/car-advanced-search' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-search', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-search/assets/css/car-search' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-search-map', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-search-map/assets/css/car-search-map' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-mini-search', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-mini-search/assets/css/car-mini-search' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-slider', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-slider/assets/css/car-slider' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-type', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-type/assets/css/car-type' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-maker', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-maker/assets/css/car-maker' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-model', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-model/assets/css/car-model' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-body', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-body/assets/css/car-body' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            // Widget
            wp_register_style(AMS_PLUGIN_PREFIX . 'listing-car-taxonomy-widget', AMS_PLUGIN_URL . 'public/templates/widgets/listing-car-taxonomy/assets/css/listing-car-taxonomy' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'loan-calculator', AMS_PLUGIN_URL . 'public/templates/widgets/loan-calculator/assets/css/loan-calculator' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'search-form-widget', AMS_PLUGIN_URL . 'public/templates/widgets/search-form/assets/css/search-form' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'top-staff', AMS_PLUGIN_URL . 'public/templates/widgets/top-staff/assets/css/top-staff' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            // Archive, Single
            wp_register_style(AMS_PLUGIN_PREFIX . 'archive-manager', AMS_PLUGIN_URL . 'public/assets/css/archive-manager' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'archive-car', AMS_PLUGIN_URL . 'public/assets/css/archive-car' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'single-manager', AMS_PLUGIN_URL . 'public/assets/css/single-manager' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'single-invoice', AMS_PLUGIN_URL . 'public/assets/css/single-invoice' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'single-car', AMS_PLUGIN_URL . 'public/assets/css/single-car' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'dashboard', AMS_PLUGIN_URL . 'public/assets/css/dashboard' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');

            wp_register_style(AMS_PLUGIN_PREFIX . 'submit-car', AMS_PLUGIN_URL . 'public/assets/css/submit-car' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');
        }

        // Enqueue RTL CSS
        public function enqueue_styles_rtl()
        {
            $min_suffix = ams_get_option('enable_min_css', 0) == 1 ? '.min' : '';

            $enable_rtl_mode = ams_get_option('enable_rtl_mode', 0);

            if (is_rtl() || ($enable_rtl_mode == 1) || isset($_GET['RTL'])) {
                wp_enqueue_style(AMS_PLUGIN_PREFIX . 'rtl', AMS_PLUGIN_URL . 'public/assets/css/rtl' . $min_suffix . '.css', array(), AMS_PLUGIN_VER, 'all');
            }
        }

        // Register the stylesheets for the public-facing side of the site.
        public function enqueue_scripts()
        {
            $min_suffix = ams_get_option('enable_min_js', 0) == 1 ? '.min' : '';
            wp_enqueue_style('bootstrap');

	        wp_enqueue_script('light-gallery', AMS_PLUGIN_URL . 'public/assets/packages/light-gallery/js/lightgallery-all.min.js', array('jquery'), '1.2.18', true);

            wp_register_script('moment', AMS_PLUGIN_URL . 'public/assets/packages/bootstrap/js/moment.min.js', array('jquery'), '2.11.1', true);

            wp_register_script('bootstrap-datetimepicker', AMS_PLUGIN_URL . 'public/assets/packages/bootstrap/js/bootstrap-datetimepicker.min.js', array('jquery', 'moment'), '4.17.42', true);

            wp_register_script('bootstrap-tabcollapse', AMS_PLUGIN_URL . 'public/assets/packages/bootstrap/js/bootstrap-tabcollapse.min.js', array('jquery'), '1.0', true);

            wp_enqueue_script('jquery-validate', AMS_PLUGIN_URL . 'public/assets/js/jquery.validate.min.js', array('jquery'), '1.17.0', true);

            wp_register_script('jquery-geocomplete', AMS_PLUGIN_URL . 'public/assets/js/jquery.geocomplete.min.js', array('jquery'), '1.7.0', true);

            wp_enqueue_script('imagesloaded', AMS_PLUGIN_URL . 'public/assets/js/imagesloaded.pkgd.min.js', array('jquery'), '4.1.3', true);

	        wp_register_script('jquery-ui-touch-punch', AMS_PLUGIN_URL . 'public/assets/packages/jquery-ui/jquery.ui.touch-punch.min.js', array('jquery'), '0.2.3', true);

            $enable_filter_location = ams_get_option('enable_filter_location', 0);

	        wp_register_script('select2_js', AMS_PLUGIN_URL . 'public/assets/packages/select2/js/select2.full.min.js', array('jquery'), '4.0.6-rc.1', true);

            wp_enqueue_script('infobox', AMS_PLUGIN_URL . 'public/assets/js/infobox.min.js', array('jquery', 'google-map'), '1.1.13', true);

            wp_enqueue_script('jquery-core');

            wp_enqueue_script('owl.carousel', AMS_PLUGIN_URL . 'public/assets/packages/owl-carousel/owl.carousel.min.js', array('jquery'), '2.3.4', true);

            $dec_point = ams_get_price_decimal_separator();

            $thousands_sep = ams_get_option('thousand_separator', ',');

	        $decimals = ams_get_option('number_of_decimals', 0);

            $currency = ams_get_option('currency_sign', esc_html__('$', 'auto-moto-stock'));

	        $currency_position = ams_get_option('currency_position', 'before');

	        $ams_main_vars = apply_filters('ams_main_vars', array(
		        'ajax_url' => AMS_AJAX_URL,
		        'confirm_yes_text' => esc_html__('Yes', 'auto-moto-stock'),
		        'confirm_no_text' => esc_html__('No', 'auto-moto-stock'),
		        'loading_text' => esc_html__('Processing, Please wait...', 'auto-moto-stock'),
		        'sending_text' => esc_html__('Sending email, Please wait...', 'auto-moto-stock'),
		        'decimals' => $decimals,
		        'dec_point' => $dec_point,
		        'thousands_sep' => $thousands_sep,
		        'currency' => $currency,
		        'currency_position' => $currency_position
	        ));

	        wp_enqueue_script(AMS_PLUGIN_PREFIX . 'main', AMS_PLUGIN_URL . 'public/assets/js/ams-main' . $min_suffix . '.js', array('jquery', 'wp-util', 'jquery-validate','jquery-ui-core','jquery-ui-slider','jquery-ui-dialog','jquery-ui-sortable','jquery-ui-touch-punch','bootstrap'), AMS_PLUGIN_VER, true);

            wp_localize_script(AMS_PLUGIN_PREFIX . 'main', 'ams_main_vars', $ams_main_vars);

            // Login
            wp_register_script(AMS_PLUGIN_PREFIX . 'login', AMS_PLUGIN_URL . 'public/assets/js/account/ams-login' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

            wp_localize_script(AMS_PLUGIN_PREFIX . 'login', 'ams_login_vars',
                array(
                    'ajax_url' => AMS_AJAX_URL,
                    'loading' => esc_html__('Sending user info, please wait...', 'auto-moto-stock'),
                )
            );

            // Register
            wp_register_script(AMS_PLUGIN_PREFIX . 'register', AMS_PLUGIN_URL . 'public/assets/js/account/ams-register' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

            wp_localize_script(AMS_PLUGIN_PREFIX . 'register', 'ams_register_vars',
                array(
                    'ajax_url' => AMS_AJAX_URL,
                    'loading' => esc_html__('Sending user info, please wait...', 'auto-moto-stock'),
                )
            );

            wp_enqueue_script(AMS_PLUGIN_PREFIX . 'compare', AMS_PLUGIN_URL . 'public/assets/js/car/ams-compare' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

            wp_localize_script(AMS_PLUGIN_PREFIX . 'compare', 'ams_compare_vars',
                array(
                    'ajax_url' => AMS_AJAX_URL,
                    'compare_button_url' => ams_get_permalink('compare'),
                    'alert_title' => esc_html__('Information!', 'auto-moto-stock'),
                    'alert_message' => esc_html__('Only allowed to compare up to 4 vehicles!', 'auto-moto-stock'),
                    'alert_not_found' => esc_html__('Compare Page Not Found!', 'auto-moto-stock')
                )
            );

            // Profile
	        $profile_ajax_upload_url = add_query_arg( 'action', 'ams_profile_image_upload_ajax', AMS_AJAX_URL );

			$profile_ajax_upload_url = add_query_arg( 'nonce', wp_create_nonce('ams_allow_upload_nonce'), $profile_ajax_upload_url );

            wp_register_script(AMS_PLUGIN_PREFIX . 'profile', AMS_PLUGIN_URL . 'public/assets/js/account/ams-profile' . $min_suffix . '.js', array('jquery', 'plupload', 'jquery-validate'), AMS_PLUGIN_VER, true);

            $user_profile_data = array(
                'ajax_url' => AMS_AJAX_URL,
                'ajax_upload_url' => $profile_ajax_upload_url,
                'file_type_title' => esc_html__('Valid file formats', 'auto-moto-stock'),
                'ams_site_url' => site_url(),
                'confirm_become_manager_msg' => esc_html__('Are you sure you want to become an manager.', 'auto-moto-stock'),
                'confirm_leave_manager_msg' => esc_html__('Are you sure you want to leave manager account and comeback normal account.', 'auto-moto-stock'),
            );

            wp_localize_script(AMS_PLUGIN_PREFIX . 'profile', 'ams_profile_vars', $user_profile_data);

            // Vehicle
            wp_register_script(AMS_PLUGIN_PREFIX . 'car', AMS_PLUGIN_URL . 'public/assets/js/car/ams-car' . $min_suffix . '.js', array('jquery', 'plupload', 'jquery-ui-sortable', 'jquery-validate', 'jquery-geocomplete'), AMS_PLUGIN_VER, true);

            $googlemap_zoom_level = ams_get_option('googlemap_zoom_level', '12');

            $google_map_style = ams_get_option('googlemap_style', '');

            $map_icons_path_marker = AMS_PLUGIN_URL . 'public/assets/images/map-marker-icon.png';

            $googlemap_default_country = ams_get_option('default_country', 'US');

	        $googlemap_coordinate_default = ams_get_option('googlemap_coordinate_default', '-33.868419, 151.193245');

            $default_marker = ams_get_option('marker_icon', '');

            if ($default_marker != '') {
                if (is_array($default_marker) && $default_marker['url'] != '') {
                    $map_icons_path_marker = $default_marker['url'];
                }
            }

            $car_upload_nonce = wp_create_nonce('car_allow_upload');

	        $car_ajax_upload_url = add_query_arg( 'action', 'ams_car_img_upload_ajax', AMS_AJAX_URL );

	        $car_ajax_upload_url = add_query_arg( 'nonce', $car_upload_nonce, $car_ajax_upload_url );

	        $car_attachment_ajax_upload_url = add_query_arg( 'action', 'ams_car_attachment_upload_ajax', AMS_AJAX_URL );

	        $car_attachment_ajax_upload_url = add_query_arg( 'nonce', $car_upload_nonce, $car_attachment_ajax_upload_url );

	        $ams_car_vars = apply_filters('ams_car_vars', array(
		        'ajax_url' => AMS_AJAX_URL,
		        'ajax_upload_url' => $car_ajax_upload_url,
		        'ajax_upload_attachment_url' => $car_attachment_ajax_upload_url,
		        'googlemap_zoom_level' => $googlemap_zoom_level,
		        'google_map_style' => $google_map_style,
		        'googlemap_marker_icon' => $map_icons_path_marker,
		        'googlemap_default_country' => $googlemap_default_country,
		        'googlemap_coordinate_default' => $googlemap_coordinate_default,
		        'upload_nonce' => $car_upload_nonce,
		        'file_type_title' => esc_html__('Valid file formats', 'auto-moto-stock'),
		        'max_car_images' => ams_get_option('max_car_images', '10'),
		        'image_max_file_size' => ams_get_option('image_max_file_size', '1000kb'),
		        'max_car_attachments' => ams_get_option('max_car_attachments', '2'),
		        'attachment_max_file_size' => ams_get_option('attachment_max_file_size', '1000kb'),
		        'attachment_file_type' => ams_get_option('attachment_file_type', 'pdf,txt,doc,docx'),
		        'ams_metabox_prefix' => AMS_METABOX_PREFIX,
		        'enable_filter_location'=>$enable_filter_location
	        ));

            wp_localize_script(AMS_PLUGIN_PREFIX . 'car', 'ams_car_vars', $ams_car_vars);

            wp_register_script(AMS_PLUGIN_PREFIX . 'car_steps', AMS_PLUGIN_URL . 'public/assets/js/car/ams-car-steps' . $min_suffix . '.js', array('jquery', 'jquery-validate', AMS_PLUGIN_PREFIX . 'car'), AMS_PLUGIN_VER, true);

            $car_req_fields = ams_get_option('required_fields', array('car_title', 'car_type', 'car_maker', /*'car_model', 'car_body',*/ 'car_price', 'car_map_address'));

            if (!is_array($car_req_fields)) {
                $car_req_fields = array();
            }

            wp_localize_script(AMS_PLUGIN_PREFIX . 'car_steps', 'ams_car_steps_vars', array(
                'car_title' => in_array("car_title", $car_req_fields),
                'car_type' => in_array("car_type", $car_req_fields),
                'car_maker' => in_array("car_maker", $car_req_fields),
                'car_model' => in_array("car_model", $car_req_fields),
                'car_body' => in_array("car_body", $car_req_fields),
                'car_status' => in_array("car_status", $car_req_fields),
                'car_label' => in_array("car_label", $car_req_fields),
                'car_price' => in_array("car_price", $car_req_fields),
                'car_price_prefix' => in_array("car_price_prefix", $car_req_fields),
                'car_price_postfix' => in_array("car_price_postfix", $car_req_fields),
                'car_doors' => in_array("car_doors", $car_req_fields),
                'car_seats' => in_array("car_seats", $car_req_fields),
                'car_condition' => in_array("car_condition", $car_req_fields),
                'car_fuel' => in_array("car_fuel", $car_req_fields),
                'car_transmission' => in_array("car_transmission", $car_req_fields),
                'car_drive' => in_array("car_drive", $car_req_fields),
                'car_owners' => in_array("car_owners", $car_req_fields),
                'car_mileage' => in_array("car_mileage", $car_req_fields),
                'car_power' => in_array("car_power", $car_req_fields),
                'car_volume' => in_array("car_volume", $car_req_fields),
                'car_year' => in_array("car_year", $car_req_fields),
                'car_registration' => in_array("car_registration", $car_req_fields),
                'car_address' => in_array("car_map_address", $car_req_fields),
                'car_country' => in_array("country", $car_req_fields),
                'state' => in_array("state", $car_req_fields),
                'city' => in_array("city", $car_req_fields),
	            'neighborhood' => in_array("neighborhood", $car_req_fields),
                'postal_code' => in_array("postal_code", $car_req_fields),
            ));

            // Payment
            wp_register_script(AMS_PLUGIN_PREFIX . 'payment', AMS_PLUGIN_URL . 'public/assets/js/payment/ams-payment' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

            $payment_data = array(
                'ajax_url' => AMS_AJAX_URL,
                'processing_text' => esc_html__('Processing, Please wait...', 'auto-moto-stock')
            );

            wp_localize_script(AMS_PLUGIN_PREFIX . 'payment', 'ams_payment_vars', $payment_data);

            wp_register_script(AMS_PLUGIN_PREFIX . 'owl_carousel', AMS_PLUGIN_URL . 'public/assets/js/ams-carousel' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

            wp_enqueue_script(AMS_PLUGIN_PREFIX . 'owl_carousel');
            $enable_captcha = ams_get_option('enable_captcha', array());

            if (is_array($enable_captcha) && count($enable_captcha) > 0) {
                $recaptcha_src = esc_url_raw(add_query_arg(array(
                    'render' => 'explicit',
                    'onload' => 'ams_recaptcha_onload_callback'
                ), 'https://www.google.com/recaptcha/api.js'));

                // Enqueue google reCAPTCHA API
                wp_register_script(
                    'ams-google-recaptcha',
                    $recaptcha_src,
                    array(),
                    AMS_PLUGIN_VER,
                    true
                );
            }

            wp_register_script('star-rating', AMS_PLUGIN_URL . 'public/assets/js/star-rating.min.js', array('jquery'), '4.0.3', true);

	        wp_register_script('isotope', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-gallery/assets/js/isotope.pkgd.min.js', array('jquery'), '3.0.6', true);

	        wp_register_script('imageLoaded', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-gallery/assets/js/imagesloaded.pkgd.min.js', array('jquery'), '4.1.4', true);

            // Shortcodes
	        wp_register_script(AMS_PLUGIN_PREFIX . 'search_map', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-search-map/assets/js/car-search-map' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

	        wp_register_script(AMS_PLUGIN_PREFIX . 'search_js_map', AMS_PLUGIN_URL.'public/templates/shortcodes/car-search/assets/js/car-search-map' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

	        wp_register_script(AMS_PLUGIN_PREFIX . 'search_js', AMS_PLUGIN_URL.'public/templates/shortcodes/car-search/assets/js/car-search' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

	        wp_register_script(AMS_PLUGIN_PREFIX . 'car_featured', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-featured/assets/js/car-featured' . $min_suffix . '.js', array('jquery', AMS_PLUGIN_PREFIX . 'owl_carousel'), AMS_PLUGIN_VER, true);

	        wp_register_script(AMS_PLUGIN_PREFIX . 'advanced_search_js', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-advanced-search/assets/js/car-advanced-search' . $min_suffix . '.js', array('jquery'), AMS_PLUGIN_VER, true);

	        wp_register_script(AMS_PLUGIN_PREFIX . 'car_gallery', AMS_PLUGIN_URL . 'public/templates/shortcodes/car-gallery/assets/js/car-gallery' . $min_suffix . '.js', array('jquery','imageLoaded','isotope',AMS_PLUGIN_PREFIX.'owl_carousel'), AMS_PLUGIN_VER, true);
        }

        // Stripe
        public function register_assets() {
            wp_register_script('stripe-checkout','https://checkout.stripe.com/checkout.js',array(),null,true);

            $cdn_bootstrap_css = ams_get_option('cdn_bootstrap_css', '');

            if (!empty($cdn_bootstrap_css)) {
                wp_register_style('bootstrap', $cdn_bootstrap_css);
            } 
            else {
                wp_register_style('bootstrap', AMS_PLUGIN_URL . 'public/assets/packages/bootstrap/css/bootstrap.min.css',array(),'3.4.1');
            }

            $cdn_bootstrap_js = ams_get_option('cdn_bootstrap_js', '');
            if (!empty($cdn_bootstrap_css)) {
                wp_register_script('bootstrap', $cdn_bootstrap_js, array('jquery'),null,true);
            } 
            else {
                wp_register_script('bootstrap', AMS_PLUGIN_URL . 'public/assets/packages/bootstrap/js/bootstrap.min.js', array('jquery'),'3.4.1',true);
            }

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-print', AMS_PLUGIN_URL . '/public/assets/css/car-print.css',array(),AMS_PLUGIN_VER);

            wp_register_style(AMS_PLUGIN_PREFIX . 'car-print-rtl', AMS_PLUGIN_URL . '/public/assets/css/car-print-rtl.css',array(),AMS_PLUGIN_VER);

            wp_register_style(AMS_PLUGIN_PREFIX . 'single-invoice', AMS_PLUGIN_URL . '/public/assets/css/single-invoice.css',array(),AMS_PLUGIN_VER);

            wp_register_style(AMS_PLUGIN_PREFIX . 'invoice-print-rtl', AMS_PLUGIN_URL . '/public/assets/css/invoice-print-rtl.css',array(),AMS_PLUGIN_VER);
        }

        // Register google map api key
        public function register_assets_google_map() {
	        $googlemap_ssl = ams_get_option('googlemap_ssl', 0);

	        $googlemap_api_key = ams_get_option('googlemap_api_key', 'AIzaSyCLyuWY0RUhv7GxftSyI8Ka1VbeU7CTDls');

	        $googlemap_pin_cluster = ams_get_option('googlemap_pin_cluster', 1);

	        if (esc_html($googlemap_ssl) == 1 || is_ssl()) {
		        wp_register_script('google-map', 'https://maps-api-ssl.google.com/maps/api/js?libraries=places&language=' . get_locale() . '&key=' . esc_html($googlemap_api_key), array('jquery'), AMS_PLUGIN_VER, true);
	        } 
            else {
		        wp_register_script('google-map', 'http://maps.googleapis.com/maps/api/js?libraries=places&language=' . get_locale() . '&key=' . esc_html($googlemap_api_key), array('jquery'), AMS_PLUGIN_VER, true);
	        }

	        if ($googlemap_pin_cluster != 0) {
		        wp_register_script('markerclusterer', AMS_PLUGIN_URL . 'public/assets/js/markerclusterer.min.js', array('jquery', 'google-map'), '2.1.1', true);
	        }
        }

        /**
         * Vehicle taxonomy
         * @return bool
         */
        function is_car_taxonomy()
        {
            return is_tax(get_object_taxonomies('car'));
        }

        /**
         * Manager taxonomy
         * @return bool
         */
        function is_manager_taxonomy()
        {
            return is_tax(get_object_taxonomies('manager'));
        }

        /**
         * Loader template
         * @param $template
         * @return string
         */
        public function template_loader($template)
        {
            $find = array();
            $file = '';

            if (is_embed()) {
                return $template;
            }

            if (is_single() && (get_post_type() == 'car' || get_post_type() == 'manager' || get_post_type() == 'invoice')) {
                if (get_post_type() == 'car') {
                    $file = 'single-car.php';
                }

                if (get_post_type() == 'manager') {
                    $file = 'single-manager.php';
                }

                if (get_post_type() == 'invoice') {
                    $file = 'single-invoice.php';
                }

                $find[] = $file;

                $find[] = AMS()->template_path() . $file;

            } 
            elseif ($this->is_car_taxonomy()) {

                $term = get_queried_object();

                if (is_tax('car-type') || is_tax('car-maker') || is_tax('car-model') || is_tax('car-body') || is_tax('car-status') || is_tax('car-exterior') || is_tax('car-interior') || is_tax('car-city') || is_tax('car-state') || is_tax('car-label') || is_tax('car-neighborhood')) {
                    $file = 'taxonomy-' . $term->taxonomy . '.php';
                } 
                else {
                    $file = 'archive-car.php';
                }

                $find[] = 'taxonomy-' . $term->taxonomy . '-' . $term->slug . '.php';

                $find[] = AMS()->template_path() . 'taxonomy-' . $term->taxonomy . '-' . $term->slug . '.php';

                $find[] = 'taxonomy-' . $term->taxonomy . '.php';

                $find[] = AMS()->template_path() . 'taxonomy-' . $term->taxonomy . '.php';

                $find[] = $file;

                $find[] = AMS()->template_path() . $file;

            } 
            elseif ($this->is_manager_taxonomy()) {

                $term = get_queried_object();

                if (is_tax('dealer')) {
                    $file = 'taxonomy-' . $term->taxonomy . '.php';
                } 
                else {
                    $file = 'archive-manager.php';
                }

                $find[] = 'taxonomy-' . $term->taxonomy . '-' . $term->slug . '.php';

                $find[] = AMS()->template_path() . 'taxonomy-' . $term->taxonomy . '-' . $term->slug . '.php';

                $find[] = 'taxonomy-' . $term->taxonomy . '.php';

                $find[] = AMS()->template_path() . 'taxonomy-' . $term->taxonomy . '.php';

                $find[] = $file;

                $find[] = AMS()->template_path() . $file;

            }
             elseif (is_post_type_archive('car') || is_page('cars')) {

                $file = 'archive-car.php';

                $find[] = $file;

                $find[] = AMS()->template_path() . $file;

            } 
            elseif (is_post_type_archive('manager') || is_page('staff')) {

                $file = 'archive-manager.php';

                $find[] = $file;

                $find[] = AMS()->template_path() . $file;
            } 
            elseif (is_author()) {
                $file = 'author.php';

                $find[] = $file;

                $find[] = AMS()->template_path() . $file;
            }

            if ($file) {
                $template = locate_template(array_unique($find));

                if (!$template) {
                    $template = AMS_PLUGIN_DIR . '/public/templates/' . $file;
                }
            }

            return $template;
        }

        /**
         * Set posts per page
         * @param $query
         * @return mixed
         */
        public function set_posts_per_page($query)
        {
            global $wp_the_query;

            if ((!is_admin()) && ($query === $wp_the_query) && ($query->is_archive() || $query->is_tax())) {

                if (is_post_type_archive('manager')) {
                    $archive_manager_item_amount = ams_get_option('archive_manager_item_amount', 12);

                    $query->set('posts_per_page', $archive_manager_item_amount);
                } 
                elseif (is_post_type_archive('car') || is_tax('car-type') || is_tax('car-maker') || is_tax('car-model') || is_tax('car-body') || is_tax('car-status') || is_tax('car-exterior') || is_tax('car-interior')
                    || is_tax('car-label') || is_tax('car-state') || is_tax('car-city') || is_tax('car-neighborhood')) {
                    $custom_car_items_amount = ams_get_option('archive_car_items_amount', 6);

                    $query->set('posts_per_page', $custom_car_items_amount);
                }
            }

            return $query;
        }

        // Print tmpl template
        public function print_tmpl_template() {
	        ams_get_template('global/tmpl-template.php');
        }
    }
}