<?php
if (!defined('ABSPATH')) {
    exit;
}
if (!class_exists('AMS_Search')) {
    /**
     * Class AMS_Search
     */

    class AMS_Search
    {
    	/*
		 * loader instances
		 */
	    private static $_instance;

	    public static function getInstance()
	    {
		    if (self::$_instance == null) {
			    self::$_instance = new self();
		    }

		    return self::$_instance;
	    }

        public function query_all_cars()
        {
            $data = array(
                'post_type' => 'car',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'orderby'   => array(
                    'menu_order'=>'ASC',
                    'date' =>'DESC',
                ),
            );
            $featured_toplist = ams_get_option('featured_toplist', 1);
            if($featured_toplist!=0)
            {
                /*$data['orderby'] = array(
                    'menu_order'=>'ASC',
                    'meta_value_num' => 'DESC',
                    'date' => 'DESC',
                );
                $data['meta_key'] = AMS_METABOX_PREFIX . 'car_featured';*/
	            $data['ams_orderby_featured'] = true;
            }
            return new WP_Query($data);
        }

        /**
         * Vehicle Search Ajax
         */
        public function ams_car_search_ajax()
        {
            check_ajax_referer('ams_search_map_ajax_nonce', 'ams_security_search_map');
            $meta_query = array();
            $tax_query = array();

	        $keyword_array = '';

	        $keyword = isset($_REQUEST['keyword']) ? ams_clean(wp_unslash($_REQUEST['keyword']))  : '';
            $title = isset($_REQUEST['title']) ? ams_clean(wp_unslash($_REQUEST['title']))  : '';
            $address = isset($_REQUEST['address']) ? ams_clean(wp_unslash($_REQUEST['address']))  : '';
            $type = isset($_REQUEST['type']) ?  ams_clean(wp_unslash($_REQUEST['type'])) : '';
            $maker = isset($_REQUEST['maker']) ? ams_clean(wp_unslash($_REQUEST['maker']))  : '';
            $model = isset($_REQUEST['model']) ? ams_clean(wp_unslash($_REQUEST['model']))  : '';
            $body = isset($_REQUEST['body']) ? ams_clean(wp_unslash($_REQUEST['body']))  : '';
            $city = isset($_REQUEST['city']) ? ams_clean(wp_unslash($_REQUEST['city']))  : '';
            $status = isset($_REQUEST['status']) ? ams_clean(wp_unslash($_REQUEST['status']))  : '';
            $owners = isset($_REQUEST['owners']) ? ams_clean(wp_unslash($_REQUEST['owners']))  : '';
            $seats = isset($_REQUEST['seats']) ? ams_clean(wp_unslash($_REQUEST['seats']))  : '';
            $condition = isset($_REQUEST['condition']) ? ams_clean(wp_unslash($_REQUEST['condition']))  : '';
            $fuel = isset($_REQUEST['fuel']) ? ams_clean(wp_unslash($_REQUEST['fuel']))  : '';
            $transmission = isset($_REQUEST['transmission']) ? ams_clean(wp_unslash($_REQUEST['transmission']))  : '';
            $drive = isset($_REQUEST['drive']) ? ams_clean(wp_unslash($_REQUEST['drive']))  : '';
	        $doors = isset($_REQUEST['doors']) ? ams_clean(wp_unslash($_REQUEST['doors']))  : '';
            $min_mileage = isset($_REQUEST['min_mileage']) ? ams_clean(wp_unslash($_REQUEST['min_mileage']))  : '';
            $max_mileage = isset($_REQUEST['max_mileage']) ? ams_clean(wp_unslash($_REQUEST['max_mileage']))  : '';
            $min_price = isset($_REQUEST['min_price']) ? ams_clean(wp_unslash($_REQUEST['min_price']))  : '';
            $max_price = isset($_REQUEST['max_price']) ? ams_clean(wp_unslash($_REQUEST['max_price']))  : '';
            $state = isset($_REQUEST['state']) ? ams_clean(wp_unslash($_REQUEST['state']))  : '';
            $country = isset($_REQUEST['country']) ? ams_clean(wp_unslash($_REQUEST['country']))  : '';
            $neighborhood = isset($_REQUEST['neighborhood']) ? ams_clean(wp_unslash($_REQUEST['neighborhood']))  : '';
            $label = isset($_REQUEST['label']) ? ams_clean(wp_unslash($_REQUEST['label']))  : '';
            $min_power = isset($_REQUEST['min_power']) ? ams_clean(wp_unslash($_REQUEST['min_power']))  : '';
            $max_power = isset($_REQUEST['max_power']) ? ams_clean(wp_unslash($_REQUEST['max_power'])) : '';
            $min_volume = isset($_REQUEST['min_volume']) ? ams_clean(wp_unslash($_REQUEST['min_volume']))  : '';
            $max_volume = isset($_REQUEST['max_volume']) ? ams_clean(wp_unslash($_REQUEST['max_volume'])) : '';
            $car_identity = isset($_REQUEST['car_identity']) ? ams_clean(wp_unslash($_REQUEST['car_identity']))  : '';
            $exteriors = isset($_REQUEST['exteriors']) ? ams_clean(wp_unslash($_REQUEST['exteriors']))  : '';
            if($exteriors != '') {
                $exteriors = explode( ';',$exteriors );
            }
            $interiors = isset($_REQUEST['interiors']) ? ams_clean(wp_unslash($_REQUEST['interiors']))  : '';
            if($interiors != '') {
                $interiors = explode( ';',$interiors );
            }
            $search_type = isset($_REQUEST['search_type']) ? ams_clean(wp_unslash($_REQUEST['search_type']))  : '';

            $query_args = array(
                'post_type' => 'car',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'orderby'   => array(
                    'menu_order'=>'ASC',
                    'date' =>'DESC',
                ),
            );
            $featured_toplist = ams_get_option('featured_toplist', 1);
            if($featured_toplist!=0)
            {
                /*$query_args['orderby'] = array(
                    'menu_order'=>'ASC',
                    'meta_value_num' => 'DESC',
                    'date' => 'DESC',
                );
                $query_args['meta_key'] = AMS_METABOX_PREFIX . 'car_featured';*/
	            $query_args['ams_orderby_featured'] = true;

            }
            if (!empty($address)) {
                $address = sanitize_text_field($address);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_address',
                    'value' => $address,
                    'type' => 'CHAR',
                    'compare' => 'LIKE',
                );
            }
            if (!empty($title)) {
                $query_args['s'] = $title;
            }

            //tax query vehicle type
            if (!empty($type)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-type',
                    'field' => 'slug',
                    'terms' => $type
                );
            }

            //tax query vehicle maker
            if (!empty($maker)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-maker',
                    'field' => 'slug',
                    'terms' => $maker
                );
            }

            //tax query vehicle model
            if (!empty($model)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-model',
                    'field' => 'slug',
                    'terms' => $model
                );
            }

            //tax query vehicle body
            if (!empty($body)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-body',
                    'field' => 'slug',
                    'terms' => $body
                );
            }

            //tax query vehicle status
            if (!empty($status)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-status',
                    'field' => 'slug',
                    'terms' => $status
                );
            }

            //tax query vehicle label
            if (!empty($label)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-label',
                    'field' => 'slug',
                    'terms' => $label
                );
            }

            //city
            if (!empty($city)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-city',
                    'field' => 'slug',
                    'terms' => $city
                );
            }

            //owner
            if (!empty($owners)) {
                $owners = sanitize_text_field($owners);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_owners',
                    'value' => $owners,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // seats
            if (!empty($seats)) {
                $seats = sanitize_text_field($seats);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_seats',
                    'value' => $seats,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // condition
            if (!empty($condition)) {
                $condition = sanitize_text_field($condition);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_condition',
                    'value' => $condition,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // fuel type
            if (!empty($fuel)) {
                $fuel = sanitize_text_field($fuel);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_fuel',
                    'value' => $fuel,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // transmission
            if (!empty($transmission)) {
                $transmission = sanitize_text_field($transmission);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_transmission',
                    'value' => $transmission,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // drive
            if (!empty($drive)) {
                $drive = sanitize_text_field($drive);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_drive',
                    'value' => $drive,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // doors
	        if (!empty($doors)) {
		        $doors = sanitize_text_field($doors);
		        $meta_query[] = array(
			        'key' => AMS_METABOX_PREFIX. 'car_doors',
			        'value' => $doors,
			        'type' => 'CHAR',
			        'compare' => '=',
		        );
	        }

            // min and max price logic
            if (!empty($min_price) && !empty($max_price)) {
                $min_price = doubleval(ams_clean_double_val($min_price));
                $max_price = doubleval(ams_clean_double_val($max_price));

                if ($min_price >= 0 && $max_price >= $min_price) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_price',
                        'value' => array($min_price, $max_price),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }
            } else if (!empty($min_price)) {
                $min_price = doubleval(ams_clean_double_val($min_price));
                if ($min_price >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_price',
                        'value' => $min_price,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            } else if (!empty($max_price)) {
                $max_price = doubleval(ams_clean_double_val($max_price));
                if ($max_price >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX . 'car_price',
                        'value' => $max_price,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            }

            // min and max mileage logic
            if (!empty($min_mileage) && !empty($max_mileage)) {
                $min_mileage = intval($min_mileage);
                $max_mileage = intval($max_mileage);

                if ($min_mileage >= 0 && $max_mileage >= $min_mileage) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_mileage',
                        'value' => array($min_mileage, $max_mileage),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }

            } else if (!empty($max_mileage)) {
                $max_mileage = intval($max_mileage);
                if ($max_mileage >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_mileage',
                        'value' => $max_mileage,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            } else if (!empty($min_mileage)) {
                $min_mileage = intval($min_mileage);
                if ($min_mileage >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_mileage',
                        'value' => $min_mileage,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            }

            // min and max power logic
            if (!empty($min_power) && !empty($max_power)) {
                $min_power = intval($min_power);
                $max_power = intval($max_power);

                if ($min_power >= 0 && $max_power >= $min_power) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_power',
                        'value' => array($min_power, $max_power),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }

            } else if (!empty($max_power)) {
                $max_power = intval($max_power);
                if ($max_power >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_power',
                        'value' => $max_power,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            } else if (!empty($min_power)) {
                $min_power = intval($min_power);
                if ($min_power >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_power',
                        'value' => $min_power,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            }
            // min and max volume logic
            if (!empty($min_volume) && !empty($max_volume)) {
                $min_volume = intval($min_volume);
                $max_volume = intval($max_volume);

                if ($min_volume >= 0 && $max_volume >= $min_volume) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_volume',
                        'value' => array($min_volume, $max_volume),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }

            } else if (!empty($max_volume)) {
                $max_volume = intval($max_volume);
                if ($max_volume >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_volume',
                        'value' => $max_volume,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            } else if (!empty($min_volume)) {
                $min_volume = intval($min_volume);
                if ($min_volume >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_volume',
                        'value' => $min_volume,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            }
            // Country
            if (!empty($country)) {//check value
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_country',
                    'value' => $country,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }
            // Vehicle ID
            if (!empty($car_identity)) {
                $car_identity = sanitize_text_field($car_identity);
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_identity',
                    'value' => $car_identity,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }
            // Search advanced by Province/State
            if (!empty($state)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-state',
                    'field' => 'slug',
                    'terms' => $state
                );
            }
            //Search advanced by neighborhood
            if (!empty($neighborhood)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-neighborhood',
                    'field' => 'slug',
                    'terms' => $neighborhood
                );
            }
            // other exterior query
            if (!empty($exteriors)) {
                foreach($exteriors as $exterior){
                    $tax_query[] = array(
                        'taxonomy' => 'car-exterior',
                        'field' => 'slug',
                        'terms' => $exterior
                    );
                }
            }
            // other interior query
            if (!empty($interiors)) {
                foreach($interiors as $interior){
                    $tax_query[] = array(
                        'taxonomy' => 'car-interior',
                        'field' => 'slug',
                        'terms' => $interior
                    );
                }
            }

	        if ($keyword !== '') {
		        $keyword_field = ams_get_option('keyword_field','veh_address');
		        if ($keyword_field === 'veh_address') {
			        $keyword_array = array(
				        'relation' => 'OR',
				        array(
					        'key' => AMS_METABOX_PREFIX. 'car_address',
					        'value' => $keyword,
					        'type' => 'CHAR',
					        'compare' => 'LIKE',
				        ),
				        array(
					        'key' => AMS_METABOX_PREFIX. 'car_zip',
					        'value' => $keyword,
					        'type' => 'CHAR',
					        'compare' => 'LIKE',
				        ),
				        array(
					        'key' => AMS_METABOX_PREFIX. 'car_identity',
					        'value' => $keyword,
					        'type' => 'CHAR',
					        'compare' => '=',
				        )
			        );
		        } else if ($keyword_field === 'veh_city_state_county') {
			        $taxlocation[] = sanitize_title(wp_kses($_GET['keyword'], array()));
			        $_tax_query = array();
			        $_tax_query['relation'] = 'OR';

			        $_tax_query[] = array(
				        'taxonomy' => 'car-state',
				        'field' => 'slug',
				        'terms' => $taxlocation
			        );

			        $_tax_query[] = array(
				        'taxonomy' => 'car-city',
				        'field' => 'slug',
				        'terms' => $taxlocation
			        );

			        $_tax_query[] = array(
				        'taxonomy' => 'car-neighborhood',
				        'field' => 'slug',
				        'terms' => $taxlocation
			        );

			        $tax_query[] = $_tax_query;
		        } else {
			        $query_args['s'] = $keyword;
		        }
	        }


	        $additional_fields = ams_get_search_additional_fields();
	        foreach ($additional_fields as $id => $title) {
		        $field = ams_get_search_additional_field($id);
		        if ($field === false) {
			        continue;
		        }
		        $field_type = isset($field['field_type']) ? $field['field_type'] : 'text';
		        $field_value = isset($_GET[$id]) ?  wp_unslash( $_GET[$id] ) : '';
		        if (!empty($field_value)) {
			        if ($field_type === 'checkbox_list') {
				        $meta_query[]      = array(
					        'key'     => AMS_METABOX_PREFIX . $id,
					        'value'   => $field_value,
					        'type'    => 'CHAR',
					        'compare' => 'LIKE',
				        );
			        } else {
				        $meta_query[]      = array(
					        'key'     => AMS_METABOX_PREFIX . $id,
					        'value'   => $field_value,
					        'type'    => 'CHAR',
					        'compare' => '=',
				        );
			        }
		        }
	        }



	        $meta_count = count($meta_query);
	        if ($meta_count > 0 || !empty($keyword_array)) {
		        $query_args['meta_query'] = array(
			        'relation' => 'AND',
			        $keyword_array,
			        array(
				        'relation' => 'AND',
				        $meta_query
			        ),
		        );
	        }

            $tax_count = count($tax_query);
            if ($tax_count > 0) {
                $query_args['tax_query'] = array(
                    'relation' => 'AND',
                    $tax_query
                );
            }
	        $query_args = apply_filters('ams_car_search_ajax_query_args',$query_args);
            $the_query = new WP_Query($query_args);
            $cars = array();
            $car_html = '';
            $custom_car_image_size = ams_get_option( 'search_car_image_size', '330x180' );
            $car_item_class = array('car-item');
            if($search_type == 'map_and_content') {
                $car_html = '<div class="list-car-result-ajax">';
            }
            while ($the_query->have_posts()): $the_query->the_post();
                $car_id = get_the_ID();
                $car_location = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_location', true);
                if (!empty($car_location['location'])) {
                    $lat_lng = explode(',', $car_location['location']);
                } else {
                    $lat_lng = array();
                }
                $attach_id = get_post_thumbnail_id();
                $width = 100;
                $height = 100;
                if (!empty($attach_id)) {
                    $image_src = ams_image_resize_id($attach_id, $height, $width, true);
                } else {
                    $image_src= AMS_PLUGIN_URL . 'public/assets/images/no-image.jpg';
                    $default_image=ams_get_option('default_car_image','');
                    if($default_image!='')
                    {
                        $image_src=$default_image['url'];
                    }
                }
                $car_type = get_the_terms($car_id, 'car-type');
                $car_url = '';
                if ($car_type) {
                    $car_type_id = $car_type[0]->term_id;
                    $car_type_icon = get_term_meta($car_type_id, 'car_type_icon', true);
                    if (is_array($car_type_icon) && count($car_type_icon) > 0) {
                        $car_url = $car_type_icon['url'];
                    }
                }

                $car_maker = get_the_terms($car_id, 'car-maker');
                $car_url = '';
                if ($car_maker) {
                    $car_maker_id = $car_maker[0]->term_id;
                    $car_maker_icon = get_term_meta($car_maker_id, 'car_maker_icon', true);
                    if (is_array($car_maker_icon) && count($car_maker_icon) > 0) {
                        $car_url = $car_maker_icon['url'];
                    }
                }

                $car_model = get_the_terms($car_id, 'car-model');
                $car_url = '';
                if ($car_model) {
                    $car_model_id = $car_model[0]->term_id;
                    $car_model_icon = get_term_meta($car_model_id, 'car_model_icon', true);
                    if (is_array($car_model_icon) && count($car_model_icon) > 0) {
                        $car_url = $car_model_icon['url'];
                    }
                }

                $car_body = get_the_terms($car_id, 'car-body');
                $car_url = '';
                if ($car_body) {
                    $car_body_id = $car_body[0]->term_id;
                    $car_body_icon = get_term_meta($car_body_id, 'car_body_icon', true);
                    if (is_array($car_body_icon) && count($car_body_icon) > 0) {
                        $car_url = $car_body_icon['url'];
                    }
                }

                $car_address = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_address', true);
                $cars_price = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_price', true);
                $cars_price = ams_get_format_money($cars_price);
                $veh = new stdClass();
                $veh->image_url = $image_src;
                $veh->title = get_the_title();
                $veh->lat = $lat_lng[0];
                $veh->lng = $lat_lng[1];
                $veh->url = get_permalink();
                $veh->price = $cars_price;
                $veh->address = $car_address;
                if ($car_url == '') {
                    $car_url = AMS_PLUGIN_URL . 'public/assets/images/map-marker-icon.png';
                    $default_marker=ams_get_option('marker_icon','');
                    if($default_marker!='')
                    {
                        if(is_array($default_marker)&& $default_marker['url']!='')
                        {
                            $car_url=$default_marker['url'];
                        }
                    }
                }
                $veh->marker_icon = $car_url;
                array_push($cars, $veh);

                if($search_type == 'map_and_content') {
                    $car_html .= ams_get_template_html('content-car.php', array(
                        'custom_car_image_size' => $custom_car_image_size,
                        'car_item_class' => $car_item_class,
                    ));
                }
            endwhile;
            if($search_type == 'map_and_content') {
                $car_html .= '</div>';
            }
            if (count($cars) > 0) {
                echo json_encode(array('success' => true, 'cars' => $cars, 'car_html' => $car_html));
            } else {
                echo json_encode(array('success' => false));
            }
            wp_reset_postdata();
            die();
        }

        public function ams_car_search_map_ajax()
        {
            check_ajax_referer('ams_search_map_ajax_nonce', 'ams_security_search_map');


            $meta_query = array();
            $tax_query = array();
	        $keyword_array = '';

	        $keyword = isset($_REQUEST['keyword']) ? ams_clean(wp_unslash($_REQUEST['keyword']))  : '';
            $title = isset($_REQUEST['title']) ? ams_clean(wp_unslash($_REQUEST['title']))  : '';
            $address = isset($_REQUEST['address']) ? ams_clean(wp_unslash($_REQUEST['address']))  : '';
            $type = isset($_REQUEST['type']) ? ams_clean(wp_unslash($_REQUEST['type']))  : '';
            $maker = isset($_REQUEST['maker']) ? ams_clean(wp_unslash($_REQUEST['maker']))  : '';
            $model = isset($_REQUEST['model']) ? ams_clean(wp_unslash($_REQUEST['model']))  : '';
            $body = isset($_REQUEST['body']) ? ams_clean(wp_unslash($_REQUEST['body']))  : '';
            $city = isset($_REQUEST['city']) ? ams_clean(wp_unslash($_REQUEST['city']))  : '';
            $status = isset($_REQUEST['status']) ? ams_clean(wp_unslash($_REQUEST['status']))  : '';
	        $doors = isset($_REQUEST['doors']) ? ams_clean(wp_unslash($_REQUEST['doors']))  : '';
            $owners = isset($_REQUEST['owners']) ? ams_clean(wp_unslash($_REQUEST['owners']))  : '';
            $seats = isset($_REQUEST['seats']) ? ams_clean(wp_unslash($_REQUEST['seats']))  : '';
            $condition = isset($_REQUEST['condition']) ? ams_clean(wp_unslash($_REQUEST['condition']))  : '';
            $fuel = isset($_REQUEST['fuel']) ? ams_clean(wp_unslash($_REQUEST['fuel']))  : '';
            $transmission = isset($_REQUEST['transmission']) ? ams_clean(wp_unslash($_REQUEST['transmission']))  : '';
            $drive = isset($_REQUEST['drive']) ? ams_clean(wp_unslash($_REQUEST['drive']))  : '';
            $min_mileage = isset($_REQUEST['min_mileage']) ? ams_clean(wp_unslash($_REQUEST['min_mileage']))  : '';
            $max_mileage = isset($_REQUEST['max_mileage']) ? ams_clean(wp_unslash($_REQUEST['max_mileage'])) : '';
            $min_price = isset($_REQUEST['min_price']) ? ams_clean(wp_unslash($_REQUEST['min_price'])) : '';
            $max_price = isset($_REQUEST['max_price']) ? ams_clean(wp_unslash($_REQUEST['max_price'])) : '';
            $state = isset($_REQUEST['state']) ? ams_clean(wp_unslash($_REQUEST['state'])) : '';
            $country = isset($_REQUEST['country']) ? ams_clean(wp_unslash($_REQUEST['country'])) : '';
            $neighborhood = isset($_REQUEST['neighborhood']) ? ams_clean(wp_unslash($_REQUEST['neighborhood'])) : '';
            $label = isset($_REQUEST['label']) ? ams_clean(wp_unslash($_REQUEST['label'])) : '';
            $min_power = isset($_REQUEST['min_power']) ? ams_clean(wp_unslash($_REQUEST['min_power'])) : '';
            $max_power = isset($_REQUEST['max_power']) ? ams_clean(wp_unslash($_REQUEST['max_power'])) : '';
            $min_volume = isset($_REQUEST['min_volume']) ? ams_clean(wp_unslash($_REQUEST['min_volume'])) : '';
            $max_volume = isset($_REQUEST['max_volume']) ? ams_clean(wp_unslash($_REQUEST['max_volume'])) : '';
            $car_identity = isset($_REQUEST['car_identity']) ? ams_clean(wp_unslash($_REQUEST['car_identity'])) : '';
            $exteriors = isset($_REQUEST['exteriors']) ? ams_clean(wp_unslash($_REQUEST['exteriors'])) : '';
            if($exteriors != '') {
                $exteriors = explode( ';',$exteriors );
            }
            $interiors = isset($_REQUEST['interiors']) ? ams_clean(wp_unslash($_REQUEST['interiors'])) : '';
            if($interiors != '') {
                $interiors = explode( ';',$interiors );
            }
            $search_type = isset($_REQUEST['search_type']) ? ams_clean(wp_unslash($_REQUEST['search_type'])) : '';
            $paged = isset($_REQUEST['paged']) ? ams_clean(wp_unslash($_REQUEST['paged'])) : '1';
            $item_amount = isset($_REQUEST['item_amount']) ? ams_clean(wp_unslash($_REQUEST['item_amount'])) : '18';
            $marker_image_size = isset($_REQUEST['marker_image_size']) ? ams_clean(wp_unslash($_REQUEST['marker_image_size'])) : '100x100';
            $query_args = array(
                'posts_per_page' => ($item_amount > 0) ? $item_amount : -1,
                'post_type' => 'car',
                'paged' => $paged,
                'post_status' => 'publish',
                'orderby'   => array(
                    'menu_order'=>'ASC',
                    'date' =>'DESC',
                ),
            );
            $featured_toplist = ams_get_option('featured_toplist', 1);
            if($featured_toplist!=0)
            {
                /*$query_args['orderby'] = array(
                    'menu_order'=>'ASC',
                    'meta_value_num' => 'DESC',
                    'date' => 'DESC',
                );
                $query_args['meta_key'] = AMS_METABOX_PREFIX . 'car_featured';*/

	           $query_args['ams_orderby_featured'] = true;
            }
            if (!empty($address)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_address',
                    'value' => $address,
                    'type' => 'CHAR',
                    'compare' => 'LIKE',
                );
            }
            if (!empty($title)) {
                $query_args['s'] = $title;
            }

            //tax query vehicle type
            if (!empty($type)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-type',
                    'field' => 'slug',
                    'terms' => $type
                );
            }

            //tax query vehicle maker
            if (!empty($maker)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-maker',
                    'field' => 'slug',
                    'terms' => $maker
                );
            }

            //tax query vehicle model
            if (!empty($model)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-model',
                    'field' => 'slug',
                    'terms' => $model
                );
            }

            //tax query vehicle body
            if (!empty($body)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-body',
                    'field' => 'slug',
                    'terms' => $body
                );
            }

            //tax query vehicle status
            if (!empty($status)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-status',
                    'field' => 'slug',
                    'terms' => $status
                );
            }

            //tax query vehicle label
            if (!empty($label)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-label',
                    'field' => 'slug',
                    'terms' => $label
                );
            }

            //city
            if (!empty($city)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-city',
                    'field' => 'slug',
                    'terms' => $city
                );
            }

            //owner
            if (!empty($owners)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_owners',
                    'value' => $owners,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // seats
            if (!empty($seats)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_seats',
                    'value' => $seats,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // condition
            if (!empty($condition)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_condition',
                    'value' => $condition,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // fuel type
            if (!empty($fuel)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_fuel',
                    'value' => $fuel,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // transmission
            if (!empty($transmission)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_transmission',
                    'value' => $transmission,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // drive
            if (!empty($drive)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_drive',
                    'value' => $drive,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }

            // doors
	        if (!empty($doors)) {
		        $meta_query[] = array(
			        'key' => AMS_METABOX_PREFIX. 'car_doors',
			        'value' => $doors,
			        'type' => 'CHAR',
			        'compare' => '=',
		        );
	        }

            // min and max price logic
            if (!empty($min_price) && !empty($max_price)) {
                $min_price = doubleval(ams_clean_double_val($min_price));
                $max_price = doubleval(ams_clean_double_val($max_price));

                if ($min_price >= 0 && $max_price >= $min_price) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_price',
                        'value' => array($min_price, $max_price),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }
            } else if (!empty($min_price)) {
                $min_price = doubleval(ams_clean_double_val($min_price));
                if ($min_price >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_price',
                        'value' => $min_price,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            } else if (!empty($max_price)) {
                $max_price = doubleval(ams_clean_double_val($max_price));
                if ($max_price >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX . 'car_price',
                        'value' => $max_price,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            }

            // min and max mileage logic
            if (!empty($min_mileage) && !empty($max_mileage)) {
                $min_mileage = intval($min_mileage);
                $max_mileage = intval($max_mileage);

                if ($min_mileage >= 0 && $max_mileage >= $min_mileage) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_mileage',
                        'value' => array($min_mileage, $max_mileage),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }

            } else if (!empty($max_mileage)) {
                $max_mileage = intval($max_mileage);
                if ($max_mileage >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_mileage',
                        'value' => $max_mileage,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            } else if (!empty($min_mileage)) {
                $min_mileage = intval($min_mileage);
                if ($min_mileage >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_mileage',
                        'value' => $min_mileage,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            }

            // min and max power logic
            if (!empty($min_power) && !empty($max_power)) {
                $min_power = intval($min_power);
                $max_power = intval($max_power);

                if ($min_power >= 0 && $max_power >= $min_power) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_power',
                        'value' => array($min_power, $max_power),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }

            } else if (!empty($max_power)) {
                $max_power = intval($max_power);
                if ($max_power >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_power',
                        'value' => $max_power,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            } else if (!empty($min_power)) {
                $min_power = intval($min_power);
                if ($min_power >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_power',
                        'value' => $min_power,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            }
            // min and max volume logic
            if (!empty($min_volume) && !empty($max_volume)) {
                $min_volume = intval($min_volume);
                $max_volume = intval($max_volume);

                if ($min_volume >= 0 && $max_volume >= $min_volume) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_volume',
                        'value' => array($min_volume, $max_volume),
                        'type' => 'NUMERIC',
                        'compare' => 'BETWEEN',
                    );
                }

            } else if (!empty($max_volume)) {
                $max_volume = intval($max_volume);
                if ($max_volume >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_volume',
                        'value' => $max_volume,
                        'type' => 'NUMERIC',
                        'compare' => '<=',
                    );
                }
            } else if (!empty($min_volume)) {
                $min_volume = intval($min_volume);
                if ($min_volume >= 0) {
                    $meta_query[] = array(
                        'key' => AMS_METABOX_PREFIX. 'car_volume',
                        'value' => $min_volume,
                        'type' => 'NUMERIC',
                        'compare' => '>=',
                    );
                }
            }
            // Country
            if (!empty($country)) {//check value
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_country',
                    'value' => $country,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }
            // Identity
            if (!empty($car_identity)) {
                $meta_query[] = array(
                    'key' => AMS_METABOX_PREFIX. 'car_identity',
                    'value' => $car_identity,
                    'type' => 'CHAR',
                    'compare' => '=',
                );
            }
            // Search advanced by Province/State
            if (!empty($state)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-state',
                    'field' => 'slug',
                    'terms' => $state
                );
            }
            // Search advanced by neighborhood
            if (!empty($neighborhood)) {
                $tax_query[] = array(
                    'taxonomy' => 'car-neighborhood',
                    'field' => 'slug',
                    'terms' => $neighborhood
                );
            }
            // other exterior query
            if (!empty($exteriors)) {
                foreach($exteriors as $exterior){
                    $tax_query[] = array(
                        'taxonomy' => 'car-exterior',
                        'field' => 'slug',
                        'terms' => $exterior
                    );
                }
            }
            // other interior query
            if (!empty($interiors)) {
                foreach($interiors as $interior){
                    $tax_query[] = array(
                        'taxonomy' => 'car-interior',
                        'field' => 'slug',
                        'terms' => $interior
                    );
                }
            }

	        if ($keyword !== '') {
		        $keyword_field = ams_get_option('keyword_field','veh_address');
		        if ($keyword_field === 'veh_address') {
			        $keyword_array = array(
				        'relation' => 'OR',
				        array(
					        'key' => AMS_METABOX_PREFIX. 'car_address',
					        'value' => $keyword,
					        'type' => 'CHAR',
					        'compare' => 'LIKE',
				        ),
				        array(
					        'key' => AMS_METABOX_PREFIX. 'car_zip',
					        'value' => $keyword,
					        'type' => 'CHAR',
					        'compare' => 'LIKE',
				        ),
				        array(
					        'key' => AMS_METABOX_PREFIX. 'car_identity',
					        'value' => $keyword,
					        'type' => 'CHAR',
					        'compare' => '=',
				        )
			        );
		        } else if ($keyword_field === 'veh_city_state_county') {
			        $taxlocation[] = sanitize_title(wp_kses($_GET['keyword'], array()));
			        $_tax_query = array();
			        $_tax_query['relation'] = 'OR';

			        $_tax_query[] = array(
				        'taxonomy' => 'car-state',
				        'field' => 'slug',
				        'terms' => $taxlocation
			        );

			        $_tax_query[] = array(
				        'taxonomy' => 'car-city',
				        'field' => 'slug',
				        'terms' => $taxlocation
			        );

			        $_tax_query[] = array(
				        'taxonomy' => 'car-neighborhood',
				        'field' => 'slug',
				        'terms' => $taxlocation
			        );

			        $tax_query[] = $_tax_query;
		        } else {
			        $query_args['s'] = $keyword;
		        }
	        }

	        $additional_fields = ams_get_search_additional_fields();
	        foreach ($additional_fields as $id => $title) {
		        $field = ams_get_search_additional_field($id);
		        if ($field === false) {
			        continue;
		        }
		        $field_type = isset($field['field_type']) ? $field['field_type'] : 'text';
		        $field_value = isset($_GET[$id]) ?  wp_unslash( $_GET[$id] ) : '';
		        if (!empty($field_value)) {
			        if ($field_type === 'checkbox_list') {
				        $meta_query[]      = array(
					        'key'     => AMS_METABOX_PREFIX . $id,
					        'value'   => $field_value,
					        'type'    => 'CHAR',
					        'compare' => 'LIKE',
				        );
			        } else {
				        $meta_query[]      = array(
					        'key'     => AMS_METABOX_PREFIX . $id,
					        'value'   => $field_value,
					        'type'    => 'CHAR',
					        'compare' => '=',
				        );
			        }
		        }
	        }


	        $meta_count = count($meta_query);
	        if ($meta_count > 0 || !empty($keyword_array)) {
		        $query_args['meta_query'] = array(
			        'relation' => 'AND',
			        $keyword_array,
			        array(
				        'relation' => 'AND',
				        $meta_query
			        ),
		        );
	        }

            $tax_count = count($tax_query);
            if ($tax_count > 0) {
                $query_args['tax_query'] = array(
                    'relation' => 'AND',
                    $tax_query
                );
            }
	        $query_args = apply_filters('ams_car_search_map_ajax_query_args',$query_args);
            $data = new WP_Query($query_args);
            $cars = array();
            $total_post = $data->found_posts;
	        ob_start();
            if($total_post > 0){
                $custom_car_image_size = '370x220';
                $car_item_class = array('car-item ams-item-wrap');

                if ($search_type == 'map_and_content') {
                    ?>
                    <div class="list-car-result-ajax">
                    <?php
                }
                ?>
                <div class="ams-car clearfix car-grid car-vertical-map-listing col-gap-10 columns-3 columns-md-3 columns-sm-2 columns-xs-1 columns-mb-1">
                <?php
                $default_image=ams_get_option('default_car_image','');
                while ($data->have_posts()): $data->the_post();
                    $car_id = get_the_ID();
                    $car_location = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_location', true);
                    if (!empty($car_location['location'])) {
                        $lat_lng = explode(',', $car_location['location']);
                    } else {
                        $lat_lng = array();
                    }
                    $attach_id = get_post_thumbnail_id();
                    if (preg_match('/\d+x\d+/', $marker_image_size)) {
                        $image_sizes = explode('x', $marker_image_size);
                        $width=$image_sizes[0];$height= $image_sizes[1];
                        $image_src = ams_image_resize_id($attach_id, $width, $height, true);
                    } else {
                        if (!in_array($marker_image_size, array('full', 'thumbnail'))) {
                            $marker_image_size = 'full';
                        }
                        $image_src_arr = wp_get_attachment_image_src($attach_id, $marker_image_size);
                        if (is_array($image_src_arr)) {
                        	$image_src = $image_src_arr[0];
                        }
                    }

                    //$marker_image_size
                    $car_type = get_the_terms($car_id, 'car-type');
                    $car_url = '';
                    if ($car_type) {
                        $car_type_id = $car_type[0]->term_id;
                        $car_type_icon = get_term_meta($car_type_id, 'car_type_icon', true);
                        if (is_array($car_type_icon) && count($car_type_icon) > 0) {
                            $car_url = $car_type_icon['url'];
                        }
                    }

                    $car_maker = get_the_terms($car_id, 'car-maker');
                    $car_url = '';
                    if ($car_maker) {
                        $car_maker_id = $car_maker[0]->term_id;
                        $car_maker_icon = get_term_meta($car_maker_id, 'car_maker_icon', true);
                        if (is_array($car_maker_icon) && count($car_maker_icon) > 0) {
                           $car_url = $car_maker_icon['url'];
                    }
                }

                    $car_model = get_the_terms($car_id, 'car-model');
                    $car_url = '';
                    if ($car_model) {
                        $car_model_id = $car_model[0]->term_id;
                        $car_model_icon = get_term_meta($car_model_id, 'car_model_icon', true);
                        if (is_array($car_model_icon) && count($car_model_icon) > 0) {
                            $car_url = $car_model_icon['url'];
                    }
                }

                    $car_body = get_the_terms($car_id, 'car-body');
                    $car_url = '';
                    if ($car_body) {
                        $car_body_id = $car_body[0]->term_id;
                        $car_body_icon = get_term_meta($car_body_id, 'car_body_icon', true);
                        if (is_array($car_body_icon) && count($car_body_icon) > 0) {
                            $car_url = $car_body_icon['url'];
                    }
                }

                    $car_address = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_address', true);
                    $cars_price = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_price', true);
                    $cars_price = ams_get_format_money($cars_price);
                    $veh = new stdClass();
                    $veh->image_url = $image_src;
                    $veh->title = get_the_title();
                    $veh->lat = $lat_lng[0];
                    $veh->lng = $lat_lng[1];
                    $veh->url = get_permalink();
                    $veh->price = $cars_price;
                    $veh->address = $car_address;
                    if ($car_url == '') {
                        $car_url = AMS_PLUGIN_URL . 'public/assets/images/map-marker-icon.png';
                        $default_marker=ams_get_option('marker_icon','');
                        if($default_marker!='')
                        {
                            if(is_array($default_marker)&& $default_marker['url']!='')
                            {
                                $car_url=$default_marker['url'];
                            }
                        }
                    }
                    $veh->marker_icon = $car_url;
                    array_push($cars, $veh);
                    if ($search_type == 'map_and_content') {
                        ams_get_template('content-car.php', array(
                            'custom_car_image_size' => $custom_car_image_size,
                            'car_item_class' => $car_item_class,
                        ));
                    }
                endwhile;?>
                </div>
                <div class="car-search-map-paging-wrap">
                    <?php $max_num_pages = $data->max_num_pages;
                    set_query_var('paged', $paged);
                    ams_get_template('global/pagination.php', array('max_num_pages' => $max_num_pages));
                    ?>
                </div>
                <?php
                if ($search_type == 'map_and_content') {?>
                    </div><?php
                }
            }
            wp_reset_postdata();
            $car_html = ob_get_clean();
            if (count($cars) > 0) {
                echo json_encode(array('success' => true, 'cars' => $cars, 'car_html' => $car_html,'total_post'=>$total_post));
            } else {
                echo json_encode(array('success' => false));
            }
            die();
        }

        public function ams_ajax_change_price_on_status_change()
        {
            $slide_html=$min_price_html=$max_price_html='';
            $request_status = isset($_POST['status']) ? ams_clean(wp_unslash($_POST['status']))  : '';
            $price_is_slider = isset($_POST['price_is_slider']) ? ams_clean(wp_unslash($_POST['price_is_slider']))  : '';
            if (!empty($price_is_slider)&& $price_is_slider=='true') {
	            $min_price = ams_get_option('car_price_slider_min',200);
	            $max_price = ams_get_option('car_price_slider_max',2500000);
	            if ($request_status !== '') {
		            $car_price_slider_search_field = ams_get_option('car_price_slider_search_field', '');
		            if ($car_price_slider_search_field != '') {
			            foreach ($car_price_slider_search_field as $data) {
				            $term_id = (isset($data['car_price_slider_car_status']) ? $data['car_price_slider_car_status'] : '');
				            $term = get_term_by('id', $term_id, 'car-status');
				            if ($term->slug == $request_status) {
					            $min_price = (isset($data['car_price_slider_min']) ? $data['car_price_slider_min'] : $min_price);
					            $max_price = (isset($data['car_price_slider_max']) ? $data['car_price_slider_max'] : $max_price);
					            break;
				            }
			            }
		            }
	            }

                $min_price_change = $min_price;
                $max_price_change = $max_price;
                $slide_html='<div class="ams-sliderbar-price ams-sliderbar-filter" data-min-default="'. $min_price.'" data-max-default="'.$max_price.'" data-min="'.$min_price_change.'" data-max="'.$max_price_change.'">
                    <div class="title-slider-filter">'. esc_html__('Price', 'auto-moto-stock').'[<span class="min-value">'. ams_get_format_money($min_price_change).'</span> - <span class="max-value">'. ams_get_format_money($max_price_change).'</span>]
                        <input type="hidden" name="min-price" class="min-input-request"
                               value="'. esc_attr($min_price_change) .'">
                        <input type="hidden" name="max-price" class="max-input-request"
                               value="'. esc_attr($max_price_change).'">
                    </div>
                    <div class="sidebar-filter"></div>
                </div>';
            }
            else
            {
	            $car_price_dropdown_min= apply_filters('ams_price_dropdown_min_default', ams_get_option('car_price_dropdown_min','0,100,300,500,700,900,1100,1300,1500,1700,1900')) ;
	            $car_price_dropdown_max= apply_filters('ams_price_dropdown_max_default', ams_get_option('car_price_dropdown_max','200,400,600,800,1000,1200,1400,1600,1800,2000')) ;
                $car_price_dropdown_search_field = ams_get_option('car_price_dropdown_search_field','');
                if ($car_price_dropdown_search_field != '') {
                    foreach ($car_price_dropdown_search_field as $data) {
                        $term_id =(isset($data['car_price_dropdown_car_status']) ? $data['car_price_dropdown_car_status'] : '');
                        $term = get_term_by('id', $term_id, 'car-status');
                        if($term->slug==$request_status)
                        {
                            $car_price_dropdown_min = (isset($data['car_price_dropdown_min']) ? $data['car_price_dropdown_min'] : $car_price_dropdown_min);
                            $car_price_dropdown_max = (isset($data['car_price_dropdown_max']) ? $data['car_price_dropdown_max'] : $car_price_dropdown_max);
                            break;
                        }
                    }
                }
                $min_price_html='<option value="">'.esc_html__('Min Price', 'auto-moto-stock').'</option>';
                $car_price_array_min = explode(',', $car_price_dropdown_min);
                if (is_array($car_price_array_min) && !empty($car_price_array_min)) {
                    foreach ($car_price_array_min as $n) {
                        $min_price_html.='<option value="'. esc_attr($n) .'">';
                        $min_price_html.=ams_get_format_money_search_field($n).'</option>';
                    }
                }
                $max_price_html='<option value="">'.esc_html__('Max Price', 'auto-moto-stock').'</option>';
                $car_price_array_max = explode(',', $car_price_dropdown_max);
                if (is_array($car_price_array_max) && !empty($car_price_array_max)) {
                    foreach ($car_price_array_max as $n) {
                        $max_price_html.='<option value="'. esc_attr($n) .'">';
                        $max_price_html.=ams_get_format_money_search_field($n).'</option>';
                    }
                }
            }
            echo json_encode(array('slide_html' => $slide_html, 'min_price_html' => $min_price_html, 'max_price_html' => $max_price_html));
            die();
        }
    }
}