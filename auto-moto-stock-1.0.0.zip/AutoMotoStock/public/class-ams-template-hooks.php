<?php

/**
 * Register all actions and filters for the plugin
 *
 * @link       https://auto-moto-stock.com
 * @since      1.0.0
 *
 * @package    Auto_Moto_Stock
 * @subpackage Auto_Moto_Stock/includes
 */
if (!defined('ABSPATH')) {
    exit;
}
    /**
     * Class AMS_Template_Hooks
     */
if (!class_exists('AMS_Template_Hooks')) {
   
    require_once AMS_PLUGIN_DIR . 'includes/class-ams-loader.php';

    class AMS_Template_Hooks
    {
        protected $loader;

        /**
         * Instance variable for singleton pattern
         */
        private static $instance = null;

        /**
         * Return class instance
         * @return AMS_Template_Hooks|null
         */
        public static function get_instance()
        {
            if (null == self::$instance) {
                self::$instance = new self;
            }
            return self::$instance;
        }

        public function __construct()
        {
            $this->loader = new AMS_Loader();
            $this->loader->add_action('ams_before_main_content', $this, 'output_content_wrapper_start', 10);
            $this->loader->add_action('ams_after_main_content', $this, 'output_content_wrapper_end', 10);          
            // Vehicle Sidebar
            $this->loader->add_action('ams_sidebar_car', $this, 'sidebar_car', 10);
            $this->loader->add_action('ams_sidebar_manager', $this, 'sidebar_manager', 10);
            $this->loader->add_action('ams_sidebar_invoice', $this, 'sidebar_invoice', 10);
            //Archive Vehicle
            $this->loader->add_action('ams_archive_car_before_main_content', $this, 'archive_car_search', 10);
            $this->loader->add_action('ams_archive_car_heading', $this, 'archive_car_heading', 10, 4);
            $this->loader->add_action('ams_archive_car_action', $this, 'archive_car_action', 10, 1);
            $this->loader->add_action('ams_loop_car', $this, 'loop_car', 10, 4);
            //Advanced Search
            $this->loader->add_action('ams_advanced_search_before_main_content', $this, 'advanced_car_search', 10);
            //Archive Manager
            $this->loader->add_action('ams_archive_manager_heading', $this, 'archive_manager_heading', 10, 1);
            $this->loader->add_action('ams_archive_manager_action', $this, 'archive_manager_action', 10, 1);
            $this->loader->add_action('ams_loop_manager', $this, 'loop_manager', 10, 3);
            //Single Vehicle
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_header', 5);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_gallery', 10);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_description', 15);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_location', 20);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_exteriors', 25);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_interiors', 30);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_attachments', 35);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_map_directions', 40);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_nearby_places', 45);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_walk_score', 50);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_contact_manager', 55);
            $this->loader->add_action('ams_single_car_summary', $this, 'single_car_footer', 90);

            //Comment Reviws
            $enable_comments_reviews_car = ams_get_option('enable_comments_reviews_car', 1);
            if ($enable_comments_reviews_car == 1) {
                $this->loader->add_action('ams_single_car_after_summary', $this, 'comments_template', 95);
            }
            if ($enable_comments_reviews_car == 2) {
                $this->loader->add_action('ams_single_car_summary', $this, 'single_car_reviews', 95);
            }

            //Single Manager
            $this->loader->add_action('ams_single_manager_summary', $this, 'single_manager_info', 5);

            $enable_comments_reviews_manager = ams_get_option('enable_comments_reviews_manager', 0);
            if ($enable_comments_reviews_manager == 1) {
                $this->loader->add_action('ams_single_manager_summary', $this, 'comments_template', 15);
            }
            if ($enable_comments_reviews_manager == 2) {
                $this->loader->add_action('ams_single_manager_summary', $this, 'single_manager_reviews', 15);
            }
            $this->loader->add_action('ams_single_manager_summary', $this, 'single_manager_car', 20);
            $this->loader->add_action('ams_single_manager_summary', $this, 'single_manager_other', 30);

            //Author
            $this->loader->add_action('ams_author_summary', $this, 'author_info', 5);
            $this->loader->add_action('ams_author_summary', $this, 'author_car', 10);

            //Single Invoice
            $this->loader->add_action('ams_single_invoice_summary', $this, 'single_invoice', 10);
            //Taxonomy
            $this->loader->add_action('ams_taxonomy_dealer_summary', $this, 'taxonomy_dealer_detail', 10);
            $this->loader->add_action('ams_taxonomy_dealer_staff', $this, 'taxonomy_dealer_staff', 10, 1);
            //Vehicle Action
            $this->loader->add_action('ams_car_action', $this, 'car_view_gallery', 5);
            $this->loader->add_action('ams_car_action', $this, 'car_favorite', 10);
            $this->loader->add_action('ams_car_action', $this, 'car_compare', 15);

	        add_action( 'pre_get_posts', array( $this, 'order_by_featured_pre_get_posts' ),99 );
	        add_action( 'pre_get_posts', array( $this, 'order_by_viewed_pre_get_posts' ),99 );
            $this->loader->run();
        }

        /**
         * output_content_wrapper
         */
        public function output_content_wrapper_start()
        {
            ams_get_template('global/wrapper-start.php');
        }

        /**
         * output_content_wrapper
         */
        public function output_content_wrapper_end()
        {
            ams_get_template('global/wrapper-end.php');
        }

        /**
         * archive_car_search
         */
        public function archive_car_search()
        {
            $enable_archive_search_form = ams_get_option('enable_archive_search_form', '0');
            if ($enable_archive_search_form == '1'){
                ams_get_template('archive-car/search-form.php');
            }
        }

        /**
         * advanced_car_search
         */
        public function advanced_car_search()
        {
            $enable_advanced_search_form = ams_get_option('enable_advanced_search_form', '1');
            if ($enable_advanced_search_form == '1') {
	            $additional_fields = ams_get_search_additional_fields();
	            $additional_fields_attr = array();
	            foreach ($additional_fields as $k => $v) {
		            $additional_fields_attr[] = sprintf('%s_enable="true"',$k);
	            }
	            $additional_fields_attr = implode(' ', $additional_fields_attr);

                $car_price_field_layout = ams_get_option('advanced_search_price_field_layout', '0');
                $car_mileage_field_layout = ams_get_option('advanced_search_size_field_layout', '0');
                $car_power_field_layout = ams_get_option('advanced_search_power_field_layout', '0');
                $car_volume_field_layout = ams_get_option('advanced_search_volume_field_layout', '0');

                echo do_shortcode('[ams_car_advanced_search layout="tab" column="3" color_scheme="color-dark" status_enable="true" type_enable="true" maker_enable="true" model_enable="true" body_enable="true" keyword_enable="true" title_enable="true" address_enable="true" country_enable="true" state_enable="true"  city_enable="true"  neighborhood_enable="true" doors_enable="true" seats_enable="true" condition_enable="true" fuel_enable="true" transmission_enable="true" drive_enable="true" owners_enable="true" price_enable="true" price_is_slider="' . (($car_price_field_layout == '1') ? 'true' : 'false') . '" mileage_enable="true" mileage_is_slider="' . (($car_mileage_field_layout == '1') ? 'true' : 'false') . '" power_enable="true" power_is_slider="' . (($car_power_field_layout == '1') ? 'true' : 'false') . '" volume_enable="true" volume_is_slider="' . (($car_volume_field_layout == '1') ? 'true' : 'false') . '" label_enable="true" car_identity_enable="true" other_exteriors_enable="true" other_interiors_enable="true" '. $additional_fields_attr .']');
            }
        }

        /**
         * car_sidebar
         */
        public function  sidebar_car()
        {
            ams_get_template('global/sidebar-car.php');
        }

        /**
         * manager_sidebar
         */
        public function sidebar_manager()
        {
            ams_get_template('global/sidebar-manager.php');
        }

        /**
         * invoice_sidebar
         */
        public function sidebar_invoice()
        {
            ams_get_template('global/sidebar-invoice.php');
        }

        /**
         * archive_car_heading
         * @param $total_post
         * @param $taxonomy_title
         * @param $manager_id
         * @param $author_id
         */
        public function archive_car_heading($total_post, $taxonomy_title, $manager_id, $author_id)
        {
            ams_get_template('archive-car/heading.php', array('total_post' => $total_post, 'taxonomy_title' => $taxonomy_title, 'manager_id' => $manager_id, 'author_id' => $author_id));
        }

        /**
         * archive_car_action
         * @param $taxonomy_name
         */
        public function archive_car_action($taxonomy_name)
        {
            ams_get_template('archive-car/action.php', array('taxonomy_name' => $taxonomy_name));
        }

        /**
         * archive_manager_heading
         * @param $total_post
         */
        public function archive_manager_heading($total_post)
        {
            ams_get_template('archive-manager/heading.php', array('total_post' => $total_post));
        }

        /**
         * archive_manager_action
         * @param $keyword
         */
        public function archive_manager_action($keyword)
        {
            ams_get_template('archive-manager/action.php', array('keyword' => $keyword));
        }

        /**
         * loop_car
         * @param $car_item_class
         * @param $custom_car_image_size
         * @param $car_image_class
         * @param $car_item_content_class
         */
        public function loop_car($car_item_class, $custom_car_image_size, $car_image_class, $car_item_content_class)
        {
            ams_get_template('loop/car.php', array(
            	'car_item_class' => $car_item_class,
	            'custom_car_image_size' => $custom_car_image_size,
	            'car_image_class' => $car_image_class,
	            'car_item_content_class' => $car_item_content_class
            ));
        }

        /**
         * loop_manager
         * @param $sf_item_wrap
         * @param $manager_layout_style
         */
        public function loop_manager($sf_item_wrap, $manager_layout_style, $custom_manager_image_size)
        {
            ams_get_template('loop/manager.php', array('sf_item_wrap' => $sf_item_wrap, 'manager_layout_style' => $manager_layout_style, 'custom_manager_image_size' => $custom_manager_image_size));
        }

        /**
         * single_car_header
         */
        public function single_car_header()
        {
            ams_get_template('single-car/header.php');
        }

        /**
         * single_car_footer
         */
        public function single_car_footer()
        {
            ams_get_template('single-car/footer.php');
        }

        /**
         * single_car_reviews
         */
        public function single_car_reviews()
        {
            ams_get_template('single-car/review.php');
        }

        /**
         * single_car_gallery
         */
        public function single_car_gallery()
        {
            ams_get_template('single-car/gallery.php');
        }

        /**
         * single_car_description
         */
        public function single_car_description()
        {
            ams_get_template('single-car/description.php');
        }

        /**
         * single_car_attachments
         */
        public function single_car_attachments()
        {
            ams_get_template('single-car/attachments.php');
        }

        /**
         * single_car_location
         */
        public function single_car_location()
        {
            ams_get_template('single-car/location.php');
        }

        /**
         * single_car_exteriors
         */
        public function single_car_exteriors()
        {
            ams_get_template('single-car/exteriors.php');
        }

        /**
         * single_car_interiors
         */
        public function single_car_interiors()
        {
            ams_get_template('single-car/interiors.php');
        }

        /**
         * single_car_map_directions
         */
        public function single_car_map_directions()
        {
            global $post;
            $enable_map_directions = ams_get_option('enable_map_directions', 1);
            if ($enable_map_directions == 1){
                ams_get_template('single-car/google-map-directions.php', array('car_id' => $post->ID));
            }
        }

        /**
         * single_car_nearby_places
         */
        public function single_car_nearby_places()
        {
            global $post;
            $enable_nearby_places = ams_get_option('enable_nearby_places', 1);
            if ($enable_nearby_places == 1){
                ams_get_template('single-car/nearby-places.php', array('car_id' => $post->ID));
            }
        }

        /**
         * single_car_walk_score
         */
        public function single_car_walk_score()
        {
            global $post;
            $enable_walk_score = ams_get_option('enable_walk_score', 0);
            if ($enable_walk_score == 1)
            {
                ams_get_template('single-car/walk-score.php', array('car_id' => $post->ID));
            }
        }

        /**
         * single_car_contact_manager
         */
        public function single_car_contact_manager()
        {
            $car_form_sections = ams_get_option('car_form_sections', array('basic_info', 'tech_data', 'exteriors', 'interiors', 'location', 'price', 'media', 'manager'));
            if (in_array('contact', $car_form_sections)) {
                $hide_contact_information_if_not_login = ams_get_option('hide_contact_information_if_not_login', 0);
                if ($hide_contact_information_if_not_login == 0) {
                    ams_get_template('single-car/contact-manager.php');
                } else {
                    if (is_user_logged_in()) {
                        ams_get_template('single-car/contact-manager.php');
                    } else {
                        ams_get_template('single-car/contact-manager-not-login.php');
                    }
                }
            }
        }

        /**
         * single_manager_info
         */
        public function single_manager_info()
        {
            ams_get_template('single-manager/manager-info.php');
        }

        /**
         * single_manager_reviews
         */
        public function single_manager_reviews()
        {
            ams_get_template('single-manager/review.php');
        }

        /**
         * single_manager_car
         */
        public function single_manager_car()
        {
            $enable_car_of_manager = ams_get_option('enable_car_of_manager');
            if ($enable_car_of_manager == 1) {
                ams_get_template('single-manager/manager-car.php');
            }
        }

        /**
         * author_info
         */
        public function author_info()
        {
            ams_get_template('author/author-info.php');
        }

        /**
         * author_car
         */
        public function author_car()
        {
            ams_get_template('author/author-car.php');
        }

        /**
         * single_manager_other
         */
        public function single_manager_other()
        {
            $enable_other_manager = ams_get_option('enable_other_manager');
            if ($enable_other_manager == 1) {
                ams_get_template('single-manager/other-manager.php');
            }
        }

        /**
         * single_invoice
         */
        public function single_invoice()
        {
            ams_get_template('single-invoice/invoice.php');
        }

        /**
         * taxonomy_dealer_detail
         */
        public function taxonomy_dealer_detail()
        {
            ams_get_template('taxonomy/dealer-detail.php');
        }

        /**
         * taxonomy_dealer_staff
         * @param $dealer_term_slug
         */
        public function taxonomy_dealer_staff($dealer_term_slug)
        {
            ams_get_template('taxonomy/dealer-staff.php', array('dealer_term_slug' => $dealer_term_slug));
        }

        /**
         * Social Share
         */
        public function car_view_gallery()
        {
            ams_get_template('car/view-galley.php');
        }

        /**
         * Favorite
         */
        public function car_favorite()
        {
            if (ams_get_option('enable_favorite_car', '1') == '1') {
                ams_get_template('car/favorite.php');
            }
        }

        /**
         * Compare
         */
        public function car_compare()
        {
            if (ams_get_option('enable_compare_cars', '1') == '1'){
                ams_get_template('car/compare-button.php');
            }
        }

        /**
         * comments_template
         */
        public function comments_template()
        {
            // If comments are open or we have at least one comment, load up the comment template
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;
        }


        public function order_by_featured_pre_get_posts($q) {
	        $ams_orderby_featured = $q->get('ams_orderby_featured',false);
	        if ($ams_orderby_featured == true) {
		        add_filter('posts_clauses', array($this , 'order_by_featured_post_clauses') , 10,2);
		        add_filter('the_posts', array($this , 'remove_car_query_featured_filters') );
	        }
        }

	    public function order_by_featured_post_clauses($args, $wp_query) {
		    global $wpdb;
		    $ams_prefix = AMS_METABOX_PREFIX;
		    $args['join'] .= " LEFT JOIN {$wpdb->prefix}postmeta as ams_mt1 ON ( {$wpdb->prefix}posts.ID = ams_mt1.post_id AND ams_mt1.meta_key = '{$ams_prefix}car_featured')";
		    $args['join'] .= " LEFT JOIN {$wpdb->prefix}postmeta as ams_mt2 ON ( {$wpdb->prefix}posts.ID = ams_mt2.post_id AND ams_mt2.meta_key = '{$ams_prefix}car_featured_date')";
		    $args['orderby'] = " CAST(ams_mt1.meta_value AS CHAR) DESC, CAST(ams_mt2.meta_value AS CHAR) DESC, {$wpdb->prefix}posts.menu_order DESC, {$wpdb->prefix}posts.post_date DESC ";
		    return $args;
	    }

	    public function remove_car_query_featured_filters($posts) {
		    remove_filter( 'posts_clauses', array( $this, 'order_by_featured_post_clauses' ) );
        	return $posts;
	    }

	    public function order_by_viewed_pre_get_posts($q) {
		    $ams_orderby_viewed = $q->get('ams_orderby_viewed',false);
		    if ($ams_orderby_viewed == true) {
			    add_filter('posts_clauses', array($this , 'order_by_viewed_post_clauses') , 10,2);
			    add_filter('the_posts', array($this , 'remove_car_query_viewed_filters') );
		    }
	    }

	    public function order_by_viewed_post_clauses($args, $wp_query) {
		    global $wpdb;
		    $ams_prefix = AMS_METABOX_PREFIX;
		    $args['join'] .= " LEFT JOIN {$wpdb->prefix}postmeta as ams_mt3 ON ( {$wpdb->prefix}posts.ID = ams_mt3.post_id AND ams_mt3.meta_key = '{$ams_prefix}car_views_count')";
		    $args['orderby'] = " (ams_mt3.meta_value+0) DESC, {$wpdb->prefix}posts.menu_order DESC, {$wpdb->prefix}posts.post_date DESC ";
		    return $args;
	    }

	    public function remove_car_query_viewed_filters($posts) {
		    remove_filter( 'posts_clauses', array( $this, 'order_by_viewed_post_clauses' ) );
		    return $posts;
	    }

    }
}
if (!function_exists('ams_template_hooks')) {
    function ams_template_hooks()
    {
        return AMS_Template_Hooks::get_instance();
    }
}
// Global for backwards compatibility.
$GLOBALS['ams_template_hooks'] = ams_template_hooks();