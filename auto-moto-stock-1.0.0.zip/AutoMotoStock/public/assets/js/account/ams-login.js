(function ($) {
    'use strict';
    $(document).ready(function () {
        if (typeof ams_login_vars !== "undefined") {
            var ajax_url = ams_login_vars.ajax_url;
            var loading = ams_login_vars.loading;
            $('.ams-login').validate({
                errorElement: "span", // wrap error elements in span not label
                rules: {
                    user_login: {
                        required: true
                    },
                    user_password: {
                        required: true
                    }
                },
                messages: {
                    user_login: "",
                    user_password: ""
                }
            });
            $('.ams-login-button').on('click', function (e) {
                e.preventDefault();
                var $form = $(this).parents('form');
                var $redirect_url = $(this).data('redirect-url');
                var $messages = $(this).parents('.ams-login-wrap').find('.ams_messages');
                if ($form.valid()) {
                    $.ajax({
                        type: 'post',
                        url: ajax_url,
                        dataType: 'json',
                        data: $form.serialize(),
                        beforeSend: function () {
                            $messages.empty().append('<span class="success text-success"> ' + loading + '</span>');
                        },
                        success: function (response) {
                            if (response.success) {
                                $messages.empty().append('<span class="success text-success"><i class="fa fa-check"></i> ' + response.message + '</span>');
                                if ($redirect_url == '') {
                                    window.location.reload();
                                }
                                else {
                                    window.location.href = $redirect_url;
                                }
                            } else {
                                if (typeof ams_reset_recaptcha == 'function') {
                                    ams_reset_recaptcha();
                                }
                                $messages.empty().append('<span class="error text-danger"><i class="fa fa-close"></i> ' + response.message + '</span>');
                            }
                        }
                    })
                }
            });

            $('.ams_forgetpass').on('click', function (e) {
                e.preventDefault();
                var $form = $(this).parents('form');
                $.ajax({
                    type: 'post',
                    url: ajax_url,
                    dataType: 'json',
                    data: $form.serialize(),
                    beforeSend: function () {
                        $('.ams_messages_reset_password').empty().append('<span class="success text-success"> ' + loading + '</span>');
                    },
                    success: function (response) {
                        if (response.success) {
                            $('.ams_messages_reset_password').empty().append('<span class="success text-success"><i class="fa fa-check"></i> ' + response.message + '</span>');
                        } else {
                            if (typeof ams_reset_recaptcha == 'function') {
                                ams_reset_recaptcha();
                            }
                            $('.ams_messages_reset_password').empty().append('<span class="error text-danger"><i class="fa fa-close"></i> ' + response.message + '</span>');
                        }
                    }
                });
            });
            $('.ams-reset-password').off('click').on('click', function (event) {
                event.preventDefault();
                var $this = $(this),
                    $login_wrap = $this.closest('.ams-login-wrap').slideUp('slow'),
                    $reset_password_wrap = $login_wrap.next('.ams-reset-password-wrap');
                $reset_password_wrap.slideDown('slow');
                $reset_password_wrap.find('.reset_password_user_login').focus();
            });
            $('.ams-back-to-login').off('click').on('click', function (event) {
                event.preventDefault();
                var $this = $(this),
                    $reset_password_wrap = $this.closest('.ams-reset-password-wrap').slideUp('slow'),
                    $login_wrap = $reset_password_wrap.prev('.ams-login-wrap');
                $login_wrap.slideDown('slow');
                $login_wrap.find('.login_user_login').focus();
            });
            $('#ams_signin_modal').on('shown.bs.modal', function () {
                $('.ams-back-to-login', $('#ams_signin_modal')).click();
            });
            $('#ams_signin_modal').on('hide.bs.modal', function () {
                $('.ams-back-to-login', $('#ams_signin_modal')).click();
            })
        }
    });
})(jQuery);