(function ($) {
	'use strict';
	$(document).ready(function () {
		function ams_archive_manager() {
			$('.sort-by', '.archive-manager-action .sort-manager').on('click', function (event) {
				var $this = $(this);
				event.preventDefault();
				if (!$this.next('ul').hasClass('active')) {
					$this.next('ul').addClass('active');
					$this.addClass('active');
				} else {
					$this.next('ul').removeClass('active');
					$this.removeClass('active');
				}
				return false;
			});
			$('li', '.archive-manager-action .sort-manager').each(function () {
				var $this = $(this);
				if (window.location.href.indexOf("sortby=" + $this.children().data('sortby')) > -1) {
					$this.addClass('active');
					$this.closest('ul').prev('span').html($this.children().html());
				}
				$this.on('click', 'a', function (event) {
					$(this).closest('ul').removeClass('active');
					if ($(this).parent().hasClass('active')) {
						event.preventDefault();
						return false;
					} else {
						$(this).closest('ul').prev('span').html($(this).html());
					}
				});
			});
			$(document).on('click', function (e) {
				if ($(e.target).closest('.sort-manager').length == 0) {
					$('ul', '.sort-manager').each(function () {
						var $this = $(this);
						if ($this.hasClass('active')) {
							$this.removeClass('active');
							$this.prev('span').removeClass('active');
						}
					});
				}
			});
			$('span', '.archive-manager-action .view-as').each(function () {
				var $this = $(this);
				if (window.location.href.indexOf("view_as") > -1) {
					if (window.location.href.indexOf("view_as=" + $this.data('view-as')) > -1) {
						$this.addClass('active');
					}
				} else {
					if ($('.ams-manager', '.ams-archive-manager').hasClass($this.data('view-as'))) {
						$this.addClass('active');
					}
				}
				var handle = true;
				$this.on('click', function (event) {
					var $view = $(this),
						$view_as = $view.data('view-as'),
						$manager_list = $view.closest('.ams-archive-manager').find('.ams-manager'),
						$ajax_url = $view.closest('.view-as').data('admin-url');
					if ($view.hasClass('active') || !handle) {
						event.preventDefault();
						return false;
					} else {
						$view.closest('.view-as').find('span').removeClass('active');
						$view.addClass('active');
						$manager_list.fadeOut();
						setTimeout(function () {
							if ($view_as == 'manager-list') {
								$manager_list.removeClass('manager-grid').addClass('manager-list list-1-column');
							} else {
								$manager_list.removeClass('manager-list list-1-column').addClass('manager-grid');
							}
							$manager_list.fadeIn('slow');
						}, 400);
						$.ajax({
							url: $ajax_url,
							data: {
								action: 'ams_manager_set_session_view_as_ajax',
								view_as: $view_as
							},
							success: function () {
								handle = true;
							},
							error: function () {
								handle = true;
							}
						});
					}
				});
			});
		}
		ams_archive_manager();
		function ams_archive_manager_paging_control() {
			$('.paging-navigation', '.ams-archive-manager').each(function () {
				var $this = $(this);
				if ($this.find('a.next').length === 0) {
					$this.addClass('next-disable');
				} else {
					$this.removeClass('next-disable');
				}
			});
		}
		ams_archive_manager_paging_control();
	});
})(jQuery);