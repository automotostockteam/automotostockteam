(function ($) {
    'use strict';
    $(document).ready(function () {
        if (typeof ams_car_vars !== "undefined") {
            var dtGlobals = {}; // Global storage
            dtGlobals.isMobile = (/(Android|BlackBerry|iPhone|iPad|Palm|Symbian|Opera Mini|IEMobile|webOS)/.test(navigator.userAgent));
            dtGlobals.isAndroid = (/(Android)/.test(navigator.userAgent));
            dtGlobals.isiOS = (/(iPhone|iPod|iPad)/.test(navigator.userAgent));
            dtGlobals.isiPhone = (/(iPhone|iPod)/.test(navigator.userAgent));
            dtGlobals.isiPad = (/(iPad|iPod)/.test(navigator.userAgent));
            var ajax_url = ams_car_vars.ajax_url,
                ajax_upload_url = ams_car_vars.ajax_upload_url,
                ajax_upload_attachment_url = ams_car_vars.ajax_upload_attachment_url,
                css_class_wrap = '.car-manager-form',
                //ams_metabox_prefix = ams_car_vars.ams_metabox_prefix,
                googlemap_zoom_level = ams_car_vars.googlemap_zoom_level,
                google_map_style = ams_car_vars.google_map_style,
                googlemap_marker_icon = ams_car_vars.googlemap_marker_icon,
                googlemap_default_country = ams_car_vars.googlemap_default_country,
                googlemap_coordinate_default = ams_car_vars.googlemap_coordinate_default,
                upload_nonce = ams_car_vars.upload_nonce,
                file_type_title = ams_car_vars.file_type_title,
                max_car_images = ams_car_vars.max_car_images,
                image_max_file_size = ams_car_vars.image_max_file_size,
                max_car_attachments = ams_car_vars.max_car_attachments,
                attachment_max_file_size = ams_car_vars.attachment_max_file_size,
                attachment_file_type = ams_car_vars.attachment_file_type;

            var uploader_gallery = null,
                uploader_attachments = null;

            var map; var location; var geocomplete = $("#geocomplete");
            var ams_geocomplete_map = function () {
                if (geocomplete.length === 0) return;
                var car_form = $('input[name="car_form"]').val();
                var styles = [];
                if (google_map_style !== '') {
                    styles = JSON.parse(google_map_style);
                }

                geocomplete.geocomplete({
                    map: ".map_canvas",
                    details: "form",
                    country: googlemap_default_country,
                    geocodeAfterResult: true,
                    types: ["geocode", "establishment"],
                    mapOptions: {
                        zoom: parseInt(googlemap_zoom_level),
                        styles: styles
                    },
                    markerOptions: {
                        draggable: true,
                        icon: googlemap_marker_icon
                    },
                    location: geocomplete.val() !== '' ? geocomplete.val() : googlemap_coordinate_default
                }).one("geocode:result", function (event, result) {
                    map = geocomplete.geocomplete("map");
                    google.maps.event.addListenerOnce(map, 'idle', function () {
                        google.maps.event.trigger(map, 'resize');
                        location = result.geometry.location;
                        map.setCenter(result.geometry.location);
                    });
                });
                geocomplete.bind("geocode:dragged", function (event, latLng) {
                    $("input[name=lat]").val(latLng.lat());
                    $("input[name=lng]").val(latLng.lng());
                    $("#reset").show();
                });
                geocomplete.on('focus', function () {
                    google.maps.event.trigger(map, 'resize');
                });
                $("#reset").on('click', function (e) {
                    e.preventDefault();
                    geocomplete.geocomplete("resetMarker");
                    $("#reset").hide();
                    return false;
                });
                $("#find").on('click', function (e) {
                    e.preventDefault();
                    map = geocomplete.geocomplete("map");
                    var marker = geocomplete.geocomplete("marker");
                    location = new google.maps.LatLng($('#latitude').val(), $('#longitude').val());
                    map.setCenter(location);
                    marker.setPosition(location);
                });
                $(window).on('load', function () {
                    geocomplete.trigger("geocode");
                });
            };
            ams_geocomplete_map();

            $('input[name="manager_display_option"]', css_class_wrap).on('change', function () {
                $('select[name="car_manager"]').hide();
                if ($(this).val() == 'other_info') {
                    $("#car_other_contact").slideDown('slow');
                }
                else {
                    $("#car_other_contact").slideUp('slow');
                }
            });
            var ams_car_price_on_call_change = function () {
                if ($('input[name="car_price_on_call"]').is(':checked')) {
                    $('input[name="car_price_short"]').attr('disabled', 'disabled');
                    $('select[name="car_price_unit"]').attr('disabled', 'disabled');
                    $('input[name="car_price_prefix"]').attr('disabled', 'disabled');
                    $('input[name="car_price_postfix"]').attr('disabled', 'disabled');
                }
                else {
                    $('input[name="car_price_short"]').removeAttr('disabled');
                    $('select[name="car_price_unit"]').removeAttr('disabled');
                    $('input[name="car_price_prefix"]').removeAttr('disabled');
                    $('input[name="car_price_postfix"]').removeAttr('disabled');
                }
            };
            ams_car_price_on_call_change();
            $('input[name="car_price_on_call"]', css_class_wrap).on('change', function () {
                ams_car_price_on_call_change();
            });

            /**
             * Vehicle Additional Exteriors
             */	
            var ams_execute_additional_exterior_order = function () {
                var $i = 0;
                $('tr', '#ams_additional_details').each(function () {
                    var input_title = $('input[name*="additional_basic_title"]', $(this)),
                        input_value = $('input[name*="additional_basic_value"]', $(this));
                    input_title.attr('name', 'additional_basic_title[' + $i + ']');
                    input_title.attr('id', 'additional_basic_title_' + $i);
                    input_value.attr('name', 'additional_basic_value[' + $i + ']');
                    input_value.attr('id', 'additional_basic_value_' + $i);
                    $i++;
                });
            };
            $('#ams_additional_details').sortable({
                revert: 100,
                placeholder: "detail-placeholder",
                handle: ".sort-additional-row",
                cursor: "move",
                stop: function (event, ui) {
                    ams_execute_additional_exterior_order();
                }
            });

            $('.add-additional-basic', css_class_wrap).on('click', function (e) {
                e.preventDefault();
                var row_num = $(this).data("increment") + 1;
                $(this).data('increment', row_num);
                $(this).attr({
                    "data-increment": row_num
                });

                var new_exterior = '<tr>' +
                    '<td class="action-field">' +
                    '<span class="sort-additional-row"><i class="fa fa-navicon"></i></span>' +
                    '</td>' +
                    '<td>' +
                    '<input class="form-control" type="text" name="additional_basic_title[' + row_num + ']" id="additional_basic_title_' + row_num + '" value="">' +
                    '</td>' +
                    '<td>' +
                    '<input class="form-control" type="text" name="additional_basic_value[' + row_num + ']" id="additional_basic_value_' + row_num + '" value="">' +
                    '</td>' +
                    '<td>' +
                    '<span data-remove="' + row_num + '" class="remove-additional-basic"><i class="fa fa-remove"></i></span>' +
                    '</td>' +
                    '</tr>';
                $('#ams_additional_details').append(new_exterior);
                ams_remove_additional_basic();
            });

            var ams_remove_additional_basic = function () {
                $('.remove-additional-basic', css_class_wrap).on('click', function (event) {
                    event.preventDefault();
                    var $this = $(this),
                        parent = $this.closest('.additional-block'),
                        button_add = parent.find('.add-additional-basic'),
                        increment = parseInt(button_add.data('increment')) - 1;

                    $this.closest('tr').remove();
                    button_add.data('increment', increment);
                    button_add.attr('data-increment', increment);
                    ams_execute_additional_exterior_order();
                });
            };
            ams_remove_additional_basic();

            /**
             * Vehicle Additional Interiors
             */
            var ams_execute_additional_interior_order = function () {
                var $i = 0;
                $('tr', '#ams_additional_details').each(function () {
                    var input_title = $('input[name*="additional_technical_title"]', $(this)),
                        input_value = $('input[name*="additional_technical_value"]', $(this));
                    input_title.attr('name', 'additional_technical_title[' + $i + ']');
                    input_title.attr('id', 'additional_technical_title_' + $i);
                    input_value.attr('name', 'additional_technical_value[' + $i + ']');
                    input_value.attr('id', 'additional_technical_value_' + $i);
                    $i++;
                });
            };
            $('#ams_additional_details').sortable({
                revert: 100,
                placeholder: "detail-placeholder",
                handle: ".sort-additional-row",
                cursor: "move",
                stop: function (event, ui) {
                    ams_execute_additional_interior_order();
                }
            });

            $('.add-additional-technical', css_class_wrap).on('click', function (e) {
                e.preventDefault();
                var row_num = $(this).data("increment") + 1;
                $(this).data('increment', row_num);
                $(this).attr({
                    "data-increment": row_num
                });

                var new_interior = '<tr>' +
                    '<td class="action-field">' +
                    '<span class="sort-additional-row"><i class="fa fa-navicon"></i></span>' +
                    '</td>' +
                    '<td>' +
                    '<input class="form-control" type="text" name="additional_technical_title[' + row_num + ']" id="additional_technical_title_' + row_num + '" value="">' +
                    '</td>' +
                    '<td>' +
                    '<input class="form-control" type="text" name="additional_technical_value[' + row_num + ']" id="additional_technical_value_' + row_num + '" value="">' +
                    '</td>' +
                    '<td>' +
                    '<span data-remove="' + row_num + '" class="remove-additional-technical"><i class="fa fa-remove"></i></span>' +
                    '</td>' +
                    '</tr>';
                $('#ams_additional_details').append(new_interior);
                ams_remove_additional_technical();
            });

            var ams_remove_additional_technical = function () {
                $('.remove-additional-technical', css_class_wrap).on('click', function (event) {
                    event.preventDefault();
                    var $this = $(this),
                        parent = $this.closest('.additional-block'),
                        button_add = parent.find('.add-additional-technical'),
                        increment = parseInt(button_add.data('increment')) - 1;

                    $this.closest('tr').remove();
                    button_add.data('increment', increment);
                    button_add.attr('data-increment', increment);
                    ams_execute_additional_interior_order();
                });
            };
            ams_remove_additional_technical();

            // Vehicle Thumbnails
            var ams_car_gallery_event = function () {

                // Set Featured Image
                $('.icon-featured', '.ams-car-gallery').off('click').on('click', function () {

                    var $this = $(this);
                    var thumb_id = $this.data('attachment-id');
                    var icon = $this.find('i');

                    $('.media-thumb .featured-image-id').remove();
                    $('.media-thumb .icon-featured i').removeClass('fa-star').addClass('fa-star-o');

                    $this.closest('.media-thumb').append('<input type="hidden" class="featured-image-id" name="featured_image_id" value="' + thumb_id + '">');
                    icon.removeClass('fa-star-o').addClass('fa-star');
                });

                $('.icon-delete', '.ams-car-gallery').off('click').on('click', function () {
                    var $this = $(this),
                        $wrap = $this.closest('.media-thumb-wrap'),
                        file_id = $wrap.attr('id'),
                        icon_delete = $this.children('i'),
                        thumbnail = $this.closest('.media-thumb-wrap'),
                        car_id = $this.data('car-id'),
                        attachment_id = $this.data('attachment-id');
                    if (typeof file_id !== typeof undefined && file_id !== false) {
                        file_id = file_id.replace('holder-', '');
                    }

                    icon_delete.addClass('fa-spinner fa-spin');
                    $.ajax({
                        type: 'post',
                        url: ajax_url,
                        dataType: 'json',
                        data: {
                            'action': 'ams_remove_car_attachment_ajax',
                            'car_id': car_id,
                            'attachment_id': attachment_id,
                            'type': 'gallery',
                            'removeNonce': upload_nonce
                        },
                        success: function (response) {
                            if (response.success) {
                                thumbnail.remove();
                                thumbnail.hide();
                                if ((uploader_gallery)
                                    && (typeof file_id !== typeof undefined && file_id !== false)) {
                                    for (var i = 0; i < uploader_gallery.files.length; i++) {
                                        if (uploader_gallery.files[i].id == file_id) {
                                            uploader_gallery.removeFile(uploader_gallery.files[i]);
                                            break;
                                        }
                                    }
                                }

                                if ($('.ams-car-gallery').find('[name="featured_image_id"]').length === 0) {
                                    var $firstImage = $('.ams-car-gallery').find('.media-thumb-wrap');
                                    if ($firstImage.length > 0) {
                                        $firstImage = $($firstImage[0]);
                                        var attachment_id = $firstImage.find('.car_image_ids').val();

                                        $firstImage.find('.icon-featured i').removeClass('fa-star-o').addClass('fa-star');
                                        $firstImage.find('.media-thumb').append('<input type="hidden" class="featured-image-id" name="featured_image_id" value="' + attachment_id + '">');
                                    }


                                }

                            }
                            icon_delete.removeClass('fa-spinner fa-spin');
                        },
                        error: function () {
                            icon_delete.removeClass('fa-spinner fa-spin');
                        }
                    });
                });
            };

            ams_car_gallery_event();

            // Vehicle Thumbnails
            var ams_car_attachments_event = function () {
                $('.icon-delete', '.ams-car-attachments').off('click').on('click', function () {
                    var $this = $(this),
                        $wrap = $this.closest('.media-thumb-wrap'),
                        file_id = $wrap.attr('id'),
                        icon_delete = $this.children('i'),
                        thumbnail = $this.closest('.media-thumb-wrap'),
                        car_id = $this.data('car-id'),
                        attachment_id = $this.data('attachment-id');

                    if (typeof file_id !== typeof undefined && file_id !== false) {
                        file_id = file_id.replace('holder-', '');
                    }

                    icon_delete.addClass('fa-spinner fa-spin');

                    $.ajax({
                        type: 'post',
                        url: ajax_url,
                        dataType: 'json',
                        data: {
                            'action': 'ams_remove_car_attachment_ajax',
                            'car_id': car_id,
                            'attachment_id': attachment_id,
                            'type': 'attachments',
                            'removeNonce': upload_nonce
                        },
                        success: function (response) {
                            if (response.success) {
                                thumbnail.remove();
                                thumbnail.hide();
                                if ((uploader_attachments)
                                    && (typeof file_id !== typeof undefined && file_id !== false)) {
                                    for (var i = 0; i < uploader_attachments.files.length; i++) {
                                        if (uploader_attachments.files[i].id == file_id) {
                                            uploader_attachments.removeFile(uploader_attachments.files[i]);
                                            break;
                                        }
                                    }
                                }
                            }
                            icon_delete.removeClass('fa-spinner fa-spin');
                        },
                        error: function () {
                            icon_delete.removeClass('fa-spinner fa-spin');
                        }
                    });
                });
            };

            ams_car_attachments_event();

            // Vehicle Gallery images
            var ams_car_gallery_images = function () {

                $("#car_gallery_thumbs_container").sortable();

                /* initialize uploader */
                uploader_gallery = new plupload.Uploader({
                    browse_button: 'ams_select_gallery_images',          // this can be an id of a DOM element or the DOM element itself
                    file_data_name: 'car_upload_file',
                    container: 'ams_gallery_plupload_container',
                    drop_element: 'ams_gallery_plupload_container',
                    multi_selection: true,
                    url: ajax_upload_url,
                    filters: {
                        mime_types: [
                            { title: file_type_title, extensions: "jpg,jpeg,gif,png" }
                        ],
                        max_file_size: image_max_file_size,
                        prevent_duplicates: true
                    }
                });
                uploader_gallery.init();

                uploader_gallery.bind('FilesAdded', function (up, files) {
                    var carThumb = "";
                    var maxfiles = max_car_images;
                    var totalFiles = $('#car_gallery_thumbs_container').find('.__thumb').length + up.files.length;
                    if (totalFiles > maxfiles) {
                        $.each(files, function (i, file) {
                            up.removeFile(file);
                        });
                        alert('no more than ' + maxfiles + ' file(s)');
                        return;
                    }
                    plupload.each(files, function (file) {
                        carThumb += '<div id="holder-' + file.id + '" class="col-sm-2 media-thumb-wrap"></div>';
                    });
                    document.getElementById('car_gallery_thumbs_container').innerHTML += carThumb;
                    up.refresh();
                    up.start();
                });

                uploader_gallery.bind('UploadProgress', function (up, file) {
                    document.getElementById("holder-" + file.id).innerHTML = '<span><i class="fa fa-spinner fa-spin"></i></span>';
                });

                uploader_gallery.bind('Error', function (up, err) {
                    document.getElementById('ams_gallery_errors_log').innerHTML += "<br/>" + "Error #" + err.code + ": " + err.message;
                });

                uploader_gallery.bind('FileUploaded', function (up, file, ajax_response) {
                    var response = $.parseJSON(ajax_response.response);

                    if (response.success) {
                        var $html =
                            '<figure class="media-thumb">' +
                            '<img src="' + response.url + '"/>' +
                            '<div class="media-item-actions">' +
                            '<a class="icon icon-delete" data-car-id="0"  data-attachment-id="' + response.attachment_id + '" href="javascript:;" ><i class="fa fa-trash-o"></i></a>' +
                            '<a class="icon icon-featured" data-car-id="0"  data-attachment-id="' + response.attachment_id + '" href="javascript:;" ><i class="fa fa-star-o"></i></a>' +
                            '<input type="hidden" class="car_image_ids" name="car_image_ids[]" value="' + response.attachment_id + '"/>' +
                            '<span style="display: none;" class="icon icon-loader"><i class="fa fa-spinner fa-spin"></i></span>' +
                            '</div>' +
                            '</figure>';

                        document.getElementById("holder-" + file.id).innerHTML = $html;

                        if ($('.ams-car-gallery').find('[name="featured_image_id"]').length === 0) {
                            $('#holder-' + file.id).find('.icon-featured i').removeClass('fa-star-o').addClass('fa-star');
                            $('#holder-' + file.id).find('.media-thumb').append('<input type="hidden" class="featured-image-id" name="featured_image_id" value="' + response.attachment_id + '">');
                        }

                        ams_car_gallery_event();
                    }
                });
            };
            ams_car_gallery_images();
            // Vehicle Documents
            var ams_car_attachments = function () {

                $("#car_attachments_thumbs_container").sortable();

                /* initialize uploader */
                uploader_attachments = new plupload.Uploader({
                    browse_button: 'ams_select_file_attachments',          // this can be an id of a DOM element or the DOM element itself
                    file_data_name: 'car_upload_file',
                    container: 'ams_attachments_plupload_container',
                    drop_element: 'ams_attachments_plupload_container',
                    multi_selection: true,
                    url: ajax_upload_attachment_url,
                    filters: {
                        mime_types: [
                            { title: file_type_title, extensions: attachment_file_type }
                        ],
                        max_file_size: attachment_max_file_size,
                        prevent_duplicates: true
                    }
                });
                uploader_attachments.init();

                uploader_attachments.bind('FilesAdded', function (up, files) {
                    var carThumb = "";
                    var maxfiles = max_car_attachments;
                    var totalFiles = $('#car_attachments_thumbs_container').find('.__thumb').length + up.files.length;
                    if (totalFiles > maxfiles) {
                        $.each(files, function (i, file) {
                            up.removeFile(file);
                        });
                        alert('no more than ' + maxfiles + ' file(s)');
                        return;
                    }
                    plupload.each(files, function (file) {
                        carThumb += '<div id="holder-' + file.id + '" class="col-lg-4 col-md-4 col-sm-6 col-xs-12 media-thumb-wrap"></div>';
                    });
                    document.getElementById('car_attachments_thumbs_container').innerHTML += carThumb;
                    up.refresh();
                    up.start();
                });

                uploader_attachments.bind('UploadProgress', function (up, file) {
                    document.getElementById("holder-" + file.id).innerHTML = '<span><i class="fa fa-spinner fa-spin"></i></span>';
                });

                uploader_attachments.bind('Error', function (up, err) {
                    document.getElementById('ams_attachments_errors_log').innerHTML += "<br/>" + "Error #" + err.code + ": " + err.message;
                });

                uploader_attachments.bind('FileUploaded', function (up, file, ajax_response) {
                    var response = $.parseJSON(ajax_response.response);

                    if (response.success) {

                        var $html =
                            '<figure class="media-thumb">' +
                            '<img src="' + response.thumb_url + '"/>' +
                            '<a href="' + response.url + '">' + response.file_name + '</a>' +
                            '<div class="media-item-actions">' +
                            '<a class="icon icon-delete" data-car-id="0"  data-attachment-id="' + response.attachment_id + '" href="javascript:;" ><i class="fa fa-trash-o"></i></a>' +
                            '<input type="hidden" class="car_attachment_ids" name="car_attachment_ids[]" value="' + response.attachment_id + '"/>' +
                            '<span style="display: none;" class="icon icon-loader"><i class="fa fa-spinner fa-spin"></i></span>' +
                            '</div>' +
                            '</figure>';

                        document.getElementById("holder-" + file.id).innerHTML = $html;
                        ams_car_attachments_event();
                    }
                });
            };
            ams_car_attachments();
            // Image 360
            var ams_image_360 = function () {

                var uploader_image_360 = new plupload.Uploader({
                    browse_button: 'ams_select_images_360',
                    file_data_name: 'car_upload_file',
                    container: 'ams_image_360_plupload_container',
                    url: ajax_upload_url,
                    filters: {
                        mime_types: [
                            { title: file_type_title, extensions: "jpg,jpeg,gif,png" }
                        ],
                        max_file_size: image_max_file_size,
                        prevent_duplicates: true
                    }
                });
                uploader_image_360.init();

                uploader_image_360.bind('FilesAdded', function (up, files) {
                    var maxfiles = max_car_images;
                    if (up.files.length > maxfiles) {
                        $.each(files, function (i, file) {
                            up.removeFile(file);
                        });
                        alert('no more than ' + maxfiles + ' file(s)');
                        return;
                    }
                    plupload.each(files, function (file) {

                    });
                    up.refresh();
                    up.start();
                });
                uploader_image_360.bind('Error', function (up, err) {
                    document.getElementById('ams_image_360_errors_log').innerHTML += "<br/>" + "Error #" + err.code + ": " + err.message;
                });
                uploader_image_360.bind('FileUploaded', function (up, file, ajax_response) {
                    var response = $.parseJSON(ajax_response.response);
                    if (response.success) {
                        $('.ams_image_360_url').val(response.full_image);
                        $('.ams_image_360_id').val(response.attachment_id);
                        var plugin_url = $('#ams_car_image_360_view').attr('data-plugin-url');
                        var _iframe = '<iframe width="100%" height="200" scrolling="no" allowfullscreen src="' + plugin_url + 'public/assets/packages/vr-view/index.html?image=' + response.full_image + '"></iframe>';
                        $('#ams_car_image_360_view').html(_iframe);
                    }
                });
            };
            ams_image_360();

            var ams_get_states_by_country = function () {
                var $this = $(".ams-car-country-ajax", css_class_wrap);
                if ($this.length) {
                    var selected_country = $this.val();
                    if ($('#geocomplete').length > 0) {
                        var autocomplete = $('#geocomplete').geocomplete("autocomplete");
                        autocomplete.setComponentRestrictions({ country: selected_country });
                    }

                    $.ajax({
                        type: "POST",
                        url: ajax_url,
                        data: {
                            'action': 'ams_get_states_by_country_ajax',
                            'country': selected_country,
                            'type': 0,
                            'is_slug': '1'
                        },
                        beforeSend: function () {
                            $this.parent().children('.ams-loading').remove();
                            $this.parent().append('<span class="ams-loading"><i class="fa fa-spinner fa-spin"></i></span>');
                        },
                        success: function (response) {
                            $(".ams-car-state-ajax", css_class_wrap).html(response);
                            var val_selected = $(".ams-car-state-ajax", css_class_wrap).attr('data-selected');
                            if (typeof val_selected !== 'undefined') {
                                $(".ams-car-state-ajax", css_class_wrap).val(val_selected);
                            }
                            $this.parent().children('.ams-loading').remove();
                        },
                        error: function () {
                            $this.parent().children('.ams-loading').remove();
                        },
                        complete: function () {
                            $this.parent().children('.ams-loading').remove();
                        }
                    });
                }
            };
            ams_get_states_by_country();

            $(".ams-car-country-ajax", css_class_wrap).on('change', function () {
                ams_get_states_by_country();
            });

            var ams_get_cities_by_state = function () {
                var $this = $(".ams-car-state-ajax", css_class_wrap);
                if ($this.length) {
                    var selected_state = $this.val();
                    $.ajax({
                        type: "POST",
                        url: ajax_url,
                        data: {
                            'action': 'ams_get_cities_by_state_ajax',
                            'state': selected_state,
                            'type': 0,
                            'is_slug': '1'
                        },
                        beforeSend: function () {
                            $this.parent().children('.ams-loading').remove();
                            $this.parent().append('<span class="ams-loading"><i class="fa fa-spinner fa-spin"></i></span>');
                        },
                        success: function (response) {
                            $(".ams-car-city-ajax", css_class_wrap).html(response);
                            var val_selected = $(".ams-car-city-ajax", css_class_wrap).attr('data-selected');
                            if (typeof val_selected !== 'undefined') {
                                $(".ams-car-city-ajax", css_class_wrap).val(val_selected);
                            }
                            $this.parent().children('.ams-loading').remove();
                        },
                        error: function () {
                            $this.parent().children('.ams-loading').remove();
                        },
                        complete: function () {
                            $this.parent().children('.ams-loading').remove();
                        }
                    });
                }
            };
            ams_get_cities_by_state();

            $(".ams-car-state-ajax", css_class_wrap).on('change', function () {
                ams_get_cities_by_state();
            });

            var ams_get_neighborhoods_by_city = function () {
                var $this = $(".ams-car-city-ajax", css_class_wrap);
                if ($this.length) {
                    var selected_city = $this.val();
                    $.ajax({
                        type: "POST",
                        url: ajax_url,
                        data: {
                            'action': 'ams_get_neighborhoods_by_city_ajax',
                            'city': selected_city,
                            'type': 0,
                            'is_slug': '1'
                        },
                        beforeSend: function () {
                            $this.parent().children('.ams-loading').remove();
                            $this.parent().append('<span class="ams-loading"><i class="fa fa-spinner fa-spin"></i></span>');
                        },
                        success: function (response) {
                            $(".ams-car-neighborhood-ajax", css_class_wrap).html(response);
                            var val_selected = $(".ams-car-neighborhood-ajax", css_class_wrap).attr('data-selected');
                            if (typeof val_selected !== 'undefined') {
                                $(".ams-car-neighborhood-ajax", css_class_wrap).val(val_selected);
                            }
                            $this.parent().children('.ams-loading').remove();
                        },
                        error: function () {
                            $this.parent().children('.ams-loading').remove();
                        },
                        complete: function () {
                            $this.parent().children('.ams-loading').remove();
                        }
                    });
                }
            };
            ams_get_neighborhoods_by_city();

            $(".ams-car-city-ajax", css_class_wrap).on('change', function () {
                ams_get_neighborhoods_by_city();
            });
            var ams_car_multi_step = $(".ams-car-multi-step");
            ams_car_multi_step.find('.ams-btn-next').on('click', function () {
                if (dtGlobals.isiOS) {
                    ams_car_gallery_images();
                    ams_car_attachments();
                    ams_image_360();
                }
                if ($('#step-location').attr('aria-hidden') === 'false') {
                    if (typeof geocomplete !== 'undefined') {
                        geocomplete.trigger("geocode");
                    }
                }
            });
            ams_car_multi_step.find('.ams-btn-edit').on('click', function () {
                if (dtGlobals.isiOS) {
                    ams_car_gallery_images();
                    ams_car_attachments();
                    ams_image_360();
                }
                if ($('#step-location').attr('aria-hidden') === 'false') {
                    if (typeof geocomplete !== 'undefined') {
                        geocomplete.trigger("geocode");
                    }
                }
            });
            var enable_filter_location = ams_car_vars.enable_filter_location;
            if (enable_filter_location == '1') {
                $('.ams-car-country-ajax', css_class_wrap).select2();
                $('.ams-car-state-ajax', css_class_wrap).select2();
                $('.ams-car-city-ajax', css_class_wrap).select2();
                $('.ams-car-neighborhood-ajax', css_class_wrap).select2();
            }

            $('#car_type,#car_maker,#car_model,#car_body,#car_status,#car_label', css_class_wrap).select2();

        }
    });
})(jQuery);