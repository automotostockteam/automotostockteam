<?php
/**
 * Plugin Name: Auto Moto Stock
 * Plugin URI: https://wordpress.org/plugins/auto-moto-stock
 * Description: Auto Moto Stock is a plugin designed for the search and sale of vehicles (cars, track, motorhome, motorcycles, etc.). Suitable for dealers, staff, private sellers. Convenient and fully functional plugin. Built-in payment gateways, the ability to submit, search, view and track vehicles, ads, payments and more. With Auto Moto Stock you can easily create an automotive website.
 * Version: 1.0.0
 * Author: AMS Team
 * Author URI: https://www.auto-moto-stock.com
 * Text Domain: auto-moto-stock
 * Domain Path: /languages/
 * License: GPLv2 or later
 */
/*
Copyright 2023 by AMS Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Currently Plugin Version.
if (!defined('AMS_PLUGIN_VER')) {
    define('AMS_PLUGIN_VER', '1.0.0');
}

// Plugin File.
if (!defined('AMS_PLUGIN_FILE')) {
    define('AMS_PLUGIN_FILE', __FILE__);
}

// Plugin Name
if (!defined('AMS_PLUGIN_NAME')) {
    $plugin_dir_name = dirname(__FILE__);
    $plugin_dir_name = str_replace('\\', '/', $plugin_dir_name);
    $plugin_dir_name = explode('/', $plugin_dir_name);
    $plugin_dir_name = end($plugin_dir_name);
    define('AMS_PLUGIN_NAME', $plugin_dir_name);
}

// Plugin Folder Path
if (!defined('AMS_PLUGIN_DIR')) {
    $plugin_dir = plugin_dir_path(__FILE__);
    define('AMS_PLUGIN_DIR', $plugin_dir);
}

// Plugin Folder URL
if (!defined('AMS_PLUGIN_URL')) {
    $plugin_url = plugins_url('/', __FILE__);
    define('AMS_PLUGIN_URL', $plugin_url);
}

// Plugin Prefix
if (!defined('AMS_PLUGIN_PREFIX')) {
    define('AMS_PLUGIN_PREFIX', 'ams_');
}

// Plugin Metabox Prefix
if (!defined('AMS_METABOX_PREFIX')) {
    define('AMS_METABOX_PREFIX', 'auto_moto_');
}

// Plugin Options Name
if (!defined('AMS_OPTIONS_NAME')) {
    define('AMS_OPTIONS_NAME', 'ams_options');
}

// Plugin Folder AJAX URL
if (!defined('AMS_AJAX_URL')) {
    $ajax_url = admin_url('admin-ajax.php', 'relative');
	$my_current_lang = apply_filters( 'wpml_current_language', NULL );
	if ($my_current_lang) {
		$ajax_url = add_query_arg( 'ams_wpml_lang', $my_current_lang, $ajax_url );
	}
    define('AMS_AJAX_URL', $ajax_url);
}

// Get Rounding Precision
if (!defined('AMS_ROUNDING_PRECISION')) {
	define('AMS_ROUNDING_PRECISION', 6);
}

 // The code that runs during plugin activation.
function ams_activate()
{
    require_once AMS_PLUGIN_DIR . 'includes/class-ams-activator.php';
    AMS_Activator::activate();
}

 // The code that runs during plugin deactivation.
function ams_deactivate()
{
    require_once AMS_PLUGIN_DIR . 'includes/class-ams-deactivator.php';
    AMS_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'ams_activate');
register_deactivation_hook(__FILE__, 'ams_deactivate');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require AMS_PLUGIN_DIR . 'includes/class-auto-moto-stock.php';

/**
 * Begins execution of the plugin.
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 */
AMS()->run();

 // Generate a Google Maps Platform API key for WordPress Sites.
add_filter('sqf_google_map_api_url', 'ams_google_map_api_url', 1);
function ams_google_map_api_url()
{
    $googlemap_ssl = ams_get_option('googlemap_ssl', 0);
    $googlemap_api_key = ams_get_option('googlemap_api_key', 'AIzaSyCLyuWY0RUhv7GxftSyI8Ka1VbeU7CTDls');
    if (esc_html($googlemap_ssl) == 1 || is_ssl()) {
        return 'https://maps-api-ssl.google.com/maps/api/js?libraries=places&language=' . get_locale() . '&key=' . esc_html($googlemap_api_key);
    } else {
        return 'http://maps.googleapis.com/maps/api/js?libraries=places&language=' . get_locale() . '&key=' . esc_html($googlemap_api_key);
    }
}
