<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AMS_Shortcodes
 */
class AMS_Shortcodes {

		 // Loader instances
	private static $_instance;

	public static function getInstance()
	{
		if (self::$_instance == null) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	private static $ams_message;
	
	// Init shortcodes.
	public static function init() {
		$shortcodes = array(
			'ams_login'                  => __CLASS__ . '::login',
			'ams_register'               => __CLASS__ . '::register',
			'ams_profile'                => __CLASS__ . '::profile',
			'ams_reset_password'         => __CLASS__ . '::reset_password',
			'ams_package'                => __CLASS__ . '::package',
			'ams_my_invoices'            => __CLASS__ . '::my_invoices',
			'ams_payment'                => __CLASS__ . '::payment',
			'ams_payment_completed'      => __CLASS__ . '::payment_completed',
			'ams_my_cars'                => __CLASS__ . '::my_cars',
			'ams_submit_car'             => __CLASS__ . '::submit_car',
			'ams_my_favorites'           => __CLASS__ . '::my_favorites',
			'ams_advanced_search'        => __CLASS__ . '::advanced_search',
			'ams_my_save_search'         => __CLASS__ . '::my_save_search',
			'ams_compare'                => __CLASS__ . '::compare',			
			'ams_car'                    => __CLASS__ . '::car',
			'ams_car_carousel'           => __CLASS__ . '::car_carousel',
			'ams_car_slider'             => __CLASS__ . '::car_slider',
			'ams_car_gallery'            => __CLASS__ . '::car_gallery',
			'ams_car_featured'           => __CLASS__ . '::car_featured',
			'ams_car_type'               => __CLASS__ . '::car_type',
			'ams_car_maker'              => __CLASS__ . '::car_maker',
			'ams_car_model'              => __CLASS__ . '::car_model',
			'ams_car_body'              => __CLASS__ . '::car_body',
			'ams_car_search'             => __CLASS__ . '::car_search',
			'ams_car_search_map'         => __CLASS__ . '::car_search_map',
			'ams_car_advanced_search'    => __CLASS__ . '::car_advanced_search',
			'ams_car_mini_search'        => __CLASS__ . '::car_mini_search',
			'ams_car_map'                => __CLASS__ . '::car_map',
			'ams_manager'                => __CLASS__ . '::manager',
			'ams_dealer'                 => __CLASS__ . '::dealer',
		);

		foreach ( $shortcodes as $shortcode => $function ) {

			add_shortcode( apply_filters( "{$shortcode}_shortcode_tag", $shortcode ), $function );
		}
	}

	/**
	 * Shortcode Wrapper.
	 *
	 * @param string[] $function  Callback function.
	 * @param array    $atts     Attributes. Default to empty array.
	 * @param array    $wrapper  Customer wrapper data.
	 *
	 * @return string
	 */
	public static function shortcode_wrapper(
		$function,
		$atts = array(),
		$wrapper = array(
			'before' => null,
			'after'  => null,
		)
	) 
	{
		ob_start();

		echo empty( $wrapper['before'] ) ? '' : $wrapper['before'];

		echo call_user_func( $function, $atts );

		echo empty( $wrapper['after'] ) ? '' : $wrapper['after'];

		return ob_get_clean();
	}

	/**
	 * Shortcode Login
	 * @param $atts
	 * @return string
	 */
	public static function login( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_Login', 'output' ), $atts );
	}

	/**
	 * Shortcode Register
	 * @param $atts
	 * @return string
	 */
	public static function register( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_Register', 'output' ), $atts );
	}

	/**
	 * Shortcode Profile
	 * @param $atts
	 * @return string
	 */
	public static function profile( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_Profile', 'output' ), $atts );
	}

	/**
	 * Shortcode Reset Password
	 * @param $atts
	 * @return string
	 */
	public static function reset_password( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_Reset_Password', 'output' ), $atts );
	}

	/**
	 * Shortcode Package
	 * @param $atts
	 * @return string
	 */
	public static function package( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_Package', 'output' ), $atts );
	}

	/**
	 * Shortcode My Invoice
	 * @param $atts
	 * @return string
	 */
	public static function my_invoices( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_My_Invoice', 'output' ), $atts );
	}

	/**
	 * Shortcode Payment
	 * @param $atts
	 * @return string
	 */
	public static function payment( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_Payment', 'output' ), $atts );
	}

	/**
	 * Shortcode Payment Completed
	 * @param $atts
	 * @return string
	 */
	public static function payment_completed( $atts ) {
		return self::shortcode_wrapper( array( 'AMS_Shortcode_Payment_Completed', 'output' ), $atts );
	}

	// Action handler for vehicles
	public function shortcode_car_action_handler()
	{
		global $post;

		if (is_page() && strstr($post->post_content, '[ams_my_cars')) {
			$this->my_cars_handler();
		}

		if (is_page() && strstr($post->post_content, '[ams_my_save_search')) {
			$this->my_save_search_handler();
		}
	}

	/**
	 * My vehicles
	 * @param $atts
	 * @return null|string
	 */
	public static function my_cars($atts)
	{
		if (!is_user_logged_in()) {
			echo ams_get_template_html('global/access-denied.php',array('type'=>'not_login'));

			return null;
		}

		$posts_per_page = '25';

		$post_status = $title = $car_status=$car_identity='';

		$tax_query=$meta_query=array();

		extract(shortcode_atts(array(
			'posts_per_page' => '25',
			'post_status' => ''
		), $atts));

		global $current_user;

		wp_get_current_user();

		$user_id = $current_user->ID;

		ob_start();

		// If doing an action, show conditional content if needed.
		if (!empty($_REQUEST['action'])) {

			$action = sanitize_title(wp_slash($_REQUEST['action']));

			if (has_action('ams_my_cars_content_' . $action)) {
				do_action('ams_my_cars_content_' . $action, $atts);

				return ob_get_clean();
			}
		}

		if (empty($post_status)) {
			$post_status = array('publish', 'expired', 'pending', 'hidden');
		}

		if (!empty($_REQUEST['post_status'])) {
			$post_status = sanitize_title(wp_unslash($_REQUEST['post_status']));
		}

		if (!empty($_REQUEST['car_status'])) {

			$car_status = sanitize_title(wp_slash($_REQUEST['car_status']));

			$tax_query[] = array(
				'taxonomy' => 'car-status',
				'field' => 'slug',
				'terms' => $car_status
			);
		}

		if (!empty($_REQUEST['car_identity'])) {

			$car_identity = sanitize_text_field(wp_unslash($_REQUEST['car_identity']));

			$meta_query[] = array(
				'key' => AMS_METABOX_PREFIX. 'car_identity',
				'value' => $car_identity,
				'type' => 'CHAR',
				'compare' => '=',
			);
		}

		if (!empty($_REQUEST['title'])) {

			$title = sanitize_text_field(wp_unslash($_REQUEST['title']));
		}

		$query_args=array(
			'post_type' => 'car',
			'post_status' => $post_status,
			'ignore_sticky_posts' => 1,
			'posts_per_page' => $posts_per_page,
			'offset' => (max(1, get_query_var('paged')) - 1) * $posts_per_page,
			'orderby' => 'date',
			'order' => 'desc',
			'author' => $user_id,
			's' => $title
		);

		$meta_count = count($meta_query);

		if ($meta_count > 0) {
			$query_args['meta_query'] = array(
				'relation' => 'AND',
				$meta_query
			);
		}

		$tax_count = count($tax_query);

		if ($tax_count > 0) {
			$query_args['tax_query'] = array(
				'relation' => 'AND',
				$tax_query
			);
		}

		$args = apply_filters('ams_my_cars_query_args', $query_args);

		$cars = new WP_Query;

		echo self::$ams_message;

		ams_get_template('car/my-cars.php', array('cars' => $cars->query($args), 'max_num_pages' => $cars->max_num_pages, 'post_status' => $post_status, 'title' => $title, 'car_identity' => $car_identity,'car_status'=>$car_status,'the_query' => $cars));

		wp_reset_postdata();

		return ob_get_clean();
	}

	// Vehicle Handler
	public function my_cars_handler()
	{
		if (!empty($_REQUEST['action']) && !empty($_REQUEST['_wpnonce']) && wp_verify_nonce($_REQUEST['_wpnonce'], 'ams_my_cars_actions')) {

			$ams_profile=new AMS_Profile();

			$action = isset($_REQUEST['action']) ?  sanitize_title(wp_unslash($_REQUEST['action'])) : '';

			$car_id = isset($_REQUEST['car_id']) ?  absint(wp_unslash($_REQUEST['car_id'])) : '';

			global $current_user;

			wp_get_current_user();

			$user_id = $current_user->ID;

			try {
				$car = get_post($car_id);
				$ams_car = new AMS_Car();

				if (!$ams_car->user_can_edit_car($car_id)) {
					throw new Exception(esc_html__('Invalid ID', 'auto-moto-stock'));
				}

				switch ($action) {
					case 'delete' :

						// Trash it
						wp_trash_post($car_id);

						// Message
						self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . wp_kses_post(sprintf(__('<strong>Success!</strong> %s has been deleted', 'auto-moto-stock'), $car->post_title))  . '</div>';
						break;

					case 'mark_featured' :
						$veh_featured = get_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured', true);

						if ($veh_featured == 1)
							throw new Exception(__('This position has already been filled', 'auto-moto-stock'));

						$paid_submission_type = ams_get_option('paid_submission_type', 'no');

						if ($paid_submission_type == 'per_package') {
							$package_num_featured_listings = get_the_author_meta(AMS_METABOX_PREFIX . 'package_number_featured', $user_id);

							$check_package=$ams_profile->user_package_available($user_id);

							if ($package_num_featured_listings > 0 && ($check_package!=-1)  && ($check_package!= 0)) {
								if ($package_num_featured_listings - 1 >= 0) {
									update_user_meta($user_id, AMS_METABOX_PREFIX . 'package_number_featured', $package_num_featured_listings - 1);
								}

								update_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured', 1);

								update_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured_date',current_time('mysql'));

								self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . wp_kses_post(sprintf(__('<strong>Success!</strong> %s has been featured', 'auto-moto-stock'), $car->post_title))  . '</div>';
							} 
							else {
								self::$ams_message = '<div class="ams-message alert alert-danger" role="alert">' . wp_kses_post(sprintf(__('<strong>Warning!</strong> %s Cannot be marked as featured. Either your package does not support featured listings, or you have use all featured listing available under your plan.', 'auto-moto-stock'), $car->post_title))  . '</div>';
							}
						} 
						elseif ($paid_submission_type == 'per_listing') {
							$price_featured_listing = apply_filters('ams_price_featured_listing_for_check_mark_featured',ams_get_option('price_featured_listing',0)) ;
							if($price_featured_listing>0)
							{
								$payment_page_link = ams_get_permalink('payment');
								$return_link = add_query_arg(array('car_id' => $car_id, 'is_upgrade' => 1), $payment_page_link);
								wp_redirect($return_link);
							}
							else{
								update_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured', 1);
								update_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured_date',current_time('mysql'));
							}
						}
						break;

					case 'allow_edit' :
						$listing_avl = get_user_meta($user_id, AMS_METABOX_PREFIX . 'package_number_listings', true);

						$check_package=$ams_profile->user_package_available($user_id);

						if (($listing_avl > 0 || $listing_avl == -1)&&($check_package==1)) {
							if ($listing_avl != -1) {
								update_user_meta($user_id, AMS_METABOX_PREFIX . 'package_number_listings', $listing_avl - 1);
							}

							$package_key = get_the_author_meta(AMS_METABOX_PREFIX . 'package_key', $user_id);

							update_post_meta( $car_id, AMS_METABOX_PREFIX . 'package_key', $package_key );

							self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . wp_kses_post(sprintf(__('<strong>Success!</strong> %s has been allow edit', 'auto-moto-stock'), $car->post_title))  . '</div>';
						} 
						else {
							self::$ams_message = '<div class="ams-message alert alert-danger" role="alert">' . wp_kses_post(__('<strong>Warning!</strong> Can not make "Allow Edit" this vehicle', 'auto-moto-stock'))  . '</div>';
						}
						break;

					case 'relist_per_package' :
						$listing_avl = get_user_meta($user_id, AMS_METABOX_PREFIX . 'package_number_listings', true);

						$check_package=$ams_profile->user_package_available($user_id);

						if (($listing_avl > 0 || $listing_avl == -1)&&($check_package==1)) {
							$auto_approve_request_publish = ams_get_option('auto_approve_request_publish', 0);
							if ($auto_approve_request_publish==1)
							{
								$data = array(
									'ID' => $car_id,
									'post_type' => 'car',
									'post_status' => 'publish'
								);
							}
							else{
								$data = array(
									'ID' => $car_id,
									'post_type' => 'car',
									'post_status' => 'pending'
								);
							}

							wp_update_post($data);

							update_post_meta($car_id, AMS_METABOX_PREFIX . 'car_featured', 0);

							$package_key = get_the_author_meta(AMS_METABOX_PREFIX . 'package_key', $user_id);

							update_post_meta( $car_id, AMS_METABOX_PREFIX . 'package_key', $package_key );

							if ($listing_avl != -1) {
								update_user_meta($user_id, AMS_METABOX_PREFIX . 'package_number_listings', $listing_avl - 1);
							}

							self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . wp_kses_post(sprintf(__('<strong>Success!</strong> %s has been reactivate', 'auto-moto-stock'), $car->post_title))  . '</div>';
						} 
						else {
							self::$ams_message = '<div class="ams-message alert alert-danger" role="alert">' . wp_kses_post(__('<strong>Warning!</strong> Can not relist this vehicle', 'auto-moto-stock'))  . '</div>';
						}
						break;

					case 'relist_per_listing' :
						$auto_approve_request_publish = ams_get_option('auto_approve_request_publish', 0);

						if ($auto_approve_request_publish==1)
						{
							$data = array(
								'ID' => $car_id,
								'post_type' => 'car',
								'post_status' => 'publish'
							);
						}
						else{
							$data = array(
								'ID' => $car_id,
								'post_type' => 'car',
								'post_status' => 'pending'
							);
						}

						wp_update_post($data);

						$submit_title = get_the_title($car_id);
						$args = array(
							'submission_title' => $submit_title,
							'submission_url' => get_permalink($car_id)
						);

						ams_send_email(get_option('admin_email'), 'admin_mail_relist_listing', $args);
						
						self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . sprintf(__('<strong>Success!</strong> %s has been resend for approval', 'auto-moto-stock'), $car->post_title) . '</div>';
						break;

					case 'payment_listing' :
						$payment_page_link = ams_get_permalink('payment');

						$return_link = add_query_arg(array('car_id' => $car_id), $payment_page_link);

						wp_redirect($return_link);
						break;

					case 'hidden' :
						$data = array(
							'ID' => $car_id,
							'post_type' => 'car',
							'post_status' => 'hidden'
						);

						wp_update_post($data);

						self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . wp_kses_post(sprintf(__('<strong>Success!</strong> %s has been hidden', 'auto-moto-stock'), $car->post_title))  . '</div>';
						break;

					case 'show' :
						if($car->post_status=='hidden')
						{
							$data = array(
								'ID' => $car_id,
								'post_type' => 'car',
								'post_status' => 'publish'
							);

							wp_update_post($data);
							self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . wp_kses_post(sprintf(__('<strong>Success!</strong> %s has been publish', 'auto-moto-stock'), $car->post_title))  . '</div>';
						}
						else{
							self::$ams_message = '<div class="ams-message alert alert-danger" role="alert">' . wp_kses_post(__('<strong>Warning!</strong> Can not publish this vehicle', 'auto-moto-stock'))  . '</div>';
						}
						break;

					default :
						do_action('ams_my_cars_do_action_' . $action);
						break;
				}

				do_action('ams_my_cars_do_action', $action, $car_id);

			} 
			catch (Exception $e) {
				self::$ams_message = '<div class="ams-message alert alert-danger" role="alert">' . $e->getMessage() . '</div>';
			}
		}
	}

	/**
	 * My save search
	 * @param $atts
	 * @return null|string
	 */
	public static function my_save_search($atts)
	{
		if (!is_user_logged_in()) {
			echo ams_get_template_html('global/access-denied.php',array('type'=>'not_login'));
			return null;
		}

		extract(shortcode_atts(array(), $atts));

		ob_start();
		global $current_user;

		wp_get_current_user();

		$user_id = $current_user->ID;

		global $wpdb;
		
		$table_name = $wpdb->prefix . 'ams_save_search';

		$results = $wpdb->get_results( 'SELECT * FROM ' . $table_name . ' WHERE user_id = ' . $user_id, OBJECT );

		echo self::$ams_message;

		ams_get_template('car/my-save-search.php', array('save_seach' => $results));
		return ob_get_clean();
	}

	// Saved Search Handler
	public function my_save_search_handler()
	{
		if (!empty($_REQUEST['action']) && !empty($_REQUEST['_wpnonce']) && wp_verify_nonce($_REQUEST['_wpnonce'], 'ams_my_save_search_actions')) {
			$action = isset($_REQUEST['action']) ? sanitize_title(wp_unslash($_REQUEST['action'])) : '';

			$save_id = isset($_REQUEST['save_id']) ?  absint(wp_unslash($_REQUEST['save_id'])) : '';

			global $current_user;

			wp_get_current_user();

			$user_id = $current_user->ID;

			try {
				switch ($action) {
					case 'delete' :
						global $wpdb;

						$table_name         = $wpdb->prefix . 'ams_save_search';

						$results        = $wpdb->get_row( 'SELECT * FROM ' . $table_name . ' WHERE id = ' . $save_id );

						if ( $user_id == $results->user_id ){
							$wpdb->delete( $table_name, array( 'id' => $save_id ), array( '%d' ) );

							self::$ams_message = '<div class="ams-message alert alert-success" role="alert">' . sprintf(__('<strong>Success!</strong> %s has been deleted', 'auto-moto-stock'), $results->title) . '</div>';
						}
						break;

					default :
						do_action('ams_my_save_search_do_action_' . $action);
						break;
				}

				do_action('ams_my_save_search_do_action', $action, $save_id);

			} 
			catch (Exception $e) {
				self::$ams_message = '<div class="ams-message alert alert-danger" role="alert">' . $e->getMessage() . '</div>';
			}
		}
	}

	/**
	 * Submit vahicle
	 * @param $atts
	 * @return string
	 */
	public static function submit_car($atts = array())
	{
		return AMS()->get_forms()->get_form('submit-car', $atts);
	}

	/**
	 * Edit vehicle
	 * @return mixed
	 */
	public function edit_car()
	{
		return AMS()->get_forms()->get_form('edit-car');
	}

	/**
	 * Shortcode My Favorites
	 * @param $atts
	 * @return string
	 */
	public static function my_favorites( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_My_Favorites', 'output' ), $atts );
	}

	/**
	 * Shortcode Advanced Search
	 * @param $atts
	 * @return string
	 */
	public static function advanced_search( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Advanced_Search', 'output' ), $atts );
	}

	/**
	 * Shortcode Compare
	 * @param $atts
	 * @return string
	 */
	public static function compare( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Compare', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle
	 * @param $atts
	 * @return string
	 */
	public static function car( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Carousel
	 * @param $atts
	 * @return string
	 */
	public static function car_carousel( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Carousel', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Slider
	 * @param $atts
	 * @return string
	 */
	public static function car_slider( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Slider', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Gallery
	 * @param $atts
	 * @return string
	 */
	public static function car_gallery( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Gallery', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Featured
	 * @param $atts
	 * @return string
	 */
	public static function car_featured( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Featured', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Type
	 * @param $atts
	 * @return string
	 */
	public static function car_type( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Type', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Maker
	 * @param $atts
	 * @return string
	 */
	public static function car_maker( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Maker', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Model
	 * @param $atts
	 * @return string
	 */
	public static function car_model( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Model', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Body
	 * @param $atts
	 * @return string
	 */
	public static function car_body( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Body', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Search
	 * @param $atts
	 * @return string
	 */
	public static function car_search( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Search', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Search Map
	 * @param $atts
	 * @return string
	 */
	public static function car_search_map( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Search_Map', 'output' ), $atts );
	}

	/**
	 * Shortcode vehicle Advanced Search
	 * @param $atts
	 * @return string
	 */
	public static function car_advanced_search( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Advanced_Search', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Mini Search
	 * @param $atts
	 * @return string
	 */
	public static function car_mini_search( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Mini_Search', 'output' ), $atts );
	}

	/**
	 * Shortcode Vehicle Map
	 * @param $atts
	 * @return string
	 */
	public static function car_map( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Car_Map', 'output' ), $atts );
	}

	/**
	 * Shortcode Manager
	 * @param $atts
	 * @return string
	 */
	public static function manager( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Manager', 'output' ), $atts );
	}

	/**
	 * Shortcode Dealer
	 * @param $atts
	 * @return string
	 */
	public static function dealer( $atts ) {

		return self::shortcode_wrapper( array( 'AMS_Shortcode_Dealer', 'output' ), $atts );
	}

	// Filter Ajax callback
	public function car_gallery_fillter_ajax()
	{
		$car_type = isset($_REQUEST['car_type']) ? str_replace('.', '', ams_clean(wp_unslash($_REQUEST['car_type']))) : '';

		$car_maker = isset($_REQUEST['car_maker']) ? str_replace('.', '', ams_clean(wp_unslash($_REQUEST['car_maker']))) : '';

		$car_model = isset($_REQUEST['car_model']) ? str_replace('.', '', ams_clean(wp_unslash($_REQUEST['car_model']))) : '';

		$car_body = isset($_REQUEST['car_body']) ? str_replace('.', '', ams_clean(wp_unslash($_REQUEST['car_body']))) : '';
		
		$is_carousel = isset($_REQUEST['is_carousel']) ? ams_clean(wp_unslash($_REQUEST['is_carousel']))  : '';

		$columns_gap = isset($_REQUEST['columns_gap']) ? wp_unslash($_REQUEST['columns_gap']) : 'col-gap-30';

		$columns = isset($_REQUEST['columns']) ? absint(wp_unslash($_REQUEST['columns'])) : 4;

		$item_amount = isset($_REQUEST['item_amount']) ? absint(wp_unslash($_REQUEST['item_amount'])) : 10;

		$image_size = isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size'])) : '';

		$color_scheme = isset($_REQUEST['color_scheme']) ? ams_clean(wp_unslash($_REQUEST['color_scheme'])) : '';

		$short_code = '[ams_car_gallery is_carousel="' . $is_carousel . '" color_scheme="' . $color_scheme . '"
		columns="' . $columns . '" item_amount="' . $item_amount . '" image_size="' . $image_size . '" columns_gap="' . $columns_gap . '"
		category_filter="true" car_type="' . $car_type .  '"
		category_filter="true" car_maker="' . $car_maker .  '" category_filter="true" car_model="' . $car_model .  '" category_filter="true" car_body="' . $car_body .  '"]';

		echo do_shortcode($short_code);

		wp_die();
	}

	// Filter City Ajax callback
	public function car_featured_fillter_city_ajax()
	{
		$car_city = isset($_REQUEST['car_city']) ? str_replace('.', '', ams_clean(wp_unslash($_REQUEST['car_city']))) : '';

		$layout_style= isset($_REQUEST['layout_style']) ? ams_clean(wp_unslash($_REQUEST['layout_style'])) : '';

		$car_type= isset($_REQUEST['car_type']) ? ams_clean(wp_unslash($_REQUEST['car_type'])) : '';

		$car_maker= isset($_REQUEST['car_maker']) ? ams_clean(wp_unslash($_REQUEST['car_maker'])) : '';

		$car_model= isset($_REQUEST['car_model']) ? ams_clean(wp_unslash($_REQUEST['car_model'])) : '';

		$car_body= isset($_REQUEST['car_body']) ? ams_clean(wp_unslash($_REQUEST['car_body'])) : '';

		$car_status= isset($_REQUEST['car_status']) ? ams_clean(wp_unslash($_REQUEST['car_status'])) : '';

		$car_exterior= isset($_REQUEST['car_exterior']) ? ams_clean(wp_unslash($_REQUEST['car_exterior'])) : '';

		$car_interior= isset($_REQUEST['car_interior']) ? ams_clean(wp_unslash($_REQUEST['car_interior'])) : '';

		$car_cities= isset($_REQUEST['car_cities']) ? ams_clean(wp_unslash($_REQUEST['car_cities'])) : '';

		$car_state= isset($_REQUEST['car_state']) ? ams_clean(wp_unslash($_REQUEST['car_state'])) : '';

		$car_neighborhood= isset($_REQUEST['car_neighborhood']) ? ams_clean(wp_unslash($_REQUEST['car_neighborhood'])) : '';

		$car_label= isset($_REQUEST['car_label']) ? ams_clean(wp_unslash($_REQUEST['car_label'])) : '';

		$color_scheme= isset($_REQUEST['color_scheme']) ? ams_clean(wp_unslash($_REQUEST['color_scheme'])) : '';

		$item_amount= isset($_REQUEST['item_amount']) ? absint(wp_unslash($_REQUEST['item_amount'])) : 10;
		$image_size= isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size'])) : '';

		$include_heading= isset($_REQUEST['include_heading']) ?  ams_clean(wp_unslash($_REQUEST['include_heading'])) : '';

		$heading_sub_title= isset($_REQUEST['heading_sub_title']) ? ams_clean(wp_unslash($_REQUEST['heading_sub_title'])) : '';

		$heading_title= isset($_REQUEST['heading_title']) ? ams_clean(wp_unslash($_REQUEST['heading_title'])) : '';

		$heading_text_align= isset($_REQUEST['heading_text_align']) ? ams_clean(wp_unslash($_REQUEST['heading_text_align'])) : '';

		$short_code = '[ams_car_featured layout_style="' . $layout_style . '" car_type="' . $car_type . '" car_maker="' . $car_maker . '" car_model="' . $car_model . '" car_body="' . $car_body . '" car_status="' . $car_status . '" car_exterior="' . $car_exterior . '" car_interior="' . $car_interior . '" car_cities="' . $car_cities . '" car_state="' . $car_state . '" car_neighborhood="' . $car_neighborhood . '" car_label="' . $car_label . '" color_scheme="' . $color_scheme . '" color_scheme="' . $color_scheme . '" item_amount="' . $item_amount . '" image_size2="' . $image_size . '" include_heading="' . $include_heading . '" heading_sub_title="' . $heading_sub_title . '" heading_title="' . $heading_title . '" heading_text_align="' . $heading_text_align . '" car_city="' . $car_city . '"]';

		echo do_shortcode($short_code);

		wp_die();
	}

	// Vehicle paging ajax
	public function car_paging_ajax()
	{
		$paged = isset($_REQUEST['paged']) ? absint(wp_unslash($_REQUEST['paged'])) : 1;

		$layout = isset($_REQUEST['layout']) ? ams_clean(wp_unslash($_REQUEST['layout'])) : '';

		$items_amount = isset($_REQUEST['items_amount']) ? absint(wp_unslash($_REQUEST['items_amount'])) : 10;

		$columns = isset($_REQUEST['columns']) ? absint(wp_unslash($_REQUEST['columns'])) :  4;

		$image_size = isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size'])) : '';

		$columns_gap = isset($_REQUEST['columns_gap']) ? wp_unslash($_REQUEST['columns_gap']) : 'col-gap-30';

		$view_all_link = isset($_REQUEST['view_all_link']) ? ams_clean(wp_unslash($_REQUEST['view_all_link'])) : '';

		$car_type= isset($_REQUEST['car_type']) ? ams_clean(wp_unslash($_REQUEST['car_type'])) : '';

		$car_maker= isset($_REQUEST['car_maker']) ? ams_clean(wp_unslash($_REQUEST['car_maker'])) : '';

		$car_model= isset($_REQUEST['car_model']) ? ams_clean(wp_unslash($_REQUEST['car_model'])) : '';

		$car_body= isset($_REQUEST['car_body']) ? ams_clean(wp_unslash($_REQUEST['car_body'])) : '';

		$car_status= isset($_REQUEST['car_status']) ? ams_clean(wp_unslash($_REQUEST['car_status'])) : '';

		$car_exterior= isset($_REQUEST['car_exterior']) ? ams_clean(wp_unslash($_REQUEST['car_exterior'])) : '';

		$car_interior= isset($_REQUEST['car_interior']) ? ams_clean(wp_unslash($_REQUEST['car_interior'])) : '';

		$car_city= isset($_REQUEST['car_city']) ? ams_clean(wp_unslash($_REQUEST['car_city'])) : '';

		$car_state= isset($_REQUEST['car_state']) ? ams_clean(wp_unslash($_REQUEST['car_state'])) : '';

		$car_neighborhood= isset($_REQUEST['car_neighborhood']) ? ams_clean(wp_unslash($_REQUEST['car_neighborhood'])) : '';

		$car_label= isset($_REQUEST['car_label']) ? ams_clean(wp_unslash($_REQUEST['car_label'])) : '';

		$car_featured= isset($_REQUEST['car_featured']) ? ams_clean(wp_unslash($_REQUEST['car_featured'])) : '';

		$author_id = isset($_REQUEST['author_id']) ? ams_clean(wp_unslash($_REQUEST['author_id'])) : '';

		$manager_id = isset($_REQUEST['manager_id'])? ams_clean(wp_unslash($_REQUEST['manager_id'])) : '';
		
		$short_code = '[ams_car item_amount="' . $items_amount . '" layout_style="' . $layout . '"
					view_all_link="' . $view_all_link . '" show_paging="true" columns="' . $columns . '" image_size="' . $image_size . '" columns_gap="' . $columns_gap . '" paged="' . $paged . '" car_type="' . $car_type . '" car_maker="' . $car_maker . '" car_model="' . $car_model . '" car_body="' . $car_body . '" car_status="' . $car_status . '" car_exterior="' . $car_exterior . '" car_interior="' . $car_interior . '" car_city="' . $car_city . '" car_state="' . $car_state . '" car_neighborhood="' . $car_neighborhood . '" car_label="' . $car_label . '" car_featured="' . $car_featured . '" author_id="' . $author_id . '" manager_id="' . $manager_id . '"]';
					
		echo do_shortcode($short_code);

		wp_die();
	}

	// Manager paging ajax
	public function manager_paging_ajax()
	{
		$paged = isset($_REQUEST['paged']) ? absint(wp_unslash($_REQUEST['paged'])) : 1;

		$layout = isset($_REQUEST['layout']) ? ams_clean(wp_unslash($_REQUEST['layout'])) : '';

		$item_amount = isset($_REQUEST['item_amount']) ? absint(wp_unslash($_REQUEST['item_amount'])) : 10;

		$items = isset($_REQUEST['items']) ? ams_clean(wp_unslash($_REQUEST['items'])) : '';

		$image_size = isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size'])) : '';

		$show_paging = isset($_REQUEST['show_paging']) ? ams_clean(wp_unslash($_REQUEST['show_paging'])) : '';

		$post_not_in = isset($_REQUEST['post_not_in']) ? ams_clean(wp_unslash($_REQUEST['post_not_in'])) : '';

		$short_code = '[ams_manager layout_style="' . $layout . '" item_amount="' . $item_amount . '" items ="' . $items . '" image_size="' . $image_size . '" paged="' . $paged . '" show_paging="' . $show_paging . '" post_not_in="' . $post_not_in . '"]';

		echo do_shortcode($short_code);

		wp_die();
	}

	// Vehicle set session view as ajax
	public function car_set_session_view_as_ajax() {

		AMS_Compare::open_session();

		$view_as = isset($_REQUEST['view_as']) ? ams_clean(wp_unslash($_REQUEST['view_as'])) : '';

		if (!empty( $view_as ) && in_array($view_as, array('car-list', 'car-grid'))) {
			$_SESSION['car_view_as'] = $view_as;
		}
	}

	// Manager set session view as ajax
	public function manager_set_session_view_as_ajax() {

		AMS_Compare::open_session();

        $view_as = isset($_REQUEST['view_as']) ? ams_clean(wp_unslash($_REQUEST['view_as'])) : '';

		if (!empty( $view_as ) && in_array($view_as, array('manager-list','manager-grid'))) { 
			$_SESSION['manager_view_as'] = $view_as;
		}
	}
}