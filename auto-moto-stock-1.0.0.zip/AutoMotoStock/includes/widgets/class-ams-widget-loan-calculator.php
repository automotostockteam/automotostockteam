<?php
/**
 * Created by AMS Team.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AMS Widget Loan Calculator
 */
if (!class_exists('AMS_Widget_Loan_Calculator')) {
	class AMS_Widget_Loan_Calculator extends AMS_Widget
	{

		// Constructor.
		public function __construct()
		{
			$this->widget_cssclass = 'ams_widget ams_widget_loan_calculator';

			$this->widget_description = esc_html__("Loan calculator widget", 'auto-moto-stock');

			$this->widget_id = 'ams_widget_loan_calculator';

			$this->widget_name = esc_html__('AMS Loan Calculator', 'auto-moto-stock');
			
			$this->settings = array(
				'title' => array(
					'type' => 'text',
					'std' => esc_html__('Loan Calculator', 'auto-moto-stock'),
					'label' => esc_html__('Title', 'auto-moto-stock')
				),
			);

			parent::__construct();
		}

		/**
		 * Output widget
		 * @param array $args
		 * @param array $instance
		 */
		public function widget($args, $instance)
		{
			$this->widget_start($args, $instance);

			echo ams_get_template_html('widgets/loan-calculator/loan-calculator.php');

			$this->widget_end($args);
		}
	}
}