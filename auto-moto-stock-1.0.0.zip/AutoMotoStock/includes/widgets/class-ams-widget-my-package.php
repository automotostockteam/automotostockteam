<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AMS Widget My Package
 */
if (!class_exists('AMS_Widget_My_Package')) {
	class AMS_Widget_My_Package extends AMS_Widget
	{

		// Constructor.
		public function __construct()
		{
			$this->widget_cssclass = 'ams_widget ams_widget_my_package';

			$this->widget_description = esc_html__("Display the user's package in the sidebar.", 'auto-moto-stock');

			$this->widget_id = 'ams_widget_my_package';

			$this->widget_name = esc_html__('AMS My Package', 'auto-moto-stock');

			$this->settings = array(
				'title' => array(
					'type' => 'text',
					'std' => esc_html__('My Package', 'auto-moto-stock'),
					'label' => esc_html__('Title', 'auto-moto-stock')
				),
			);

			parent::__construct();
		}

		/**
		 * Output widget
		 * @param array $args
		 * @param array $instance
		 */
		public function widget($args, $instance)
		{
			$this->widget_start($args, $instance);
			
			echo ams_get_template_html('widgets/my-package/my-package.php',array('args' => $args, 'instance' => $instance));

			$this->widget_end($args);
		}
	}
}