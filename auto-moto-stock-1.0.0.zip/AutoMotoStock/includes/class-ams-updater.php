<?php
/**
 * AMS Updater plugin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (!class_exists('AMS_Updater')) {

	/**
	 * Class AMS_Updater
	 */
	class AMS_Updater
	{
		public static function updater()
		{
			$ams_repair_option = get_option('ams_repair_option', false);
			$ams_pre_version = get_option( 'ams_version', AMS_PLUGIN_VER );

			if (($ams_repair_option === false) || (version_compare( AMS_PLUGIN_VER, $ams_pre_version, '>' ))) {
				if (function_exists('SQF')) {
					$configs = SQF()->adminThemeOption()->getOptionConfig();

					foreach ($configs as $page => $config) {
						$options_default = SQF()->helper()->getConfigDefault($config);

						$current_option = get_option($config['option_name'], array());
						$is_update = false;

						foreach ($options_default as $k => $v) {
							if (!isset($current_option[$k])) {
								$current_option[$k] = $v;
								$is_update = true;
							}
						}
						
						if ($is_update) {
							update_option($config['option_name'], $current_option);
						}
					}
					update_option('ams_repair_option', true);
					update_option('ams_version', AMS_PLUGIN_VER);
				}
			}			
		}
	}
}