<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if (!class_exists('AMS_Shortcode_Login')) {
    class AMS_Shortcode_Login
    {
        /**
         * Output the cart shortcode.
         *
         * @param array $atts
         */
        public static function output($atts)
        {
            return ams_get_template_html('account/login.php', array('atts' => $atts));
        }
    }
}