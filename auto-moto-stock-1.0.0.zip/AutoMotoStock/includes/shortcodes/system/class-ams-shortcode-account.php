<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Account')) {
	/**
	 * Class AMS_Shortcode_Account
	 */
	class AMS_Shortcode_Account
	{

		/**
		 * Constructor.
		 */
		public function __construct()
		{
			add_shortcode('ams_login', array($this, 'login_shortcode'));
			add_shortcode('ams_register', array($this, 'register_shortcode'));
			add_shortcode('ams_profile', array($this, 'update_profile_shortcode'));
			add_shortcode('ams_reset_password', array($this, 'reset_password_shortcode'));
		}

		/**
		 * Login shortcode
		 */
		public function login_shortcode($atts)
		{
			return ams_get_template_html('account/login.php', array('atts' => $atts));
		}

		/**
		 * Register shortcode
		 */
		public function register_shortcode($atts)
		{
			return ams_get_template_html('account/register.php', array('atts' => $atts));
		}

		/**
		 * Update profile shortcode
		 */
		public function update_profile_shortcode()
		{
			return ams_get_template_html('account/my-profile.php');
		}

		/**
		 * Reset password shortcode
		 */
		public function reset_password_shortcode()
		{
			return ams_get_template_html('account/reset-password.php');
		}
	}
}
new AMS_Shortcode_Account();