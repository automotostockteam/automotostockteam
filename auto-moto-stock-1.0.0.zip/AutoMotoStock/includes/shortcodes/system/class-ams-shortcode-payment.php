<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Payment')) {
	/**
	 * AMS_Shortcode_Payment class.
	 */
	class AMS_Shortcode_Payment
	{
		/**
		 * Constructor.
		 */
		public function __construct()
		{
			add_shortcode('ams_payment', array($this, 'payment_shortcode'));
			add_shortcode('ams_payment_completed', array($this, 'payment_completed_shortcode'));
		}

		/**
		 * Payment shortcode
		 */
		public function payment_shortcode()
		{
			return ams_get_template_html('payment/payment.php');
		}

		/**
		 * Payment completed shortcode
		 */
		public function payment_completed_shortcode()
		{
			return ams_get_template_html('payment/payment-completed.php');
		}
	}
}
new AMS_Shortcode_Payment();