<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
if (!class_exists('AMS_Shortcode_Profile')) {
    class AMS_Shortcode_Profile
    {
        /**
         * Output the cart shortcode.
         *
         * @param array $atts
         */
        public static function output($atts)
        {
            return ams_get_template_html('account/my-profile.php', array('atts' => $atts));
        }
    }
}