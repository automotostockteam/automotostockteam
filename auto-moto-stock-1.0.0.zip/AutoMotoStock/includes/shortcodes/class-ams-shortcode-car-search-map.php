<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Car_Search_Map')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Car_Search_Map
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{

			wp_enqueue_script('google-map');
			wp_enqueue_script('markerclusterer');
			wp_enqueue_style( 'select2_css');
			wp_enqueue_script('select2_js');


			wp_enqueue_script(AMS_PLUGIN_PREFIX . 'search_map');
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-search-map');
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car');

			return ams_get_template_html('shortcodes/car-search-map/car-search-map.php', array('atts' => $atts));
		}
	}
}