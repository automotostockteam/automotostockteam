<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Manager')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Manager
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{
			return ams_get_template_html('shortcodes/manager/manager.php', array('atts' => $atts));
		}
	}
}