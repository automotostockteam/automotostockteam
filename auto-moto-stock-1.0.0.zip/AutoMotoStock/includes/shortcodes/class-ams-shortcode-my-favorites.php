<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_My_Favorites')) {
	/**
	 * Class AMS_Shortcode_My_Favorites
	 */
	class AMS_Shortcode_My_Favorites
	{
		public static function output($atts)
		{
			if (!is_user_logged_in()) {
				echo ams_get_template_html('global/access-denied.php',array('type'=>'not_login'));
				return null;
			}
			$posts_per_page = 8;
			extract(shortcode_atts(array(
				'posts_per_page' => '9',
			), $atts));
			ob_start();
			global $current_user;
			wp_get_current_user();
			$user_id = $current_user->ID;
			$my_favorites = get_user_meta($user_id, AMS_METABOX_PREFIX . 'favorites_car', true);
			if(empty($my_favorites))
			{
				$my_favorites=array(0);
			}
			$args = apply_filters('ams_my_cars_query_args', array(
				'post_type' => 'car',
				'post__in' => $my_favorites,
				'ignore_sticky_posts' => 1,
				'posts_per_page' => $posts_per_page,
				'offset' => (max(1, get_query_var('paged')) - 1) * $posts_per_page,
			));

			$favorites = new WP_Query($args);
			ams_get_template('car/my-favorites.php', array('favorites' => $favorites, 'max_num_pages' => $favorites->max_num_pages));
			return ob_get_clean();
		}
	}
}