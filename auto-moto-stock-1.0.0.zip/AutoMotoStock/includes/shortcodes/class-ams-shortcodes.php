<?php

/**
 * Include system and register public shortcodes.
 */
if (!defined('ABSPATH')) {
	exit;
}

    /**
	 * Class AMS_Shortcode.
	 */
if (!class_exists('AMS_Shortcode')) {
	
	class AMS_Shortcode
	{
		
		 // Constructor
		public function __construct()
		{
			$this->include_system_shortcode();
			$this->register_public_shortcode();
		}

		// Include system shortcodes
		public function include_system_shortcode()
		{
			require_once AMS_PLUGIN_DIR . 'includes/shortcodes/system/class-ams-shortcode-account.php';

			require_once AMS_PLUGIN_DIR . 'includes/shortcodes/system/class-ams-shortcode-car.php';

			require_once AMS_PLUGIN_DIR . 'includes/shortcodes/system/class-ams-shortcode-package.php';

			require_once AMS_PLUGIN_DIR . 'includes/shortcodes/system/class-ams-shortcode-payment.php';

			require_once AMS_PLUGIN_DIR . 'includes/shortcodes/system/class-ams-shortcode-invoice.php';
		}

		// Register shortcodes
		public function register_public_shortcode()
		{
			add_shortcode('ams_car', array($this, 'car_shortcode'));

			add_shortcode('ams_car_carousel', array($this, 'car_carousel_shortcode'));

			add_shortcode('ams_car_slider', array($this, 'car_slider_shortcode'));

			add_shortcode('ams_car_gallery', array($this, 'car_gallery_shortcode'));

			add_shortcode('ams_car_featured', array($this, 'car_featured_shortcode'));

			add_shortcode('ams_car_type', array($this, 'car_type_shortcode'));

			add_shortcode('ams_car_maker', array($this, 'car_maker_shortcode'));

			add_shortcode('ams_car_model', array($this, 'car_model_shortcode'));

			add_shortcode('ams_car_body', array($this, 'car_body_shortcode'));

			add_shortcode('ams_car_search', array($this, 'car_search_shortcode'));

			add_shortcode('ams_car_search_map', array($this, 'car_search_map_shortcode'));

			add_shortcode('ams_car_advanced_search', array($this, 'car_advanced_search_shortcode'));

			add_shortcode('ams_car_mini_search', array($this, 'car_mini_search_shortcode'));

			add_shortcode('ams_car_map', array($this, 'car_map_shortcode'));

			add_shortcode('ams_manager', array($this, 'manager_shortcode'));

			add_shortcode('ams_dealer', array($this, 'dealer_shortcode'));
		}

		/**
		 * Vehicle Gallery
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_gallery_shortcode($atts)
		{
			$filter_style = isset($atts['filter_style']) ? $atts['filter_style'] : 'filter-isotope';

			if ($filter_style == 'filter-isotope') {
				wp_enqueue_script('isotope');
			}

			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-gallery');

			wp_enqueue_script('imageLoaded');

			wp_enqueue_script(AMS_PLUGIN_PREFIX . 'car_gallery');

			return ams_get_template_html('shortcodes/car-gallery/car-gallery.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Carousel with Left Navigation
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_carousel_shortcode($atts)
		{
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-carousel');

			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car');

			return ams_get_template_html('shortcodes/car-carousel/car-carousel.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Slider
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_slider_shortcode($atts) {
			wp_enqueue_style( AMS_PLUGIN_PREFIX . 'car-slider');

			return ams_get_template_html('shortcodes/car-slider/car-slider.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Search
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_search_shortcode($atts) {
			$search_styles = isset($atts['search_styles']) ? $atts['search_styles'] : 'style-default';

			$map_search_enable = isset($atts['map_search_enable']) ? $atts['map_search_enable'] : '';

			if ($search_styles === 'style-vertical' || $search_styles === 'style-absolute') {
				$map_search_enable='true';
			}

			if ($map_search_enable == 'true') {
				wp_enqueue_script('google-map');

				wp_enqueue_script('markerclusterer');

				wp_enqueue_script(AMS_PLUGIN_PREFIX . 'search_js_map');
			} 
			else {
				wp_enqueue_script(AMS_PLUGIN_PREFIX . 'search_js');
			}

			wp_enqueue_style( AMS_PLUGIN_PREFIX . 'car-search');

			wp_enqueue_style( AMS_PLUGIN_PREFIX . 'car');

			$enable_filter_location = ams_get_option('enable_filter_location', 0);
			if($enable_filter_location==1)
			{
				wp_enqueue_style( 'select2_css');

				wp_enqueue_script('select2_js');
			}

			return ams_get_template_html('shortcodes/car-search/car-search.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Search Map
		 * @param $atts
		 * @return string
		 */
		public function car_search_map_shortcode($atts) {
			wp_enqueue_script('google-map');

			wp_enqueue_script('markerclusterer');

			wp_enqueue_style( 'select2_css');

			wp_enqueue_script('select2_js');

			wp_enqueue_script(AMS_PLUGIN_PREFIX . 'search_map');

			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-search-map');

			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car');

			return ams_get_template_html('shortcodes/car-search-map/car-search-map.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Full Search
		 * @param $atts
		 * @return string
		 */
		public function car_advanced_search_shortcode($atts) {
			$enable_filter_location = ams_get_option('enable_filter_location', 0);
			if($enable_filter_location==1)
			{
				wp_enqueue_style( 'select2_css');

				wp_enqueue_script('select2_js');
			}

			wp_enqueue_script(AMS_PLUGIN_PREFIX . 'advanced_search_js');

			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-advanced-search');

			return ams_get_template_html('shortcodes/car-advanced-search/car-advanced-search.php', array('atts' => $atts));
		}

		/**
		 * Mini Search
		 * @param $atts
		 * @return string
		 */
		public function car_mini_search_shortcode($atts) {
			return ams_get_template_html('shortcodes/car-mini-search/car-mini-search.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Featured
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_featured_shortcode($atts)
		{
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-featured');

			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car');

			wp_enqueue_script(AMS_PLUGIN_PREFIX . 'car_featured');

			return ams_get_template_html('shortcodes/car-featured/car-featured.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Type
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_type_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/car-type/car-type.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Maker
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_maker_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/car-maker/car-maker.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Model
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_model_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/car-model/car-model.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Body
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_body_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/car-body/car-body.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Shortcode
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/car/car.php', array('atts' => $atts));
		}

		/**
		 * Manager Shortcode
		 * @param $atts
		 *
		 * @return string
		 */
		public function manager_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/manager/manager.php', array('atts' => $atts));
		}

		/**
		 * Dealer Shortcode
		 * @param $atts
		 *
		 * @return string
		 */
		public function dealer_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/dealer/dealer.php', array('atts' => $atts));
		}

		/**
		 * Vehicle Google Map Shortcode
		 * @param $atts
		 *
		 * @return string
		 */
		public function car_map_shortcode($atts)
		{
			return ams_get_template_html('shortcodes/car-map/car-map.php', array('atts' => $atts));
		}

		// Filter Ajax callback
		public function car_gallery_fillter_ajax()
		{
			$car_type = isset($_REQUEST['car_type']) ?  str_replace('.', '',ams_clean(wp_unslash($_REQUEST['car_type']))) : '';

			$car_maker = isset($_REQUEST['car_maker']) ?  str_replace('.', '',ams_clean(wp_unslash($_REQUEST['car_maker']))) : '';

			$car_model = isset($_REQUEST['car_model']) ?  str_replace('.', '',ams_clean(wp_unslash($_REQUEST['car_model']))) : '';

			$car_body = isset($_REQUEST['car_body']) ?  str_replace('.', '',ams_clean(wp_unslash($_REQUEST['car_body']))) : '';

			$is_carousel = isset($_REQUEST['is_carousel']) ? ams_clean(wp_unslash($_REQUEST['is_carousel'])) : '';

			$columns_gap = isset($_REQUEST['columns_gap']) ? wp_unslash($_REQUEST['columns_gap']) : 'col-gap-30';

			$columns = isset($_REQUEST['columns']) ? absint(wp_unslash($_REQUEST['columns'])) : 4;

			$item_amount = isset($_REQUEST['item_amount']) ? absint(wp_unslash($_REQUEST['item_amount'])) : 10;

			$image_size = isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size'])) : '';
			
			$color_scheme = isset($_REQUEST['color_scheme']) ? ams_clean(wp_unslash($_REQUEST['color_scheme'])) : '';

			$short_code = '[ams_car_gallery is_carousel="' . $is_carousel . '" color_scheme="' . $color_scheme . '"
		columns="' . $columns . '" item_amount="' . $item_amount . '" image_size="' . $image_size . '" columns_gap="' . $columns_gap . '"
		category_filter="true" car_type="' . $car_type . '" car_maker="' . $car_maker . '"car_model="' . $car_model . '"car_body="' . $car_body . '" ]';
			echo do_shortcode($short_code);

			wp_die();
		}

		// Filter City Ajax callback
		public function car_featured_fillter_city_ajax()
		{
			$car_city = isset($_REQUEST['car_city']) ? str_replace('.', '', ams_clean(wp_unslash($_REQUEST['car_city']))) : '';

			$layout_style= isset($_REQUEST['layout_style']) ? ams_clean(wp_unslash($_REQUEST['layout_style'])) : '';

			$car_type= isset($_REQUEST['car_type']) ? ams_clean(wp_unslash($_REQUEST['car_type'])) : '';

			$car_maker = isset($_REQUEST['car_maker']) ? ams_clean(wp_unslash($_REQUEST['car_maker'])) : '';

			$car_model = isset($_REQUEST['car_model']) ? ams_clean(wp_unslash($_REQUEST['car_model'])) : '';

			$car_body = isset($_REQUEST['car_body']) ? ams_clean(wp_unslash($_REQUEST['car_body'])) : '';

			$car_status= isset($_REQUEST['car_status']) ? ams_clean(wp_unslash($_REQUEST['car_status'])) : '';

			$car_exterior= isset($_REQUEST['car_exterior']) ? ams_clean(wp_unslash($_REQUEST['car_exterior'])) : '';

			$car_interior= isset($_REQUEST['car_interior']) ? ams_clean(wp_unslash($_REQUEST['car_interior'])) : '';

			$car_cities= isset($_REQUEST['car_cities']) ? ams_clean(wp_unslash($_REQUEST['car_cities'])) : '';

			$car_state= isset($_REQUEST['car_state']) ? ams_clean(wp_unslash($_REQUEST['car_state'])) : '';

			$car_neighborhood= isset($_REQUEST['car_neighborhood']) ? ams_clean(wp_unslash($_REQUEST['car_neighborhood'])) : '';

			$car_label= isset($_REQUEST['car_label']) ? ams_clean(wp_unslash($_REQUEST['car_label'])) : '';

			$color_scheme= isset($_REQUEST['color_scheme']) ? ams_clean(wp_unslash($_REQUEST['color_scheme'])) : '';

			$item_amount= isset($_REQUEST['item_amount']) ? absint(wp_unslash($_REQUEST['item_amount'])) : 10;

			$image_size= isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size'])) : '';

			$include_heading= isset($_REQUEST['include_heading']) ? ams_clean(wp_unslash($_REQUEST['include_heading'])) : '';

			$heading_sub_title= isset($_REQUEST['heading_sub_title']) ? ams_clean(wp_unslash($_REQUEST['heading_sub_title'])) : '';

			$heading_title= isset($_REQUEST['heading_title']) ? ams_clean(wp_unslash($_REQUEST['heading_title'])) : '';

			$heading_text_align= isset($_REQUEST['heading_text_align']) ? ams_clean(wp_slash($_REQUEST['heading_text_align'])) : '';

			$short_code = '[ams_car_featured layout_style="' . $layout_style . '" car_type="' . $car_type . '" car_maker="' . $car_maker . '" car_model="' . $car_model . '" car_body="' . $car_body . '" car_status="' . $car_status . '" car_exterior="' . $car_exterior . '" car_interior="' . $car_interior . '" car_cities="' . $car_cities . '" car_state="' . $car_state . '" car_neighborhood="' . $car_neighborhood . '" car_label="' . $car_label . '" color_scheme="' . $color_scheme . '" color_scheme="' . $color_scheme . '" item_amount="' . $item_amount . '" image_size2="' . $image_size . '" include_heading="' . $include_heading . '" heading_sub_title="' . $heading_sub_title . '" heading_title="' . $heading_title . '" heading_text_align="' . $heading_text_align . '" car_city="' . $car_city . '"]';

			echo do_shortcode($short_code);

			wp_die();
		}

		// Vehicle paging ajax
		public function car_paging_ajax()
		{
			$paged = isset($_REQUEST['paged']) ? absint(wp_unslash($_REQUEST['paged'])) : 1;

			$layout = isset($_REQUEST['layout']) ? ams_clean(wp_unslash($_REQUEST['layout'])) : '';

			$items_amount = isset($_REQUEST['items_amount']) ? absint(wp_unslash($_REQUEST['items_amount'])) : 10;

			$columns = isset($_REQUEST['columns']) ? absint(wp_unslash($_REQUEST['columns'])) : 4;

			$image_size = isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size']))  : '';

			$columns_gap = isset($_REQUEST['columns_gap']) ? wp_unslash($_REQUEST['columns_gap']) : 'col-gap-30';

			$view_all_link = isset($_REQUEST['view_all_link']) ? ams_clean(wp_unslash($_REQUEST['view_all_link'])) : '';

			$car_type= isset($_REQUEST['car_type']) ? ams_clean(wp_unslash($_REQUEST['car_type'])) : '';

			$car_maker = isset($_REQUEST['car_maker']) ? ams_clean(wp_unslash($_REQUEST['car_maker'])) : '';

			$car_model = isset($_REQUEST['car_model']) ? ams_clean(wp_unslash($_REQUEST['car_model'])) : '';

			$car_body = isset($_REQUEST['car_body']) ? ams_clean(wp_unslash($_REQUEST['car_body'])) : '';

			$car_status = isset($_REQUEST['car_status']) ? ams_clean(wp_unslash($_REQUEST['car_status'])) : '';

			$car_exterior = isset($_REQUEST['car_exterior']) ? ams_clean(wp_unslash($_REQUEST['car_exterior'])) : '';

			$car_interior = isset($_REQUEST['car_interior']) ? ams_clean(wp_unslash($_REQUEST['car_interior'])) : '';

			$car_city= isset($_REQUEST['car_city']) ? ams_clean(wp_unslash($_REQUEST['car_city'])) : '';

			$car_state= isset($_REQUEST['car_state']) ? ams_clean(wp_unslash($_REQUEST['car_state'])) : '';

			$car_neighborhood = isset($_REQUEST['car_neighborhood']) ? ams_clean(wp_unslash($_REQUEST['car_neighborhood'])) : '';

			$car_label= isset($_REQUEST['car_label']) ? ams_clean(wp_unslash($_REQUEST['car_label'])) : '';

			$car_featured= isset($_REQUEST['car_featured']) ? ams_clean(wp_unslash($_REQUEST['car_featured'])) : '';

			$author_id = isset($_REQUEST['author_id']) ? ams_clean(wp_unslash($_REQUEST['author_id'])) : '';

			$manager_id = isset($_REQUEST['manager_id']) ? ams_clean(wp_unslash($_REQUEST['manager_id'])) : '';

			$short_code = '[ams_car item_amount="' . $items_amount . '" layout_style="' . $layout . '"
					view_all_link="' . $view_all_link . '" show_paging="true" columns="' . $columns . '"
					image_size="' . $image_size . '" columns_gap="' . $columns_gap . '" paged="' . $paged . '" car_type="' . $car_type . '" car_maker="' . $car_maker . '" car_model="' . $car_model . '"
					car_body="' . $car_body . '" car_status="' . $car_status . '"
					car_exterior="' . $car_exterior . '" car_interior="' . $car_interior . '" car_city="' . $car_city . '" car_state="' . $car_state . '" car_neighborhood="' . $car_neighborhood . '"
					car_label="' . $car_label . '" car_featured="' . $car_featured . '" author_id="' . $author_id . '" manager_id="' . $manager_id . '"]';
				     
			echo do_shortcode($short_code);

			wp_die();
		}

		/**
		 * Manager paging ajax
		 */
		public function manager_paging_ajax()
		{
			$paged = isset($_REQUEST['paged']) ? absint(wp_unslash($_REQUEST['paged'])) : 1;

			$layout = isset($_REQUEST['layout']) ? ams_clean(wp_unslash($_REQUEST['layout'])) : '';

			$item_amount = isset($_REQUEST['item_amount']) ? absint(wp_unslash($_REQUEST['item_amount'])) : 10;

			$items = isset($_REQUEST['items']) ? ams_clean(wp_unslash($_REQUEST['items'])) : '';

			$image_size = isset($_REQUEST['image_size']) ? ams_clean(wp_unslash($_REQUEST['image_size'])) : '';

			$show_paging = isset($_REQUEST['show_paging']) ? ams_clean(wp_unslash($_REQUEST['show_paging'])) : '';

			$post_not_in = isset($_REQUEST['post_not_in']) ? ams_clean(wp_unslash($_REQUEST['post_not_in'])) : '';

			$short_code = '[ams_manager layout_style="' . $layout . '" item_amount="' . $item_amount . '" items ="' . $items . '" image_size="' . $image_size . '" paged="' . $paged . '" show_paging="' . $show_paging . '" post_not_in="' . $post_not_in . '"]';

			echo do_shortcode($short_code);
			wp_die();
		}

		// Vehicle set session view as ajax
		public function car_set_session_view_as_ajax() {
			AMS_Compare::open_session();

			$view_as = isset($_REQUEST['view_as']) ? ams_clean(wp_unslash($_REQUEST['view_as'])) : '';

			if (!empty( $view_as ) && in_array($view_as, array('car-list', 'car-grid'))) {
				$_SESSION['car_view_as'] = $view_as;
			}
		}

		// Manager set session view as ajax
		public function manager_set_session_view_as_ajax() {
            $view_as = isset($_REQUEST['view_as']) ? ams_clean(wp_unslash($_REQUEST['view_as'])) : '';

			if (!empty( $view_as ) && in_array($view_as, array('manager-list', 'manager-grid'))) {
				$_SESSION['manager_view_as'] = $view_as;
			}
		}
	}
}
new AMS_Shortcode();

