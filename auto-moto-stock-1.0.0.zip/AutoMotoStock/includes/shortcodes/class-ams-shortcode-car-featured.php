<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Car_Featured')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Car_Featured
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car-featured');
			wp_enqueue_style(AMS_PLUGIN_PREFIX . 'car');
			wp_enqueue_script(AMS_PLUGIN_PREFIX . 'car_featured');

			return ams_get_template_html('shortcodes/car-featured/car-featured.php', array('atts' => $atts));
		}
	}
}