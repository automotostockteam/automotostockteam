<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('AMS_Shortcode_Car_Mini_Search')) {
	/**
	 * Class AMS_Shortcode_Package
	 */
	class AMS_Shortcode_Car_Mini_Search
	{
		/**
		 * Package shortcode
		 */
		public static function output( $atts )
		{
			return ams_get_template_html('shortcodes/car-mini-search/car-mini-search.php', array('atts' => $atts));
		}
	}
}