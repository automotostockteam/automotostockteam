<?php

/**
 * Class AMS_Captcha
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

// Class AMS_Captcha
if (!class_exists('AMS_Captcha')) {
	class AMS_Captcha
	{
		// loader instances
		private static $_instance;

		public static function getInstance()
		{
			if (self::$_instance == null) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

        // Enable captcha
		public function render_recaptcha() {
			$enable_captcha = ams_get_option('enable_captcha', array());

			if (is_array($enable_captcha) && count($enable_captcha)>0) {

				wp_enqueue_script('ams-google-recaptcha');

				$captcha_site_key = ams_get_option('captcha_site_key', '');
				?>

				<script type="text/javascript">
					var ams_widget_ids = [];

					var ams_captcha_site_key = '<?php echo esc_js($captcha_site_key); ?>';

					 // reCAPTCHA render
					var ams_recaptcha_onload_callback = function() {
						jQuery('.ams-google-recaptcha').each( function( index, el ) {
							var widget_id = grecaptcha.render( el, {
								'sitekey' : ams_captcha_site_key
							} );

							ams_widget_ids.push( widget_id );
						} );
					};

					 // reCAPTCHA reset
					var ams_reset_recaptcha = function() {

						if( typeof ams_widget_ids != 'undefined' ) {
							var arrayLength = ams_widget_ids.length;

							for( var i = 0; i < arrayLength; i++ ) {
								grecaptcha.reset( ams_widget_ids[i] );
							}
						}
					};
				</script>
				<?php
			}
		}

        // Render recaptcha WP Login
		public function render_recaptcha_wp_login() {

			$enable_captcha = ams_get_option('enable_captcha', array());

			if (is_array($enable_captcha) && count($enable_captcha)>0) {
				$captcha_site_key = ams_get_option('captcha_site_key', '');

				$recaptcha_src = esc_url_raw(add_query_arg(array(
					'render' => 'explicit',
					'onload' => 'ams_recaptcha_onload_callback'
				), 'https://www.google.com/recaptcha/api.js'));
				?>

				<script type="text/javascript">
					var ams_widget_ids = [];

					var ams_captcha_site_key = '<?php echo esc_js($captcha_site_key); ?>';
					
					// reCAPTCHA render
					var ams_recaptcha_onload_callback = function() {

						for ( var i = 0; i < document.forms.length; i++ ) {
							var form = document.forms[i];

							var captcha_div = form.querySelector( '.ams-google-recaptcha' );

							var widget_id = grecaptcha.render( captcha_div, {
								'sitekey' : ams_captcha_site_key
							} );

							ams_widget_ids.push( widget_id );
						}
					};

					// reCAPTCHA reset
					var ams_reset_recaptcha = function() {

						if( typeof ams_widget_ids != 'undefined' ) {
							var arrayLength = ams_widget_ids.length;

							for( var i = 0; i < arrayLength; i++ ) {
								grecaptcha.reset( ams_widget_ids[i] );
							}
						}
					};
				</script>

				<script src="<?php echo esc_url( $recaptcha_src ); ?>"
				        async defer>
				</script>

				<?php
			}
		}

        // Verify reCaptcha
		public function verify_recaptcha() {

			if (!$this->verify()) {
				echo json_encode( array(
					'success' => false,
					'message' => esc_attr__( 'Captcha Invalid', 'auto-moto-stock' )
				) );

				wp_die();
			}
		}

        // Captcha secret key
		public function verify() {

			if (isset($_POST['g-recaptcha-response'])) {
				$captcha_secret_key = ams_get_option('captcha_secret_key', '');

				$response = wp_remote_get("https://www.google.com/recaptcha/api/siteverify?secret=". $captcha_secret_key ."&response=". ams_clean(wp_unslash($_POST['g-recaptcha-response'])));

				$response = json_decode($response["body"], true);
				return true == $response["success"];
			}

			return true;
		}

        // Form reCaptcha
		public function form_recaptcha() {
			$enable_captcha = ams_get_option('enable_captcha', array());

			if (is_array($enable_captcha) && count($enable_captcha)>0) {
				?>

				<div class="ams-recaptcha-wrap clearfix">
					<div class="ams-google-recaptcha"></div>
				</div>

				<?php
			}
		}

        // Verify recaptcha wp login

		public function verify_recaptcha_wp_login($user, $username = '', $password = '') {
			if ( ! $username ) {
				return $user;
			}

			if (!$this->verify()) {
				return new WP_Error( 'captcha_error',__( '<strong>Error</strong>: Captcha Invalid', 'auto-moto-stock' ) );
			}

			return $user;
		}
        
        // Verify recaptcha wp lostpassword
		public function verify_recaptcha_wp_lostpassword($errors) {

			if (!$this->verify()) {

				$errors->add( 'captcha_error', __( '<strong>Error</strong>: Captcha Invalid', 'auto-moto-stock' ) );
			}

			return $errors;
		}

        // verify recaptcha wp registration
		function verify_recaptcha_wp_registration( $errors, $sanitized_user_login, $user_email ) {

			if ( ! $this->verify() ) {

				$errors->add( 'captcha_error', __( '<strong>Error</strong>: Captcha Invalid', 'auto-moto-stock' ) );
			}

			return $errors;
		}
	}
}