(function ($) {
	$(document).ready(function () {
		$('.ams-insert-shortcode-button').on('click', function () {
			AMS_POPUP.required_element();
			AMS_POPUP.reset_fileds();
			$.magnificPopup.open({
				mainClass: 'mfp-zoom-in',
				items: {
					src: '#ams-input-shortcode'
				},
				type: 'inline',
				removalDelay: 500
			}, 0);
		});
	});
})(jQuery);
